(function () {
    var defaultConfig = {
        ":: Main Rice": ["header", ""],
        "Left Margin": [
            65, "Change the size of the left margin.", [{
                name: "Large",
                value: 65
            }, {
                name: "Medium",
                value: 25
            }, {
                name: "Small",
                value: 5
            }, {
                name: "None",
                value: 0
            }, {
                name: "Custom",
                value: 999
            }], true
        ],
        "Custom Left Margin": [
            0, "Left margin custom width (pixels).", "Left Margin", 999, true
        ],
        "Right Margin": [
            65, "Change the size of the right margin.", [{
                name: "Large",
                value: 65
            }, {
                name: "Medium",
                value: 25
            }, {
                name: "Small",
                value: 5
            }, {
                name: "None",
                value: 0
            }, {
                name: "Custom",
                value: 999
            }], true
        ],
        "Custom Right Margin": [
            0, "Right margin custom width (pixels).", "Right Margin", 999, true
        ],
        "Rounded Corners": [true, "Styles replies, menus and Quick Reply to have subtly rounded corners."],
        "Invert Spoiler": [false, "Inverts colors for text spoilers."],
        "Underline All Links": [false, "Underlines all links in the page."],
        "Show Banner": [false, "Toggle visibility of the board banner image.", null, true],
        "Reduce Banner Opacity": [false, "Reduce opacity of the banner for easier viewing.", "Show Banner", true, true],
        "Show Board Name": [true, "Toggle visibility of the board name."],
        "Show Navigation Links": [true, "Toggle visibility of the navigation links at the top and bottom of the threads.", null, true],
        "Show Top Links": [true, "Toggle visibility of the top navigation links.", "Show Navigation Links", true, true],
        "Show Bottom Links": [true, "Toggle visibility of the bottom navigation links.", "Show Navigation Links", true, true],
        ":: Sidebar": ["header", ""],
        "Sidebar Position": [
            3, "Change the position of the sidebar or disable it. If this option is enabled the QR will be locked to the Sidebar.", [{
                name: "Right",
                value: 1
            }, {
                name: "Left",
                value: 2
            }, {
                name: "Disabled",
                value: 3
            }], true
        ],
        "SS-like Sidebar": [false, "Darkens the sidebar and adds a border like 4chan Style Script."],
        "Minimal Sidebar": [false, "Shrinks the sidebar and moves the banner."],
        "Nav Buttons": ["", "Scale, position, spacing and order of the site's ↑ ↓ navigation buttons on thread pages. Set Position opens the editor; drag the buttons on the page while it is open.", null, null, true],
        ":: Quick Reply": ["header", ""],
        "Autohide Style": [
            0, "Changes how the quick reply is hidden.", [{
                name: "Disabled",
                value: 0
            }, {
                name: "Collapse",
                value: 1
            }, {
                name: "Vertical Tabbed",
                value: 2
            }, {
                name: "Fade",
                value: 3
            }]
        ],
        "Transparent QR": [false, "Reduces opacity of the QR box."],
        "Remove Background": [false, "Removes the QR background."],
        "Remove Controls": [false, "Removes the QR controls and checkbox."],
        "Animated Transition": [false, "Enables a transition animation for the QR."],
        "Expanding Form Inputs": [true, "Makes certain form elements expand on focus."],
        "Remember Comment Draft": [false, "Will save and restore unsubmitted QR comments (5 second delay). Drafts expire after 24h."],
        "Auto-Convert Images": [false, "Auto-convert WebP images to JPEG, and convert any image exceeding the board's file size or dimensions limit to JPEG."],
        ":: Replies": ["header", ""],
        "Fit Width": [true, "Replies stretch to the width of the page.", null, true],
        "Fit Post Menu": [false, "Moves the post menu button to the right edge of each post.", "Fit Width", true, true],
        "Fit Expanded Images": [false, "Expanded images will better fit to the viewport."],
        "Show Reply Header": [true, "Shows reply header background and line border."],
        "Show File Info": [true, "Shows the filename, size and dimensions line under each file."],
        "Underline QuoteLinks": [false, "Underlines quotelinks only."],
        "Indent OP": [true, "Indents the OP instead of touching the screen."],
        "Allow Wrapping Around OP": [false, "Allow for replies to wrap around OP instead of being forced onto their own line."],
        "OP Background": [true, "Give OP a background similar to a reply."],
        "Recolor Even Replies": [false, "Makes every other post a darker color. If Quote Threading is enabled darkens every root reply."],
        "Reduce Thumbnail Opacity": [false, "Reduces opacity of thumbnails."],
        "Replace Thumbnails": [false, "Replace thumbnails with the full file. Pick formats below. Uses more bandwidth.", null, true],
        "Replace GIF": [true, "Animate GIF thumbnails.", "Replace Thumbnails", true, true],
        "Replace JPG": [true, "Sharp full-resolution JPG thumbnails.", "Replace Thumbnails", true, true],
        "Replace PNG": [true, "Sharp full-resolution PNG thumbnails.", "Replace Thumbnails", true, true],
        "Replace WEBP": [true, "Sharp full-resolution WEBP thumbnails (animated WEBPs animate).", "Replace Thumbnails", true, true],
        "Replace WEBM/MP4": [false, "Muted looping video thumbnails for WEBM and MP4 files (sound only plays in the expanded player). Heaviest on bandwidth.", "Replace Thumbnails", true, true],
        "Backlink Icons": [false, "Use icons for backlinks instead of text."],
        "Backlink Shadow": [false, "Add a shadow to the backlink text."],
        "Borders": [
            2, "Changes which sides of replies have borders.", [{
                name: "Normal (site default)",
                value: 1
            }, {
                name: "On all sides",
                value: 2
            }, {
                name: "None",
                value: 3
            }]
        ],
        "Margin Between Replies": ['', "Change size of spacing in between replies.", [{
            name: "Very Large",
            value: 15
        }, {
            name: "Large",
            value: 8
        }, {
            name: "Normal (site default)",
            value: ''
        }, {
            name: "Minimal",
            value: -2
        }, {
            name: "None",
            value: -4
        }, {
            name: "Overlapping Borders",
            value: -5
        }]],
        "Post Message Margin": [
            2, "Change size of margin around post message.", [{
                name: "Small",
                value: 1
            }, {
                name: "Normal",
                value: 2
            }, {
                name: "Large",
                value: 3
            }]
        ],
        ":: Catalog": ["header", ""],
        "Justified Text": [false, "Justifies the teaser text of every thread to be more uniform."],
        "Show Background": [true, "Threads receive a matching background."],
        "Unified Thumbnail Size": [false, "Makes all thumbnails the same size regardless of aspect ratio."],
        ":: Post Decoration": ["header", ""],
        "Decoration Style": [
            0, "Changes the decoration of all posts.", [{
                name: "None",
                value: 0
            }, {
                name: "Border",
                value: 1
            }, {
                name: "Outline",
                value: 2
            }, {
                name: "Separator",
                value: 3
            }]
        ],
        "Decoration Width": [
            3, "Changes decoration width of posts including (You)s.", [{
                name: "Large",
                value: 6
            }, {
                name: "Medium",
                value: 3
            }, {
                name: "Small",
                value: 1
            }, {
                name: "Custom",
                value: 999
            }], true
        ],
        "Custom Decoration Width": [
            0, "Enter a custom width for the decoration (pixels).", "Decoration Width", 999, true
        ],
        "Highlight Style": [
            "solid", "Changes style of post highlight.", [{
                name: "Dashed",
                value: "dashed"
            }, {
                name: "Dotted",
                value: "dotted"
            }, {
                name: "Double",
                value: "double"
            }, {
                name: "Inset",
                value: "inset"
            }, {
                name: "Solid",
                value: "solid"
            }]
        ],
        "Opacity": [100, "Adjusts the opacity of post highlighting."],
        ":: Fonts": ["header", ""],
        "Font Family": [
            "sans-serif", "Set the default font family.", [{
                name: "Default (sans-serif)",
                value: "sans-serif"
            }, {
                name: "Monospace",
                value: "monospace"
            }, {
                name: "Serif",
                value: "serif"
            }, {
                name: "Cursive",
                value: "cursive"
            }]
        ],
        "Custom Font": ["", "Enter a custom font name. Please make sure the font name is exact. Overrides the Font Family option if set."],
        "Font Size": [13, "Set the font size of text (in pixels). Default: 13px. Menu elements have a 18px (max) and 9px (min) limit to avoid breaking their layouts."],
        "UI Font Size": [11, "Set the font size of certain QR and button elements (in pixels). Default: 11px."],
        "Backlink Font Size": [10, "Set the font size of backlinks (in pixels). Default: 10px."],
        "Bitmap Font": [false, "Check this if you are using a bitmap font."],
        "Misc": [],
        ":: Notifications": ["header", ""],
        "Toast Notifications": [true, "Show toast notifications for events.", null, true],
        "Style Holotower TS Notifications": [true, "Show Holotower TS notifications in the same style as StyleTower's toasts.", "Toast Notifications", true, true],
        "Center Notifications": [false, "Center notifications at the top below the header bar.", "Toast Notifications", true, true],
        "Full Border": [false, "Use a full border to make notifications more visible. Border style follows the Highlight Style and Width options.", "Toast Notifications", true, true],
        ":: Theming": ["header", ""],
        "System Theming": [false, "Follow the system color scheme: the Dark and Light themes below replace the selected theme.", null, true],
        "Dark Theme": [0, "Theme to use when system is in dark mode.", "System Theming", true, true],
        "Light Theme": [0, "Theme to use when system is in light mode.", "System Theming", true, true],
        "Use StyleTower Icons": [true, "Replace site icons with themed SVG icons. Disable to use the vanilla icons.", null, true],
        "Style Scrollbars": [false, "Customize the look of scrollbars to match the theme.", null, true],
        "Thin Scrollbars": [false, "Use thinner scrollbars.", "Style Scrollbars", true, true],
        ":: Header": ["header", ""],
        "Show Header Background Gradient": [false, "Gives the header bar a gradient background."],
        "Show Header Shadow": [true, "Gives the header a drop shadow."],
        "Highlight Current Board": [true, "Gives the current board link a bottom highlight border."],
        ":: Holotower": ["header", ""],
        ":: General": ["header", ""],
        "Follow Cursor": [true, "Quote previews sit beside the cursor on the roomier side of the screen and stay inside the viewport, instead of the site's placement with the preview's corner under the cursor."],
        "Catalog Links": [false, "Converts board navigation links to catalog links."],
        "Highlight Posts Quoting You": [true, "Styles the highlight of posts quoting you (posts are marked by the site/Holotower TS)."],
        "Highlight Own Posts": [true, "Styles the highlight of your own posts (posts are marked by the site/Holotower TS)."],
        ":: Posting": ["header", ""],
        "Show Original Form": [true, "Show the posting form at the top of the page. Uncheck to hide it and post through the quick reply instead."],
        "Pin Quick Reply": [false, "Open the quick reply automatically when entering a thread."],
        "QR Button Image": ["", "Image URL (or data URI) that replaces the floating Quick Reply button icon. Leave empty to keep the site's icon."],
        "Watch Thread on Reply": [false, "Automatically adds the thread to the thread watcher when posting a reply."],
        ":: Integrations": ["header", ""],
        "Auto Scroll": [true, "Scroll to new posts only when already at the bottom of the thread. Ported from Holotower Auto Scroll."],
        "Sauce Links": [true, "Add X/BSKY sauce links to files with matching filenames. Ported from Holotower X/BSKY Sauce."],
        "Catalog Highlights": [true, "Highlight and pin catalog threads via the Pin Settings button in the catalog. Ported from Holotower Catalog Highlights and Pin."],
        "Enable Mascots": [false, "Display a mascot image in the bottom corner of the page. Selected mascots rotate randomly on each page load."],
        "Hide Mascots in Catalog": [true, "Hides the mascot when viewing the catalog."],
        "Mascots Overlap Posts": [false, "Render the mascot above posts and threads instead of behind them."],
        "Reduce Mascot Opacity": [false, "Fade the mascot out until it is hovered. Note: the mascot captures the mouse where it overlaps the page."],
        "Mascot Max Width": [true, "Cap mascots at the 300px sidebar width by default: an auto-sized image is scaled down to fit, an exact size is shown as typed and clipped past the cap. Each mascot can override this in its editor."],
        "Advanced Mascot Editor": [false, "Remembered mascot editor mode (set from the editor itself)."],
        "Mascots": ["[]", "Mascot data.", null, null, true],
        "Themes": [],
        "Hidden Themes": [],
        "Selected Theme": 1,
        "NSFW Theme": 0
    },
        NAME = "StyleTower",
        NAMESPACE = "StyleTower.",
        VERSION = "1.0.23",
        CHANGELOG = "https://github.com/vampiricwulf/StyleTower/releases/latest",
        themeInputs = [{
            dName: "Reply Background",
            name: "mainColor",
            property: "background-color"
        }, {
            dName: "Reply Border",
            name: "brderColor",
            property: "border-color"
        }, {
            dName: "Input Background",
            name: "inputColor",
            property: "background-color"
        }, {
            dName: "Input Border",
            name: "inputbColor",
            property: "border-color"
        }, {
            dName: "Header Background",
            name: "headerBGColor",
            property: "background-color"
        }, {
            dName: "Header Text",
            name: "headerColor",
            property: "color"
        }, {
            dName: "Board Title",
            name: "boardColor",
            property: "color"
        }, {
            dName: "Body Background",
            name: "bgColor",
            property: "background-color"
        }, {
            dName: "Text",
            name: "textColor",
            property: "color"
        }, {
            dName: "Backlink",
            name: "blinkColor",
            property: "color"
        }, {
            dName: "Header Link",
            name: "headerLColor",
            property: "color"
        }, {
            dName: "Header Link Hover",
            name: "headerLHColor",
            property: "color"
        }, {
            dName: "Link",
            name: "linkColor",
            property: "color"
        }, {
            dName: "Link Hover",
            name: "linkHColor",
            property: "color"
        }, {
            dName: "Quotelinks",
            name: "qlColor",
            property: "color"
        }, {
            dName: "Name",
            name: "nameColor",
            property: "color"
        }, {
            dName: "Tripcode",
            name: "tripColor",
            property: "color"
        }, {
            dName: "Subject",
            name: "titleColor",
            property: "color"
        }, {
            dName: "Greentext",
            name: "quoteColor",
            property: "color"
        }, {
            dName: "Unread Line",
            name: "unreadColor",
            property: "color"
        }, {
            dName: "Highlighting",
            name: "postHLColor",
            property: "color"
        }, {
            dName: "Posts Quoting You",
            name: "quotesYouHLColor",
            property: "color"
        }, {
            dName: "Own Posts",
            name: "ownPostHLColor",
            property: "color"
        }, {
            dName: "Highlighted Threads",
            name: "threadHLColor",
            property: "color"
        }, {
            dName: "Highlighted Reply BG",
            name: "replybgHLColor",
            property: "background"
        }, {
            dName: "Reply Selection",
            name: "replyslctColor",
            property: "outline"
        }, {
            dName: "Hover Preview BG",
            name: "hoverColor",
            property: "background-color"
        }, {
            dName: "Hover Outline",
            name: "hoverOutColor",
            property: "outline"
        }],
        $, $lib, $SS,
        $docBody = null,
        $docHead = null;

    // Cache DOM references for performance
    function getDocBody() {
        return $docBody || ($docBody = document.body);
    }
    function getDocHead() {
        return $docHead || ($docHead = document.head);
    }

    if (!Array.isArray) {
        Array.isArray = function (arg) {
            return Object.prototype.toString.call(arg) === "[object Array]";
        };
    }
    /* STYLE SCRIPT LIBRARY */
    /* More or less based off jQuery */
    /* Kept closure-local: overwriting window.$ clobbers the site's jQuery in
       any environment that doesn't sandbox userscripts */
    $ = $lib = function (selector, root) {
        return this instanceof $lib ?
            this.init(selector, root) : new $lib(selector, root);
    };
    /* Runs cb once selector matches. Gives up after timeout ms (default
       $SS.waitTimeout): an element another script never builds would
       otherwise keep a document-wide observer polling every mutation */
    $.waitFor = function (selector, cb, timeout) {
        var el = document.querySelector(selector);
        if (el) { cb(el); return; }
        // Only an added subtree can hold a new match; querying the whole
        // document on every mutation would cost a page walk per batch for
        // as long as the wait lasts
        var timer, obs = new MutationObserver(function (mutations) {
            for (var i = 0; i < mutations.length; i++) {
                var nodes = mutations[i].addedNodes;
                for (var j = 0; j < nodes.length; j++) {
                    var n = nodes[j];
                    if (n.nodeType !== 1) continue;
                    var found = n.matches(selector) ? n : n.querySelector(selector);
                    if (found) { clearTimeout(timer); obs.disconnect(); cb(found); return; }
                }
            }
        });
        obs.observe(document.documentElement, { childList: true, subtree: true });
        timer = setTimeout(function () { obs.disconnect(); }, timeout || $SS.waitTimeout);
    };
    $.waitForFn = function (test, cb) {
        var result = test();
        if (result) { cb(result); return; }
        setTimeout(function () { $.waitForFn(test, cb); }, 25);
    };

    $lib.prototype = {
        constructor: $lib,
        elems: [],
        length: function () {
            return this.elems.length;
        },
        /* CONSTRUCTOR */
        init: function (selector, root) {
            if (selector == null || selector == undefined) return this;

            if (selector.constructor === $lib) return selector;
            else if (typeof selector === "string") {
                root = root || document;
                var tagCheck = /^<(\w+)([^>]*)>(.*)$/.exec(selector); // No closing tag for root node.

                if (root.constructor === $lib)
                    root = root.get();

                if (tagCheck) {
                    var tag = document.createElement(tagCheck[1]);

                    if (tagCheck[2]) {
                        var attribs, atRegEx = /(\w+)=((?:"(?:[^"]+)"|'(?:[^']+)'|(?:\w+)))/g;
                        while ((attribs = atRegEx.exec(tagCheck[2])) != null) {
                            var val = attribs[2];
                            if ((val[0] == '"' || val[0] === "'") && val[0] == val[val.length - 1])
                                val = val.substr(1, val.length - 2);

                            tag.setAttribute(attribs[1], val);
                        }
                    }

                    tag.innerHTML = tagCheck[3];

                    this.elems = [tag];
                } else if (/^#[\w-]+$/.test(selector) && root == document) {
                    var el;

                    if ((el = document.getElementById(selector.substr(1))) != null)
                        this.elems = [el];
                } else {
                    if (!root || typeof root.querySelectorAll !== "function") {
                        this.elems = [];
                        return this;
                    }
                    var results = root.querySelectorAll(selector);
                    this.elems = Array.prototype.slice.call(results);
                }
            } else if (selector.nodeType)
                this.elems = [selector];
            else if (Array.isArray(selector))
                this.elems = Array.prototype.slice.call(selector);

            return this;
        },

        /* DOM NODE RETRIEVAL */
        get: function (index) {
            if (index == undefined && this.elems.length === 1)
                return this.elems[0];
            else if (index == undefined && !this.hasSingleEl())
                return this.elems;

            return this.elems[index];
        },

        /* DOM MANIPULATION */
        append: function (el) {
            if (el.constructor === $lib)
                el = el.get();

            return this.each(function () {
                this.appendChild(el);
            });
        },
        before: function (el) {
            if (el.constructor === $lib)
                el = el.get();

            return this.each(function () {
                this.parentNode.insertBefore(el, this);
            });
        },
        replace: function (el) {
            return this.each(function () {
                $(this).before(el).remove();
            });
        },
        html: function (html) {
            if (html == undefined)
                return this.elems[0].innerHTML;

            return this.each(function () {
                this.innerHTML = html;
            });
        },
        text: function (text) {
            if (this.length() === 0)
                return;

            if (text == undefined)
                return this.elems[0].textContent;

            return this.each(function () {
                this.textContent = text;
            });
        },
        attr: function (name, val) {
            if (val == undefined)
                if (!this.hasSingleEl())
                    return this;
                else
                    return this.elems[0].getAttribute(name);
            else
                if (val === "")
                    return this.each(function () {
                        this.removeAttribute(name);
                    });

            return this.each(function () {
                this.setAttribute(name, val);
            });
        },
        toggle: function (bHidden) {
            return this.each(function () {
                var $this = $(this);

                if (bHidden == undefined)
                    bHidden = !($this.attr("disabled") === "true");

                $this.attr("hidden", bHidden || "");
                this.style.display = bHidden ? "none" : "";
            });
        },
        hide: function () {
            return this.toggle(true);
        },
        show: function () {
            return this.toggle(false);
        },
        val: function (val) {
            if (val == undefined) {
                var el = this.elems[0];

                if (el == undefined)
                    return false;

                switch (el.type) {
                    case "checkbox":
                    case "radio":
                        return el.checked == true;
                    default:
                        if (/^-?\d+$/.test(el.value))
                            return parseInt(el.value, 10);
                        return el.value;
                }
            }

            return this.each(function () {
                switch (this.type) {
                    case "checkbox":
                    case "radio":
                        this.checked = val;
                        break;
                    default:
                        this.value = val;
                        break;
                }
            });
        },
        addClass: function (classNames) {
            if (!classNames || typeof classNames !== "string") return this;
            var classes = classNames.split(" ");
            return this.each(function () {
                if (this.classList) {
                    for (var j = 0, jMAX = classes.length; j < jMAX; j++)
                        this.classList.add(classes[j]);
                } else {
                    for (var j = 0, jMAX = classes.length; j < jMAX; j++)
                        if (!$(this).hasClass(classes[j]))
                            this.className += (this.className ? " " : "") + classes[j];
                }
            });
        },
        hasClass: function (className) {
            if (!this.hasSingleEl() || this.elems[0].className == undefined)
                return false;

            if (this.elems[0].classList) {
                return this.elems[0].classList.contains(className);
            }

            var regx = new RegExp("\\b" + className + "\\b");
            return regx.test(this.elems[0].className);
        },
        removeClass: function (classNames) {
            if (!classNames || typeof classNames !== "string") return this;
            var classes = classNames.split(" ");
            return this.each(function () {
                if (this.classList) {
                    for (var j = 0, jMAX = classes.length; j < jMAX; j++)
                        this.classList.remove(classes[j]);
                } else {
                    var cclassNames = this.className.split(" "),
                        newClasses = [];
                    for (var k = 0, kMAX = cclassNames.length; k < kMAX; k++) {
                        var found = false;
                        for (var j = 0, jMAX = classes.length; j < jMAX; j++) {
                            if (classes[j] === cclassNames[k]) {
                                found = true;
                                break;
                            }
                        }
                        if (!found && cclassNames[k]) {
                            newClasses.push(cclassNames[k]);
                        }
                    }
                    this.className = newClasses.join(" ");
                }
            });
        },

        remove: function () {
            return this.each(function () {
                this.parentNode.removeChild(this);
            });
        },
        /* DOM TRAVERSING */
        parent: function () {
            if (!this.hasSingleEl()) return this;

            return new $lib(this.elems[0].parentNode);
        },
        children: function (selector) {
            if (!this.hasSingleEl())
                return this;
            else if (selector == null)
                selector = "*";

            return new $lib(selector, this.elems[0]);
        },


        /* EVENT METHODS */
        bind: function (type, listener) {
            return this.each(function () {
                var types = type.split(/\s+/);
                for (var i = 0; i < types.length; i++) {
                    this.addEventListener(types[i], listener, false);
                }
            });
        },
        unbind: function (type, listener) {
            return this.each(function () {
                this.removeEventListener(type, listener, false);
            });
        },
        fire: function (evnt) {
            var ev = document.createEvent("HTMLEvents");

            return this.each(function () {
                ev.initEvent(evnt, true, true);
                this.dispatchEvent(ev);
            });
        },
        scrollIntoView: function (alignWithTop) {
            return this.each(function () {
                this.scrollIntoView(alignWithTop);
            });
        },
        /* HELPER METHODS */
        each: function (func, args) {
            if (args != null && !Array.isArray(args))
                args = [args];

            for (var i = 0, MAX = this.elems.length; i < MAX; ++i)
                func.apply(this.elems[i], args || [i]);

            return this;
        },
        exists: function () {
            return this.elems.length > 0;
        },
        hasSingleEl: function () {
            return this.elems.length === 1;
        },
    };
    /* END STYLE SCRIPT LIBRARY */

    /* STYLE SCRIPT CLASSES & METHODS */
    $SS = {
        waitTimeout: 60000,
        draftDelay: 5000,
        // Replaced video thumbs on the page: while zero, the observers skip
        // their per-mutation player checks
        _videoThumbCount: 0,
        /* Runs one startup feature; a failure is logged and the rest keeps
           going, so a site change that breaks one hook cannot take the
           theme down with it */
        guard: function (name, fn) {
            try { return fn(); } catch (e) { console.error("[StyleTower] " + name + " failed:", e); }
        },
        DOMLoaded: function (reload) {
            var guard = $SS.guard;
            guard("classes", $SS.classes.init);
            guard("disableSiteTheme", $SS.disableSiteTheme);
            guard("migrateMascotScale", $SS.migrateMascotScale);
            guard("displayMascots", $SS.displayMascots);
            guard("integrations", $SS.integrations.init);
            // Runs on settings reloads too so Replace Thumbnails applies
            // without a page refresh (idempotent per image)
            guard("replaceThumbnails", $SS.replaceThumbnails);
            guard("threadMarks", $SS.syncThreadMarks);
            guard("navButtons", $SS.initNavButtons);

            var div;
            if (reload !== true) {
                guard("options", $SS.options.init);

                document.addEventListener("click", function (e) {
                    var li = e.target.closest("[data-cmd='toggle-you']");
                    if (li) $SS.toggleYou(li);
                    li = e.target.closest("[data-cmd='delete-post']");
                    if (li) $SS.deletePost(li, false);
                    li = e.target.closest("[data-cmd='delete-file']");
                    if (li) $SS.deletePost(li, true);
                });

                var MutationObserver = window.MutationObserver || window.WebKitMutationObserver;
                var touchesInline = function (n) {
                    return n.nodeType === 1 && ((n.matches && n.matches(".inline-quote-container")) ||
                        (n.querySelector && n.querySelector(".inline-quote-container") != null));
                };
                // A .post child of a .thread that takes part in the thread
                // marks: not a hover clone, TS's hidden dummy or a post
                // post-hover.js fetched and parked hidden
                var realPost = function (n, parent) {
                    var c = n.classList;
                    return c.contains("post") && !c.contains("post-hover") && !c.contains("dummy") &&
                        !c.contains("hidden") && parent.nodeType === 1 && parent.classList.contains("thread");
                };
                // Every selector the per-node pipeline below can act on
                // (forms, threads and posts, file blocks and info lines,
                // omitted summaries, thumbs, menu buttons, intros and
                // numbers, the site's auto-scroll box, post menus)
                var INTEREST = "form, #quick-reply, .thread, .post, .files, .fileinfo, span.omitted, " +
                    "img.post-image, video.st-thumb-video, a.post-btn, p.intro, .post_no, input.auto-scroll, .post-menu";
                var observer = new MutationObserver(function (mutations) {
                    var i, j, MAX, _MAX, nodes, node, cl, target, inHover, lastVideoTarget = null,
                        inlineSync = false, threads = [];

                    for (i = 0, MAX = mutations.length; i < MAX; ++i) {
                        target = mutations[i].target;
                        // The site's expand-video player comes and goes inside
                        // a replaced video thumb's file block
                        if ($SS._videoThumbCount && target !== lastVideoTarget) {
                            lastVideoTarget = target;
                            $SS.syncVideoThumb(target);
                        }
                        // Churn inside a hover preview (TS refills it from the
                        // source post) never changes the page's own state
                        inHover = target.nodeType === 1 && target.closest(".post-hover") != null;
                        // Containers vanish on collapse; watch removals too
                        nodes = mutations[i].removedNodes;
                        for (j = 0, _MAX = nodes.length; j < _MAX; ++j) {
                            node = nodes[j];
                            if (node === $SS._hoverEl) $SS._hoverEl = null;
                            if (inHover || node.nodeType !== 1) continue;
                            cl = node.classList;
                            if (cl.contains("post-hover") || (cl.contains("dummy") && cl.contains("post"))) continue;
                            if (!inlineSync && touchesInline(node)) inlineSync = true;
                            if (realPost(node, target) && threads.indexOf(target) === -1) threads.push(target);
                        }

                        nodes = mutations[i].addedNodes;

                        for (j = 0, _MAX = nodes.length; j < _MAX; ++j) {
                            node = nodes[j];
                            if (node.nodeType !== 1) continue;
                            cl = node.classList;
                            // The site's post-hover.js adds one preview at a
                            // time: a clone of a post that was processed when
                            // it arrived (attributes and structure come along),
                            // so the per-post work below would only repeat
                            // itself on every hover. Its copied loop video is
                            // the one thing that needs re-arming
                            if (cl.contains("post-hover")) {
                                $SS._hoverEl = node;
                                $SS.placeHover();
                                $SS.armClonedVideos(node);
                                continue;
                            }
                            if (inHover) {
                                $SS.armClonedVideos(node);
                                continue;
                            }
                            // TS's hidden placeholder beside the quoting post
                            if (cl.contains("dummy") && cl.contains("post")) continue;
                            if (!inlineSync && touchesInline(node)) inlineSync = true;
                            // TS's inline quote clones: processed originals too
                            if (cl.contains("inline-cloned-post") || node.closest(".inline-cloned-post")) {
                                $SS.armClonedVideos(node);
                                continue;
                            }
                            if (realPost(node, target) && threads.indexOf(target) === -1) threads.push(target);
                            var canHavePosts = node.nodeName !== "SCRIPT" && node.nodeName !== "STYLE" &&
                                node.nodeName !== "LINK" && node.nodeName !== "META" && node.nodeName !== "BR";
                            // Everything below looks only for the things in
                            // INTEREST; an added node that neither is nor
                            // contains one (TS's scroll markers, media hover
                            // image, notices, effects) skips the dozen
                            // queries it would otherwise get
                            if (!canHavePosts || !(node.matches(INTEREST) || node.querySelector(INTEREST))) continue;

                            if (canHavePosts) {
                                // Whole threads arrive too: the hidden one
                                // post-hover.js prepends to the form for a
                                // cross-thread preview, TS's fetched wrappers
                                var ths = cl.contains("thread") ? [node] : node.getElementsByClassName("thread");
                                for (var k = 0; k < ths.length; ++k)
                                    if (threads.indexOf(ths[k]) === -1) threads.push(ths[k]);
                                var formSel = "#quick-reply, form[name='post']";
                                var forms = node.matches && node.matches(formSel)
                                    ? [node]
                                    : node.querySelectorAll ? node.querySelectorAll(formSel) : [];
                                forms.forEach($SS.handleFormNode);
                                if (node.matches && node.matches("#quick-reply"))
                                    $SS.QRDialogCreationHandler({ target: node });
                                if ($SS._initDone) {
                                    $SS.moveOPFiles(node);
                                    $SS.tidyFileInfo(node);
                                    $SS.moveOmittedSpans(node);
                                    if ($SS.addIndexHideButtons) $SS.addIndexHideButtons(node);
                                    $SS.replaceThumbnails(node);
                                    $SS.replacePostMenuBtn(node);
                                    $SS.integrations.onNodeAdded(node);
                                }
                            }
                            var pm = node.matches && node.matches(".post-menu") ? node : node.querySelector ? node.querySelector(".post-menu") : null;
                            if (pm) {
                                $SS.insertToggleYou(pm);
                                $SS.insertDeletePost(pm);
                            }
                        }
                    }

                    if (inlineSync) $SS.syncInlinedMarks();
                    for (i = 0; i < threads.length; ++i) $SS.syncThreadMarks(threads[i]);
                });

                // Observe only the body element instead of entire document for better performance
                var targetNode = getDocBody() || document.documentElement;
                observer.observe(targetNode, {
                    childList: true,
                    subtree: true
                });

                // Post hover previews follow the cursor. The site's own
                // handler already writes left/top on every mousemove; the
                // placement itself runs once per frame (placeHover), so a
                // burst of moves costs one layout read and write, not one
                // per event. The position is remembered so a preview that
                // appears under a still cursor (scrolling past quote links)
                // is placed the moment it is added
                if ($SS.conf["Follow Cursor"]) {
                    document.addEventListener("mousemove", function (e) {
                        $SS._mouseX = e.clientX;
                        $SS._mouseY = e.clientY;
                        if ($SS._hoverEl) $SS.placeHover();
                    });
                }

                // Auto-convert images on drop
                if ($SS.conf["Auto-Convert Images"]) {
                    guard("initImageConvertOnDrop", $SS.initImageConvertOnDrop);
                }
                // Normalize OP structure (move .files inside .post.op)
                guard("moveOPFiles", $SS.moveOPFiles);
                guard("tidyFileInfo", $SS.tidyFileInfo);
                guard("moveOmittedSpans", $SS.moveOmittedSpans);
                // One-click post hiding + control row on index pages
                if (!$SS.location.reply && !$SS.location.catalog && $SS.location.board) {
                    guard("initIndexPostHiding", $SS.initIndexPostHiding);
                    guard("initIndexNav", $SS.initIndexNav);
                }
                guard("initCatalogCards", $SS.initCatalogCards);
                // Compact single-line thread footer: pull the updater and thread
                // stats up next to the [Return]/[Go to top]/[Catalog] links.
                if ($SS.location.reply) {
                    // #updater is the site's (auto-reload.js); #thread_stats is TS's
                    $.waitFor("#updater", function (updater) {
                        var links = document.getElementById("thread-links");
                        if (links && links.parentNode && updater.previousElementSibling !== links)
                            links.parentNode.insertBefore(updater, links.nextSibling);
                    });
                    if ($SS.isTS())
                        $.waitFor("#thread_stats", function (stats) {
                            var ti = document.getElementById("thread-interactions");
                            if (ti && stats.parentNode !== ti) ti.appendChild(stats);
                        });
                }
                // Remember QR comments
                guard("initRememberComment", $SS.initRememberComment);
                // Native QR autohide (focus/hover behavior for Normal & Vertical Tabbed)
                guard("initNativeQRAutohide", $SS.initNativeQRAutohide);
                // Keep the QR fully inside the window when it or the window changes size
                guard("initKeepQRInView", $SS.initKeepQRInView);

                guard("limitNameSubject", function () { $SS.limitNameSubject(document); });

                // Auto-watch thread on post submission
                if ($SS.conf["Watch Thread on Reply"] && $SS.location.reply) {
                    $SS.handleFormNode();
                }

                // Auto-open the quick reply on thread pages (the floating
                // .quick-reply-btn is the site's opener; #link-quick-reply was
                // 4chan-X). Autohide styles dock the QR as persistent UI, so
                // they imply opening it too.
                if ($SS.location.reply && ($SS.conf["Pin Quick Reply"] || $SS.conf["Autohide Style"] !== 0)) {
                    var qrOpened = false,
                        openQR = function () {
                            if (qrOpened) return;
                            qrOpened = true;
                            var btn = document.querySelector("a.quick-reply-btn");
                            if (btn) btn.click();
                            // Some scripts pre-build the QR hidden; reveal it
                            var qr = document.getElementById("quick-reply");
                            if (qr && qr.style.display === "none") qr.style.display = "";
                        };
                    $.waitFor("a.quick-reply-btn, #quick-reply", function () {
                        setTimeout(openQR, 50);
                    });
                }

                // With an Autohide Style the QR is persistent docked UI, so
                // TS's quick reply keybind (which closes/reopens the form)
                // fights it; repurpose the same binding as a show/hide toggle.
                // Capture phase runs before TS's bubble listener.
                if ($SS.location.reply && $SS.conf["Autohide Style"] !== 0) {
                    document.addEventListener("keydown", function (e) {
                        var tag = e.target.tagName;
                        if (tag === "INPUT" || tag === "TEXTAREA" || !e.key) return;
                        var kb = { ctrl: false, alt: false, shift: false, key: "q" };
                        try {
                            var ts = JSON.parse(localStorage.getItem("Thread Settings") || "{}");
                            if (ts.enableQuickReply === false) return;
                            if (ts.kbQuickReply) kb = ts.kbQuickReply;
                        } catch (er) {}
                        if (e.key.toLowerCase() !== String(kb.key || "q").toLowerCase() ||
                            e.ctrlKey !== !!kb.ctrl || e.altKey !== !!kb.alt || e.shiftKey !== !!kb.shift)
                            return;
                        e.preventDefault();
                        e.stopImmediatePropagation();
                        $SS.toggleAutohideQR();
                    }, true);
                }

                if ($SS.conf["Catalog Links"]) {
                    function fixBoardLinks(nav) {
                        if (!nav) return;
                        nav.querySelectorAll("a[href]").forEach(function (a) {
                            var href = a.getAttribute("href");
                            if (/^\/[a-z0-9]+\/(?:index\.html)?$/i.test(href))
                                a.setAttribute("href", href.replace(/(?:index\.html)?$/, "catalog.html"));
                        });
                    }
                    document.querySelectorAll(".boardlist").forEach(fixBoardLinks);
                }

                // Handle a quick reply that appeared before init
                setTimeout(function () {
                    if (!$SS.QRhandled && (div = $("#quick-reply")).exists())
                        $SS.QRDialogCreationHandler({
                            target: div.elems[0]
                        });
                });

                $SS._initDone = true;
            }
        },
        init: function (reload, overrides) {
            if (!reload) {
                if (/^about:neterror/.test(document.documentURI)) return;
                $SS.hasGM = typeof GM_deleteValue !== "undefined";

                $SS.location = $SS.getLocation();

                if ($SS.Config.get("VERSION") !== VERSION) {
                    setTimeout(function () {
                        var content = document.createElement('span');
                        var changelogLink = document.createElement('a');

                        content.appendChild(document.createTextNode(NAME + ' has been updated to version ' + VERSION + '.'));
                        content.appendChild(document.createElement('br'));
                        changelogLink.href = CHANGELOG;
                        changelogLink.target = '_blank';
                        changelogLink.rel = 'noopener noreferrer';
                        changelogLink.textContent = 'Read the changelog.';
                        content.appendChild(changelogLink);

                        $SS.notify({
                            type: 'info',
                            content: content,
                            lifetime: 15
                        });
                    }, 25);
                    // Correct selected theme after updating
                    // and the number defaults has changed.
                    var ntThemes = $SS.Themes.defaults.length,
                        otThemes = $SS.Config.get("Total Themes"),
                        sTheme = $SS.Config.get("Selected Theme");

                    if (otThemes !== ntThemes && otThemes != undefined && sTheme >= otThemes) {
                        sTheme += ntThemes - otThemes;
                        $SS.Config.set("Selected Theme", sTheme);
                    }

                    $SS.Config.set("VERSION", VERSION);
                    $SS.Config.set("Total Themes", ntThemes);
                }
            }

            $SS.Config.init(overrides);
            $SS.Themes.init();

            // Set native site theme to mitigate unloaded CSS flashbang #6
            (function () {
                try {
                    localStorage.stylesheet = $SS.theme.bgColor.isLight ? "Yotsuba B" : "Tomorrow";
                } catch (e) {}
            })();

            if (reload) {
                $SS.insertCSS();
                $SS.DOMLoaded(true);
            } else {
                $SS.insertCSS();
                if (/complete|interactive/.test(document.readyState))
                    $SS.DOMLoaded();
                else
                    $(document).bind("DOMContentLoaded", $SS.DOMLoaded);
            }

        },

        /* STYLING & DOM */
        insertCSS: function () {
            var css,
                reload = $("#ch4SS").exists();

            if ($SS.location.dead)
                return;

            css = "#expand-all-images,#password,#watch-board,#watch-pin,#watch-thread,.boardlist.bottom,.post-hover input[type=checkbox],.tab-select:not(:checked)+div,:root.hide-banner img.board_image,:root.hide-board-name header div.subtitle,:root.hide-board-name header h1,:root.hide-navlinkbot #thread-links,:root.hide-navlinks #thread-links,:root.hide-navlinks div.banner,:root.hide-navlinktop div.banner,:root.qr-controls #quick-reply a.close-btn,:root.show-file-info p.fileinfo .unimportant,:root.show-form form[name=post]:not(#quick-reply),:root:not(.st-home) footer,:root:not(.st-home) hr,[hidden],div.styles,form[name=postcontrols] .post input[type=checkbox],iframe[src='about:blank'],label:has(> a.threading-toggle){display:none}a,input:focus,select,textarea:focus{outline:0!important}.sjis{font-size:16px;line-height:17px;white-space:pre;font-family:IPAMonaPGothic,Mona,'MS PGothic',monospace;overflow:auto;display:block;clear:left}.files .file>a{float:left;margin-left:13px;margin-right:20px;margin-bottom:10px}.thread>.files .file>a{margin-bottom:0}p.fileinfo{margin-left:13px!important;margin-bottom:2px!important}p.fileinfo>.unimportant{margin-left:4px}.fixed.top-header body.active-index{padding-bottom:2.5em;padding-top:" + (($SS.conf["Font Size"] <= 11) ? 3.2 : 2.4) + "em!important}.fixed.top-header body.active-thread{padding-bottom:0;padding-top:" + (($SS.conf["Font Size"] <= 11) ? 3.2 : 2.4) + "em!important}.fixed.top-header body.active-catalog{padding-bottom:.5em;padding-top:" + (($SS.conf["Font Size"] <= 11) ? 3.2 : 2.4) + "em!important}.fixed.top-header body{padding-top:2.4em!important}.boardlist.bottom{margin-bottom:15px}:root:not(.fixed) .boardlist:not(.bottom){margin-top:15px}div.post{margin:4px 0;overflow:hidden}:root:not(.reply-fit-width) form[name=postcontrols] div.post.reply:not([hidden]):not(.iq-hidden-post):not(.hidden-post):not(.hidden){display:table!important}div.thread{margin:0;clear:both;padding-bottom:10px}div.pages{float:left}span.spoiler,span.spoiler:not(:hover)>a{color:#000;background:none repeat scroll 0 0 #000}span.spoiler:focus,span.spoiler:hover{color:#fff}hr{clear:both}table{border-spacing:1px;margin-left:auto;margin-right:auto}#post-moderation-fields{float:right}.fixed.top-header body.active-index #post-moderation-fields,.fixed.top-header body.active-thread #post-moderation-fields{margin-bottom:8px}input[value=Next],input[value=Previous]{padding:4px 13px}div.post img.icon{margin-bottom:-3px}select{padding:0 0 2px 2px;margin-right:1px}.theme-catalog .replies>strong{margin-bottom:5px}form[name=post] input[type=file]{height:23px}#quick-reply input[type=file]{margin-right:0!important}:root.left-sidebar #quick-reply,:root.right-sidebar #quick-reply{max-width:300px!important}:root.left-sidebar #quick-reply input[type=text],:root.left-sidebar #quick-reply textarea,:root.right-sidebar #quick-reply input[type=text],:root.right-sidebar #quick-reply textarea{max-width:294px!important}:root.left-sidebar #quick-reply textarea,:root.right-sidebar #quick-reply textarea{min-width:294px!important}form[name=post]:not(#quick-reply){margin-top:1em}:root.normal-qr #quick-reply:not(:hover):not(.focus){width:303px!important}:root.normal-qr #quick-reply:not(:hover):not(.focus) table tr:not(:first-child){display:none!important}:root.normal-qr .qr-transition #quick-reply table tr:not(:first-child){transition:opacity .2s ease-in-out .1s}#quick-reply input[type=file]::-webkit-file-upload-button,#quick-reply input[type=file]::file-selector-button,form[name=post] input[type=file]::-webkit-file-upload-button,form[name=post] input[type=file]::file-selector-button{appearance:none;cursor:pointer;height:23px;padding:0 6px;text-transform:uppercase;margin-right:4px;background:rgb(var(--sc-mainColor-rgb))!important;border-style:solid;border-width:1px;border-color:rgb(var(--sc-mainColor-shiftM15)) rgb(var(--sc-mainColor-shiftM15)) rgb(var(--sc-mainColor-shiftM30))!important;color:var(--sc-textColor)!important;font-family:" + $SS.formatFont($SS.conf["Font Family"]) + ";font-size:" + $SS.conf["UI Font Size"] + "px!important}#quick-reply input[type=file]:hover::-webkit-file-upload-button,#quick-reply input[type=file]:hover::file-selector-button,form[name=post] input[type=file]:hover::-webkit-file-upload-button,form[name=post] input[type=file]:hover::file-selector-button{background:rgb(var(--sc-mainColor-shift10))!important}:root.follow-cursor #chx_hoverImage{max-width:calc(100vw - 100px);max-height:calc(100vh - 60px)}body{margin-left:" + $SS.conf["Margin Left"] + "px;margin-right:" + $SS.conf["Margin Right"] + "px;margin-top:0;margin-bottom:0}div.post.reply{padding:0!important;max-width:none!important}p.intro{margin:0!important;padding:5px 13px!important;display:block!important}span.omitted{margin-left:2px}.thread>span.omitted{display:block;clear:both;margin:2px 0 4px 4px!important;font-style:italic;opacity:.8}div.post.op{display:block;margin-left:4px;margin-right:4px}:root.op-background .op{padding:4px 0}:root.force-indent .op{margin-left:-12px}:root.force-wrapping .op::after{clear:both;content:'';display:block}.thread>.post.reply,.threadingContainer>.post.reply,:root.op-background .thread>.post.op{margin-bottom:" + ($SS.conf["Margin Between Replies"] !== '' ? $SS.conf["Margin Between Replies"] : 4) + "px!important}.thread>.post.reply.st-last-reply,:root.op-background .thread>.post.op.st-last-post{margin-bottom:0!important}:root.oneechan .post.op.st-inlined:not(.iq-hidden-post),:root.oneechan .post.reply.st-inlined:not(.iq-hidden-post):not(.inline-cloned-post):not(.post-hover){opacity:.45;filter:grayscale(60%);transition:opacity .2s ease,filter .2s ease}:root.oneechan .post.op.st-inlined:not(.iq-hidden-post):hover,:root.oneechan .post.reply.st-inlined:not(.iq-hidden-post):not(.inline-cloned-post):not(.post-hover):hover{opacity:.85;filter:grayscale(20%)}.post+br,.reply+br,.thread>br,.threadingContainer>br{display:none!important}div.body{margin:" + $SS.conf["Margin Post Message"] + "!important}:root.fit-eximg .full-image{max-height:calc(100vh - 8rem)!important;max-width:100%!important;width:auto!important;height:auto!important}:root.reply-fit-width .reply.post:not(.iq-hidden-post):not(.hidden-post):not(.hidden){display:block!important}:root.reply-fit-width .post.reply{overflow:hidden!important}:root.post-info .post.reply>p.intro{box-shadow:inset rgba(0,0,0,.05) 0 -1px 2px;padding-top:2px!important}:root.post-info .post.reply.post-hover{padding:0 0 1px!important}p.intro a.post-btn{margin:0 0 0 5px!important}:root.reply-fit-width.fit-postmenu p.intro>a.post-btn{float:right!important;margin:2px 20px 0 0!important}:root.reply-fit-width .post a.post-btn{position:relative;opacity:0}:root.reply-fit-width .post:not(:hover) a.post-btn{transition:opacity .3s ease-out 0s!important}:root.reply-fit-width .post:hover a.post-btn{opacity:1;transition:opacity .3s ease-in .1s!important}pre{padding:5px!important;display:block;max-height:400px;overflow-x:auto;max-width:100%;white-space:pre-wrap;overflow-wrap:anywhere}input[type=button],input[type=checkbox],input[type=submit]{cursor:pointer}input[type=checkbox]{display:inline-block;height:12px!important;position:relative;width:12px!important;border-radius:2px!important;appearance:none;margin:0 2px -1px 0}input[type=checkbox]:checked::before{content:'✓';position:absolute;top:0;left:0;height:12px;width:11px;font-size:11px;line-height:12px;text-align:center;color:var(--sc-textColor)}.boardlist:not(.bottom){padding:4px 4px 5px!important}:root:not(.fixed) .boardlist:not(.bottom){top:0;right:0;left:0;box-shadow:0 1px 2px rgba(0,0,0,.15)}:root.autohide body,:root.autohide.fixed.top-header body{padding-top:0!important;padding-bottom:0!important}:root:not(.fixed).right-sidebar .boardlist:not(.bottom){right:300px}:root:not(.fixed).left-sidebar .boardlist:not(.bottom){left:300px}.boardlist a{margin-left:2px}h2,h3{margin:auto}a.quick-reply-btn img{display:block}.post-menu{z-index:80}hr{height:2px;border:none!important}header h1{cursor:default;letter-spacing:-2px;padding-top:.1em}img.board_image{border:0!important;margin:0 auto;max-height:100px!important;max-width:100%}:root.banner-opacity img.board_image{opacity:.5;transition:opacity .3s ease-out 0s}:root.banner-opacity img.board_image:hover{opacity:1}div.pages a[href$='catalog.html']{margin-left:12px}div.pages a[href$='catalog.html'],input[value=Next],input[value=Previous]{font-weight:700;transition:opacity .3s ease-in 0s}div.pages a.selected:hover,div.pages a[href$='catalog.html']:hover,input[value=Next]:hover,input[value=Previous]:hover{opacity:.7}.pages a{padding:5px 10px;margin-left:-1px}div.banner{font-size:0!important;background:0 0!important;text-align:left;padding:0!important;margin:8px 0!important}div.banner a{font-size:" + $SS.conf["Font Size"] + "px!important;margin-right:5px}#updater{float:left}a.reply.hide-button,a.reply.show-button{color:var(--sc-blinkColor)!important;opacity:.5;text-decoration:none!important}a.reply.show-button{float:none!important;clear:both;display:flex;align-items:center;gap:13px;width:fit-content;margin-top:8px}a.reply.show-button .hide-icon,a.reply.show-button svg.plus{vertical-align:baseline!important;margin:0!important;display:inline-flex;align-items:center}a.reply.hide-button:hover,a.reply.show-button:hover{opacity:1;color:var(--sc-linkHColor)!important}a.hide-thread-link{display:none!important}a.st-index-hide{float:left;padding:2px}:root.st-menu-silent .post-menu{display:none!important}.post.st-index-hidden{opacity:.6}a.st-index-hide:has(+ .post.reply[style*='display: none']){display:none!important}#update_thread{padding-left:0!important}#thread-catalog::before,header div.subtitle a::before{content:'['}#thread-catalog::after,header div.subtitle a::after{content:']'}#thread-interactions{margin-bottom:5px}#st-index-nav{margin:12px 0 6px;clear:both}#st-index-nav>a{margin-right:5px;text-decoration:none}#st-index-nav>a::before{content:'['}#st-index-nav>a::after{content:']'}#st-index-age{opacity:.7;margin:0 8px 0 2px;font-size:" + (($SS.conf["Font Size"] <= 10) ? 9 : $SS.conf["Font Size"] - 2) + "px}#st-index-search{width:180px!important;min-width:0!important}.st-search-hidden{display:none!important}div.pages{font-size:0!important;background:rgb(var(--sc-mainColor-rgb))!important;border:1px solid var(--sc-brderColor)!important;color:var(--sc-textColor)!important;padding:5px 8px!important;margin:0 0 10px!important}:root.rounded-corners div.pages{border-radius:3px}div.pages a,div.pages input[type=submit]{font-size:" + (($SS.conf["Font Size"] >= 18) ? 18 : ($SS.conf["Font Size"] <= 9 ? 9 : $SS.conf["Font Size"])) + "px!important;padding:2px 6px!important}div.pages form{display:inline!important}div.pages input[type=submit]{background:0 0!important;border:none!important;color:var(--sc-linkColor)!important;cursor:pointer;text-transform:none!important}div.pages input[type=submit]:hover{color:var(--sc-linkHColor)!important}div.pages a.selected{background:rgba(var(--sc-mainColor-shiftM16),.8)!important;color:var(--sc-textColor)!important;text-decoration:none!important;transition:opacity .3s ease-in 0s}:root.rounded-corners div.pages a.selected{border-radius:2px}.post-hover{z-index:75!important}:root.thumb-opacity .file>a img:not(.full-image){opacity:.5;transition:opacity .3s ease-out 0s}:root.thumb-opacity .file>a img:not(.full-image):hover{opacity:1}select{appearance:none}form[name=postcontrols]{overflow-wrap:break-word;word-break:break-word;margin-bottom:15px}.st-video-thumb img.post-image{display:none!important}video.st-thumb-video{display:block;cursor:pointer;max-width:300px;max-height:300px}#scroll-buttons.st-nav-custom{gap:var(--st-nav-gap,0)}#scroll-buttons.st-nav-reversed>a#nav-to-top{order:1}#scroll-buttons.st-nav-editing{z-index:130!important;cursor:move;outline:2px dashed var(--sc-linkColor);outline-offset:4px}#scroll-buttons.st-nav-editing a{cursor:move}#styletower-mascots{position:fixed;bottom:0;z-index:-1;display:flex;flex-direction:column;gap:8px;pointer-events:none}#styletower-mascots.mascots-right{right:10px;align-items:flex-end}#styletower-mascots.mascots-left{left:10px;align-items:flex-start}#styletower-mascots.mascots-capped{max-width:300px;overflow:hidden}:root.right-sidebar #styletower-mascots.mascots-right{right:3px}:root.left-sidebar #styletower-mascots.mascots-left{left:3px}#styletower-mascots img{max-width:300px;display:block}:root.mascot-overlap #styletower-mascots{z-index:5}:root.mascot-dim #styletower-mascots{opacity:.35;transition:opacity .25s ease;pointer-events:auto}:root.mascot-dim #styletower-mascots:hover{opacity:1}.post-menu,body,div.pages a.selected,form table th,form[name=post] table td,header,input,select,span.omitted,textarea{color:var(--sc-textColor)!important}p.intro span.name{color:var(--sc-nameColor)!important}p.intro a.capcode,p.intro span.capcode{color:purple!important}p.intro span.trip{color:var(--sc-tripColor)!important}:root .options-button,a:not(span.spoiler>a),a:visited,span.spoiler:hover>a:not(:hover){color:var(--sc-linkColor)!important}#import-link>.options-button:hover,:root a:hover,:root div.post p.intro a.post_no:hover{color:var(--sc-linkHColor)!important}.boardlist{color:var(--sc-headerColor)!important;border:none!important}.boardlist a{color:var(--sc-headerLColor)!important}.boardlist a:hover{color:var(--sc-headerLHColor)!important}.theme-catalog .replies .quote,div.body span.quote,span.spoiler:hover .quote{color:var(--sc-quoteColor)!important}.option.header .option-title,.tab-label,span.subject{color:var(--sc-titleColor)!important}.option.header{font-size:140%}header h1{color:var(--sc-boardColor)!important;text-shadow:none!important}:root p.intro .clone-mentioned a,:root p.intro .mentioned a,a.post-btn{color:var(--sc-blinkColor)!important}:root.backlink-shadow p.intro .clone-mentioned a,:root.backlink-shadow p.intro .mentioned a{text-shadow:1px 1px 5px}:root div.body a.quotelink,:root div.body a[onclick*=citeReply],:root div.body a[onclick*=highlightReply]{color:var(--sc-qlColor)!important}pre{background:none repeat scroll 0 0 rgba(var(--sc-codeBackground))!important;border:1px solid rgba(var(--sc-codeBorder))!important}::placeholder{color:rgba(var(--sc-textColor-rgb),.4)!important}body{background:var(--sc-bgImg) var(--sc-bgColor)!important}:root::before{content:'';position:fixed;top:0;right:0;bottom:0;left:0;z-index:-3;pointer-events:none;background:var(--sc-bgImgFixed)}.reply,:root.op-background .post.op{background:rgba(var(--sc-mainColor-rgb),var(--sc-replyOp))!important;border-width:0 1px 1px 0;border-style:solid}#alert_div,#header-bar.dialog,#options_div,#pin-settings,#quick-reply .handle,.watch-menu,form table th,form[name=post] table td{background:rgb(var(--sc-mainColor-rgb))!important}.post-menu ul{background:rgb(var(--sc-mainColor-rgb))!important;border:1px solid var(--sc-brderColor)!important}.post-menu,.post-menu li{color:var(--sc-textColor)!important}.post-menu li:hover{background:rgb(var(--sc-mainColor-shift15))!important}#add-mascot,#add-theme,#oneechan-options,#st-nav-editor,.tab-label{background:rgb(var(--sc-mainColor-rgb))!important}#add-mascot,#add-theme,#st-nav-editor{color:var(--sc-textColor)!important}:root.recolor-even .thread>.post.reply.st-even:not(.highlighted):not(:target){background:rgb(var(--sc-mainColor-shiftM10),var(--sc-replyOp))!important}:root:not(.header-gradient) .boardlist{background:rgba(var(--sc-headerBGColor-rgb),var(--sc-navOp))!important}:root.header-gradient .boardlist{background:linear-gradient(rgb(var(--sc-headerBGColor-shift15)),rgba(var(--sc-headerBGColor-rgb),var(--sc-navOp)))!important}:root.header-shadow .boardlist{box-shadow:none!important}#link-quick-reply,#quick-reply input[type=submit],.options-button,button.outline,div.pages a.selected,form[name=post] input[type=submit],input[value=Next],input[value=Previous]{background:linear-gradient(rgb(var(--sc-mainColor-shift15)),rgb(var(--sc-mainColor-rgb)))!important}#quick-reply input[type=submit]:hover,.import-input:hover+.options-button,.options-button:hover,button.outline:hover,div.pages a.selected:hover,form[name=post] input[type=submit]:hover,input[value=Next]:hover,input[value=Previous]:hover{background:rgb(var(--sc-mainColor-shift15))}#link-quick-reply:hover,:root.vertical-qr #quick-reply .handle{background:rgb(var(--sc-mainColor-rgb))}#quick-reply input,input[type=text],select,textarea{background:var(--sc-inputColor)!important;transition:background .2s,color .2s,border-color .2s!important}input[type=checkbox]{background:rgb(var(--sc-inputColor-shift25))!important}#quick-reply input:hover,input[type=checkbox]:hover,input[type=text]:hover,select:hover,textarea:hover{background:rgb(var(--sc-inputColor-hover))!important}hr{background-image:linear-gradient(to left,rgba(var(--sc-brderColor-rgb),0),rgb(var(--sc-brderColor-rgb)),rgba(var(--sc-brderColor-rgb),0))}div.post.reply[style*='box-shadow: 0 3px red'],div.post.reply[style*='box-shadow: 0px 3px red'],div.post.reply[style*='box-shadow: red 0px 3px']{box-shadow:0 3px rgb(var(--sc-unreadColor-rgb))!important}.post-hover{background:rgba(var(--sc-hoverColor-rgb),var(--sc-hoverOp))!important}:root.post-info .reply>p.intro{background:rgba(var(--sc-mainColor-shiftM16),.2);border-bottom:1px solid rgb(var(--sc-mainColor-shift4))}:root.borders-all .reply,:root.borders-all.op-background .post.op{border-width:1px!important}:root.borders-none .reply,:root.borders-none.op-background .post.op{border:0!important}.post-menu ul,img.thread-image{border-radius:0!important}:root.rounded-corners #add-theme,:root.rounded-corners #alert_div,:root.rounded-corners #link-quick-reply,:root.rounded-corners #oneechan-options,:root.rounded-corners #options_div,:root.rounded-corners #pin-settings,:root.rounded-corners #quick-reply .handle,:root.rounded-corners #quick-reply input[type=submit],:root.rounded-corners #thread_stats,:root.rounded-corners .color-picker-btn,:root.rounded-corners .options-button,:root.rounded-corners .post-hover,:root.rounded-corners .post-menu ul,:root.rounded-corners .preview-border,:root.rounded-corners .reply,:root.rounded-corners .watch-menu,:root.rounded-corners button.outline,:root.rounded-corners div.pages a.selected,:root.rounded-corners img.board_image,:root.rounded-corners img.post-image,:root.rounded-corners img.thread-image,:root.rounded-corners input,:root.rounded-corners input[value=Next],:root.rounded-corners input[value=Previous],:root.rounded-corners label.tab-label,:root.rounded-corners select,:root.rounded-corners textarea,:root.rounded-corners.op-background .post.op{border-radius:3px!important}:root.post-info.rounded-corners .reply>p.intro,:root.rounded-corners #quick-reply,:root.rounded-corners:root.vertical-qr #quick-reply .handle{border-radius:3px 3px 0 0!important}#alert_div,#header-bar.dialog,#options_div,#pin-settings,#quick-reply,#quick-reply select,.post-hover,.reply,:root.op-background .post.op,:root.vertical-qr #quick-reply .handle,fieldset,select{border-color:var(--sc-brderColor)!important}#quick-reply,#quick-reply select,.watch-menu,:root.vertical-qr #quick-reply .handle,form table th,form[name=post] table td,input,select,textarea{border:1px solid var(--sc-inputbColor)!important}#link-quick-reply,.options-button,button.outline,div.pages a.selected,input[value=Next],input[value=Previous]{border-style:solid;border-width:1px;border-color:rgb(var(--sc-mainColor-shiftM15)) rgb(var(--sc-mainColor-shiftM15)) rgb(var(--sc-mainColor-shiftM30))!important}button.outline{color:var(--sc-textColor)!important;cursor:pointer}#quick-reply input:focus,input[type=text]:focus,select:focus,textarea:focus{border:1px solid var(--sc-linkColor)!important}img.thread-image{box-shadow:0 0 5px rgba(0,0,0,.25)}#quick-reply,.watch-menu{box-shadow:1px 1px 3px rgba(0,0,0,.1)!important}div.ban{background:rgb(var(--sc-mainColor-rgb))!important;border:1px solid var(--sc-brderColor)!important}div.ban h2{background:var(--sc-headerBGColor)!important;color:var(--sc-headerColor)!important}.ban-reason-table td,.ban-reason-table th{border-color:var(--sc-brderColor)!important}.ban-reason-table th{background-color:var(--sc-headerBGColor)!important;color:var(--sc-headerColor)!important}:root.alt-spoiler span.spoiler,:root.alt-spoiler span.spoiler:not(:hover)>a{color:#fff;background:none repeat scroll 0 0 #fff}:root.alt-spoiler span.spoiler:focus,:root.alt-spoiler span.spoiler:hover{color:#000}#link-quick-reply,.boardlist,::placeholder,button,form,header h1,input,select,span,textarea{font-family:inherit!important;font-size:inherit!important}body{font-family:" + ($SS.conf["Custom Font"] ? $SS.cssQuote($SS.conf["Custom Font"]) : $SS.formatFont($SS.conf["Font Family"])) + "!important;font-size:" + $SS.conf["Font Size"] + "px!important}.post-menu{font-size:" + $SS.conf["Font Size"] + "px!important}.theme-catalog .replies>strong,p.fileinfo,span.omitted{font-size:82%!important}header h1{font-weight:400!important;font-size:" + (($SS.conf["Font Size"] < 13) ? 22 : 26) + "px!important}pre span{font-family:monospace!important;font-size:medium!important}body>.boardlist{font-size:" + ($SS.conf["Font Size"] - 1) + "px!important}@media (min-width:1280px) and (max-width:1920px){.boardlist{word-spacing:" + (($SS.conf["Font Size"] < 14) ? -1 : -2) + "px}}:root:not(.backlink-icon) p.intro .clone-mentioned a,:root:not(.backlink-icon) p.intro .mentioned a{font-size:" + $SS.conf["Backlink Font Size"] + "px!important}p.intro .clone-mentioned a.hash-link,p.intro .mentioned a.hash-link{font-size:" + ((parseInt($SS.conf["Backlink Font Size"], 10) || 10) + 2) + "px!important;margin-left:4px!important}#alert_div,#link-quick-reply,#oneechan-options,#options_div,.options-button,.tab-label,.theme-preview,a.options-button{font-size:" + (($SS.conf["Font Size"] >= 18) ? 18 : ($SS.conf["Font Size"] <= 9 ? 9 : $SS.conf["Font Size"])) + "px!important}#quick-reply .handle,#quick-reply .handle::before,#quick-reply input[type=submit],#quick-reply label,button.outline,select:not(#oneechan-options select,#add-theme select){font-size:" + $SS.conf["UI Font Size"] + "px!important}#quick-reply input[type=submit],#quick-reply label{text-transform:uppercase}#quick-reply label{overflow:hidden;padding-bottom:2px}:root.underline-disabled a{text-decoration:none!important}#thread-interactions a{text-decoration:underline}:root.underline-quotes div.body a.quotelink,:root.underline-quotes div.body a[onclick*=citeReply],:root.underline-quotes div.body a[onclick*=highlightReply],:root.underline-quotes p.intro .clone-mentioned a:not(.hash-link),:root.underline-quotes p.intro .mentioned a:not(.hash-link){text-decoration:underline!important}#oneechan-version a,a.options-button{text-decoration:none!important}.option.header .option-title,.tab-label.selected,span.name,span.subject{font-weight:" + ($SS.conf["Bitmap Font"] ? "normal" : "bold") + "!important}.tab-label:not(.selected):not(:hover){font-weight:400;opacity:.85}form table th{font-weight:700}span.omitted{font-style:" + ($SS.conf["Bitmap Font"] ? 'none' : 'italic') + "}"+($SS.conf["Sidebar Position"] !== 3 ? " :root.left-sidebar body{padding-left:306px}:root.right-sidebar body{padding-right:306px}:root.left-sidebar:not(.mini-sidebar) header,:root.left-sidebar:not(.mini-sidebar) img.board_image,:root.right-sidebar:not(.mini-sidebar) header,:root.right-sidebar:not(.mini-sidebar) img.board_image{position:fixed;margin:0}:root.left-sidebar:not(.mini-sidebar) header,:root.left-sidebar:not(.mini-sidebar) img.board_image{left:2px}:root.right-sidebar:not(.mini-sidebar) header,:root.right-sidebar:not(.mini-sidebar) img.board_image{right:2px}:root.left-sidebar:not(.mini-sidebar) img.board_image,:root.right-sidebar:not(.mini-sidebar) img.board_image{top:24px}:root.left-sidebar:not(.mini-sidebar) header,:root.right-sidebar:not(.mini-sidebar) header{top:128px;width:302px}:root.right-sidebar:not(.mini-sidebar) a.quick-reply-btn{top:230px!important}:root.left-sidebar #quick-reply{left:0!important;right:auto!important}:root.right-sidebar #quick-reply{right:0!important;left:auto!important}:root.ss-sidebar body::before{background:var(--sc-sidebar-bg);border-left:2px solid rgba(var(--sc-mainColor-rgb),.9);box-shadow:inset var(--sc-brderColor) 1px 0 0,inset var(--sc-brderColor) -1px 0 0;content:'';height:100%;width:306px;box-sizing:border-box;position:fixed;top:0;right:0;z-index:-2;pointer-events:none}:root.ss-sidebar.left-sidebar body::before{border-right:2px solid rgba(var(--sc-mainColor-rgb),.9);border-left:none!important;left:0;right:auto!important}:root.vertical-qr:root.left-sidebar #quick-reply{transform:translateX(-100%);left:0!important;right:auto!important}:root.vertical-qr:root.left-sidebar #quick-reply th{transform:rotate(90deg);transform-origin:bottom left;right:auto;left:100%}:root.mini-sidebar:root.left-sidebar body{padding-left:32px!important}:root.mini-sidebar:root.right-sidebar body{padding-right:32px!important}:root.mini-sidebar header div.subtitle{display:none}:root.mini-sidebar:root.ss-sidebar body::before{width:31px!important}:root.mini-sidebar header h1{top:72px!important;letter-spacing:-1.4px;position:fixed;margin:0;padding-top:.05em}:root.mini-sidebar:root.right-sidebar header h1{right:32px;transform-origin:top right;transform:rotate(-90deg)}:root.mini-sidebar:root.left-sidebar header h1{left:32px;transform-origin:top left;transform:rotate(90deg)}" : "")+" #quick-reply{box-shadow:none!important;border-radius:0!important;margin:0!important}#quick-reply .close-btn{padding:2px 3px 2px 4px!important}#quick-reply input[type=checkbox]{margin:0 4px 1px;vertical-align:baseline;position:relative;top:3px}#quick-reply input[type=submit]{height:25px!important;margin:0!important}form[name=post]:not(#quick-reply) input[type=submit]{height:22px!important}#quick-reply select{margin:1px 0!important}#quick-reply input[type=text]{min-width:0!important}#quick-reply .st-submit-row input[type=submit]{width:100%!important;margin-top:1px!important}:root.expand-inputs form[name=post] input[type=text]{width:100%;box-sizing:border-box}#quick-reply textarea{min-height:25px!important}:root.left-sidebar #quick-reply textarea,:root.right-sidebar #quick-reply textarea{max-width:302px!important}:root.qr-background #quick-reply,:root.qr-background #quick-reply table{background:0 0!important;border:none}:root.qr-opacity #quick-reply{opacity:.9}:root.vertical-qr #quick-reply .close-btn{display:none}:root.vertical-qr #quick-reply textarea{resize:vertical!important;z-index:1}:root.vertical-qr #quick-reply{top:auto!important;position:fixed;right:0!important;left:auto!important;bottom:0!important;transform:translateX(100%);max-width:300px!important}:root.vertical-qr #quick-reply.focus,:root.vertical-qr #quick-reply:hover{transform:translateX(0)!important}:root.qr-transition.vertical-qr #quick-reply{transition:transform .3s ease-in-out .1s!important}:root.vertical-qr #quick-reply th{display:block;position:absolute;bottom:140px;right:100%;width:max-content;min-width:105px;padding:2px 2px 4px 4px;text-align:center;cursor:default;transform:rotate(-90deg);transform-origin:bottom right;white-space:nowrap}:root.vertical-qr #quick-reply th .handle{float:none;display:inline;width:auto}:root.vertical-qr #quick-reply.focus th,:root.vertical-qr #quick-reply:hover th{opacity:0!important;transition:opacity .42s linear}:root.fade-qr #quick-reply:not(.focus):not(:hover){opacity:.2!important;transition:opacity .2s ease-in-out 1s!important}form[name=post] .cf-turnstile{margin:1px auto}#quick-reply th .handle{text-transform:uppercase}.dropzone{color:var(--sc-textColor)!important;background:var(--sc-inputColor)!important;border:1px dashed var(--sc-inputbColor)!important}.dropzone .file-hint{color:rgba(var(--sc-textColor-rgb),.5)!important}.dropzone.dragover .file-hint,.dropzone:hover .file-hint{color:var(--sc-textColor)!important}.dropzone.dragover{background:rgb(var(--sc-inputColor-hover))!important;border-color:var(--sc-linkColor)!important}:root.rounded-corners .dropzone{border-radius:3px!important}.upload-filename-wrapper{gap:2px;align-items:center}#upload_filename input[name=filename]{box-sizing:border-box}#quick-reply #emote-menu{background:var(--sc-inputColor)!important;border:1px solid var(--sc-inputbColor)!important;box-sizing:border-box!important;transition:background .2s}#quick-reply td:has(> #emote-menu){position:relative}#quick-reply td:has(> #emote-menu) input[name=subject]{display:block;width:100%!important;max-width:calc(100% - 26px)!important;box-sizing:border-box}#quick-reply td:has(> #emote-menu) #emote-menu{float:none!important;position:absolute!important;top:0!important;right:0!important;bottom:0!important;height:auto!important;width:22px!important;margin:0!important}#quick-reply #emote-menu:hover{background:rgb(var(--sc-inputColor-hover))!important}:root.rounded-corners #quick-reply #emote-menu{border-radius:3px}#quick-reply #emote-list{background:var(--sc-inputColor)!important;border:1px solid var(--sc-inputbColor)!important;box-sizing:border-box}:root.rounded-corners #quick-reply #emote-list{border-radius:3px}#quick-reply #emote-list>img:hover{background:rgb(var(--sc-inputColor-shift25))}:root.backlink-icon p.intro .clone-mentioned a:not(.hash-link),:root.backlink-icon p.intro .mentioned a:not(.hash-link){font-size:0!important;padding:" + (($SS.conf["Font Size"] < 12) ? 5 : 6) + "px!important;margin-right:0!important;opacity:.6!important;position:relative;bottom:5px;left:2px;background-image:var(--sc-icon-backlink)!important}:root.backlink-icon p.intro .clone-mentioned a:not(.hash-link):hover,:root.backlink-icon p.intro .mentioned a:not(.hash-link):hover{opacity:1!important}:root.backlink-icon p.intro .clone-mentioned a.inline-active,:root.backlink-icon p.intro .mentioned a.inline-active{background-image:var(--sc-icon-downArrow)!important;opacity:1!important}:root.use-sc-icons p.intro i.fa.fa-lock,:root.use-sc-icons p.intro i.fa.fa-thumb-tack{color:transparent!important;font-size:0!important;background-color:transparent!important;background-position:center!important;background-repeat:no-repeat;display:inline-block;height:0!important;padding-top:16px!important;text-indent:-9999px!important;vertical-align:bottom;width:16px!important}:root.use-sc-icons p.intro i.fa.fa-lock{background-image:var(--sc-icon-threadClosed)!important}:root.use-sc-icons p.intro i.fa.fa-thumb-tack{background-image:var(--sc-icon-threadPinned)!important}#StyleTowerLink{float:right;margin-left:4px}:root.use-sc-icons #StyleTowerLink{font-size:0!important}:root.use-sc-icons #StyleTowerLink a,:root.use-sc-icons .boardlist>a[title=Options]{font-size:0!important;display:inline-block;width:15px;height:15px;background-position:center;background-repeat:no-repeat;background-size:contain;vertical-align:text-bottom;opacity:.8}:root.use-sc-icons #StyleTowerLink a{background-image:var(--sc-icon-menu)}:root.use-sc-icons .boardlist>a[title=Options]{background-image:var(--sc-icon-options)}:root.use-sc-icons #StyleTowerLink a:hover,:root.use-sc-icons .boardlist>a[title=Options]:hover{opacity:1}:root.use-sc-icons #scroll-buttons img{display:none}:root.use-sc-icons #scroll-buttons a::before{content:'';display:block;width:32px;height:32px;background-image:var(--sc-icon-navArrow);background-position:center;background-repeat:no-repeat;background-size:contain;opacity:.7}:root.use-sc-icons #scroll-buttons a:hover::before{opacity:1}:root.use-sc-icons #scroll-buttons a#nav-to-top::before{transform:rotate(180deg)}:root.hl-border .post.reply,:root.op-background.hl-border .post.op{border-left:" + $SS.conf["Width Decoration"] + "px " + $SS.conf["Highlight Style"] + " rgba(var(--sc-postHLColor-rgb)," + (($SS.conf["Opacity"] || 100) / 100) + ")!important}:root.hl-border-down .post.reply,:root.op-background.hl-border-down .post.op{border-bottom:" + $SS.conf["Width Decoration"] + "px " + $SS.conf["Highlight Style"] + " rgba(var(--sc-postHLColor-rgb)," + (($SS.conf["Opacity"] || 100) / 100) + ")!important}:root.hl-outline .post.reply,:root.op-background.hl-outline .post.op{outline:" + $SS.conf["Width Decoration"] + "px " + $SS.conf["Highlight Style"] + " rgba(var(--sc-postHLColor-rgb)," + (($SS.conf["Opacity"] || 100) / 100) + ")}.post-hover{outline:2px solid rgba(var(--sc-hoverOutColor-rgb),var(--sc-hoverOutOp))!important}:root.oneechan.highlight-you .hasQuoteYou.post.op,:root.oneechan.highlight-you .hasQuoteYou.post.reply,:root.oneechan.highlight-you .quoting-you.post.op,:root.oneechan.highlight-you .quoting-you.post.reply{border-left:" + $SS.conf["Width Decoration"] + "px solid rgba(var(--sc-quotesYouHLColor-rgb)," + (($SS.conf["Opacity"] || 100) / 100) + ")!important}:root.oneechan.highlight-own .post.op.you,:root.oneechan.highlight-own .post.reply.you,:root.oneechan.highlight-own .yourPost.post.op,:root.oneechan.highlight-own .yourPost.post.reply{border-left:" + $SS.conf["Width Decoration"] + "px dashed rgba(var(--sc-ownPostHLColor-rgb)," + (($SS.conf["Opacity"] || 100) / 100) + ")!important}.reply.highlighted,.reply:target{background:rgba(var(--sc-replybgHLColor-rgb),.8)!important;outline:1px solid rgba(var(--sc-replyslctColor-rgb),.8)!important}:root.oneechan div.body a.inline-active,:root.oneechan p.intro .clone-mentioned a.inline-active,:root.oneechan p.intro .mentioned a.inline-active{color:var(--sc-linkHColor)!important;font-weight:700!important;text-decoration:underline dotted!important;opacity:.85}:root.oneechan div.body a.inline-active:hover,:root.oneechan p.intro .clone-mentioned a.inline-active:hover,:root.oneechan p.intro .mentioned a.inline-active:hover{opacity:1}.theme-catalog div.thread .replies{margin-left:5px;margin-right:5px}.theme-catalog #Grid div.thread{margin:3px 3px 0 0;border-color:rgba(var(--sc-brderColor-rgb),.6)!important;transition:background-color .15s ease-in-out,border-color .15s ease-in-out}.theme-catalog .replies>strong{color:rgba(var(--sc-textColor-rgb),.6)!important;font-weight:400!important}:root.oneechan .theme-catalog #Grid div.thread{cursor:pointer}select#image_size,select#sort_by{margin-top:4px}.theme-catalog div.threads{padding:10px 0!important}:root.catalog-justify .theme-catalog .replies{text-align:justify!important;text-align-last:center;hyphens:auto}.theme-catalog div.thread:hover{background:rgb(var(--sc-mainColor-hover))!important;border-color:var(--sc-linkColor)!important}:root.oneechan .theme-catalog #Grid div.thread:hover{background:rgb(var(--sc-mainColor-hover))!important;border-color:var(--sc-linkColor)!important}:root.catalog-background .theme-catalog #Grid div.thread{background:rgba(var(--sc-mainColor-rgb),var(--sc-replyOp))!important}:root.rounded-corners.catalog-background .theme-catalog #Grid div.thread{border-radius:3px!important}:root.catalog-background .theme-catalog .replies{margin:0 5px 5px 5px}:root.catalog-background .theme-catalog img.thread-image{margin-top:8px}:root.catalog-thumbsize .theme-catalog img.thread-image{width:150px!important;height:150px!important;max-width:none!important;max-height:none!important}:root.catalog-thumbsize .theme-catalog div.grid-size-large img.thread-image{width:250px!important;height:250px!important}:root.oneechan .theme-catalog{--catalog-header-bg:var(--sc-headerBGColor);--catalog-header-color:var(--sc-headerColor);--catalog-header-border-color:var(--sc-brderColor);--catalog-row-bg:rgba(var(--sc-mainColor-rgb), var(--sc-replyOp));--catalog-row-hover-bg:rgba(var(--sc-hoverColor-rgb), var(--sc-hoverOp));--catalog-row-color:var(--sc-textColor);--catalog-row-border-color:var(--sc-brderColor)}:root.oneechan.rounded-corners .theme-catalog{--catalog-row-radius:3px}:root.oneechan .theme-catalog .catalog-controls,:root.oneechan .theme-catalog .catalog-text-mode{width:100%!important}@media (min-width:701px){:root.oneechan .theme-catalog .catalog-text-mode .catalog-table,:root.oneechan .theme-catalog .catalog-text-mode .catalog-table tbody{display:block;width:100%}:root.oneechan .theme-catalog .catalog-text-mode .catalog-table thead{display:none}:root.oneechan .theme-catalog .catalog-text-mode .catalog-table tbody>tr:not(.catalog-row):not([hidden]),:root.oneechan .theme-catalog .catalog-text-mode .catalog-table tbody>tr:not(.catalog-row):not([hidden]) td{display:block}:root.oneechan .theme-catalog .catalog-text-mode .catalog-table tbody>tr[hidden]{display:none!important}:root.oneechan .theme-catalog .catalog-text-mode .catalog-row{display:grid;grid-template-columns:minmax(0,1fr) auto auto auto auto auto auto auto;grid-template-areas:'subject maxed sticky locked replies images id time' 'preview preview preview preview preview preview preview preview';align-items:baseline;padding:.5em .8em!important;margin-bottom:6px;background:rgba(var(--sc-mainColor-rgb),var(--sc-replyOp));border:1px solid var(--sc-brderColor);border-radius:var(--catalog-row-radius);transition:background-color .15s ease-in-out}:root.oneechan .theme-catalog .catalog-text-mode .catalog-row:hover{background:rgba(var(--sc-hoverColor-rgb),var(--sc-hoverOp))}:root.oneechan .theme-catalog .catalog-text-mode .catalog-row td{display:block;min-width:0;background:0 0!important;border:0!important;padding:0!important;text-align:left!important}:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-subject{grid-area:subject;overflow-wrap:anywhere}:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-subject a{color:var(--sc-titleColor)!important;font-weight:700;text-decoration:none}:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-subject a:hover{color:var(--sc-linkHColor)!important}:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-replies{grid-area:replies}:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-images{grid-area:images}:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-id{grid-area:id;width:8.5em}:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-time{grid-area:time;width:12.8em}:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-id,:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-images,:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-replies,:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-time{font-size:82%;white-space:nowrap;color:rgba(var(--sc-textColor-rgb),.6);font-variant-numeric:tabular-nums;margin-left:.65rem!important}:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-images,:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-replies{width:4.9em}:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-replies::before{content:'R: '}:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-images::before{content:'I: '}:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-id::before{content:'No.'}:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-id a,:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-time a{color:rgba(var(--sc-textColor-rgb),.6)!important;text-decoration:none}:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-id a:hover,:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-time a:hover{color:var(--sc-linkHColor)!important}:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-preview{grid-area:preview;margin-top:.35em!important}:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-preview .catalog-preview-content{display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden;max-height:none}:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-maxed{grid-area:maxed}:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-sticky{grid-area:sticky}:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-locked{grid-area:locked}:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-locked:empty,:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-maxed:empty,:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-sticky:empty{display:none}:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-locked,:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-maxed,:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-sticky{font-size:0!important;margin-left:.65rem!important}:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-locked::before,:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-maxed::before,:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-sticky::before{content:attr(data-label);font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.04em;color:rgba(var(--sc-textColor-rgb),.6)}:root.oneechan .theme-catalog .catalog-text-mode .catalog-cell-maxed::before{content:'MAXED'}}:root.st-home body{background:var(--sc-bgColor)!important;color:var(--sc-textColor)!important}:root.st-home #page a{color:var(--sc-linkColor)}:root.st-home #page a:hover{color:var(--sc-linkHColor)}:root.st-home #page{background:var(--sc-bgColor)!important;border-color:var(--sc-brderColor)!important;box-shadow:0 0 0 4px rgba(0,0,0,.3)!important}:root.st-home #layout,:root.st-home .main-column{background:var(--sc-bgColor)!important}:root.st-home .left-column{background:rgba(var(--sc-mainColor-rgb),var(--sc-replyOp))!important;border-color:var(--sc-brderColor)!important}:root.st-home .poll-results,:root.st-home .thread-list li,:root.st-home .window-mods .info-list li{border-color:rgba(var(--sc-brderColor-rgb),.5)!important}:root.st-home .featured-frame{background:var(--sc-inputColor)!important;border-color:var(--sc-brderColor)!important}:root.st-home .poll-button{background:rgb(var(--sc-mainColor-rgb))!important;border-color:var(--sc-inputbColor)!important;color:var(--sc-textColor)!important}:root.st-home .poll-button.secondary,:root.st-home .poll-button:hover{background:rgb(var(--sc-mainColor-shift15))!important}:root.st-home #top-banner{background:rgba(var(--sc-headerBGColor-rgb),var(--sc-navOp))!important;border-bottom-color:var(--sc-brderColor)!important}:root.st-home .top-tagline{color:var(--sc-headerColor)}:root.st-home .top-tagline-subtext{color:var(--sc-headerColor);opacity:.7}:root.st-home a.top-nav-link{background:rgb(var(--sc-mainColor-rgb))!important;border-color:var(--sc-brderColor)!important;color:var(--sc-linkColor)!important}:root.st-home a.top-nav-link:hover{background:rgb(var(--sc-mainColor-shift15))!important;color:var(--sc-linkHColor)!important}:root.st-home .side-panel{background:rgba(var(--sc-mainColor-rgb),var(--sc-replyOp))!important;border-color:var(--sc-brderColor)!important}:root.st-home a.menu-button{background:rgb(var(--sc-mainColor-rgb))!important;border-color:var(--sc-brderColor)!important;color:var(--sc-textColor)!important}:root.st-home a.menu-button:hover{background:rgb(var(--sc-mainColor-shift15))!important}:root.st-home .side-logo-copy{background-color:rgba(var(--sc-mainColor-rgb),var(--sc-replyOp))!important;border-color:var(--sc-brderColor)!important}:root.st-home .side-logo-copy-title{color:var(--sc-boardColor)!important}:root.st-home .skyline-copy-text-mode{background-color:rgba(var(--sc-mainColor-rgb),var(--sc-replyOp))!important;border-color:var(--sc-brderColor)!important}:root.st-home .friend-badge{background-color:rgb(var(--sc-mainColor-rgb))!important;border-color:var(--sc-brderColor)!important;color:var(--sc-linkColor)!important}:root.st-home .friend-badge:hover{background-color:rgb(var(--sc-mainColor-shift15))!important;color:var(--sc-linkHColor)!important}:root.st-home .friend-name,:root.st-home .panel-heading,:root.st-home .side-heading,:root.st-home .skyline-friends-title,:root.st-home .skyline-title{color:var(--sc-titleColor)!important}:root.st-home .skyline-subtitle{color:var(--sc-textColor)!important;opacity:.8}:root.st-home .skyline{background:rgba(var(--sc-mainColor-rgb),var(--sc-replyOp))!important;border-color:var(--sc-brderColor)!important}:root.st-home .skyline-right{border-color:var(--sc-brderColor)!important}:root.st-home .ticker{background:rgba(var(--sc-mainColor-rgb),var(--sc-replyOp))!important;border-color:var(--sc-brderColor)!important}:root.st-home .window{background:rgba(var(--sc-mainColor-rgb),var(--sc-replyOp))!important;border-color:var(--sc-brderColor)!important;box-shadow:2px 2px 0 rgba(0,0,0,.35)!important}:root.st-home .window-titlebar{background:rgb(var(--sc-headerBGColor-rgb))!important;color:var(--sc-headerColor)!important}:root.st-home .thread-title{color:var(--sc-linkColor)}:root.st-home .thread-meta,:root.st-home .thread-stats{opacity:.7}:root.st-home .music-player{background:rgb(var(--sc-mainColor-rgb))!important;border-color:var(--sc-brderColor)!important}:root.st-home .music-display{background:var(--sc-inputColor)!important;border-color:var(--sc-inputbColor)!important}:root.st-home .music-label{color:var(--sc-textColor);opacity:.7}:root.st-home .music-button{background:rgb(var(--sc-mainColor-rgb))!important;border-color:var(--sc-inputbColor)!important;color:var(--sc-textColor)!important}:root.st-home .music-button:hover{background:rgb(var(--sc-mainColor-shift15))!important}:root.st-home .music-seek{background:var(--sc-inputColor)!important;border-color:var(--sc-inputbColor)!important}:root.st-home .music-seek::-webkit-slider-runnable-track{background:var(--sc-inputColor)!important}:root.st-home .music-seek::-webkit-slider-thumb{background:var(--sc-textColor)!important;border-color:var(--sc-inputbColor)!important}:root.st-home .music-seek::-moz-range-track{background:var(--sc-inputColor)!important}:root.st-home .music-seek::-moz-range-thumb{background:var(--sc-textColor)!important;border-color:var(--sc-inputbColor)!important}:root.st-home .music-playlist li.active{background:rgb(var(--sc-mainColor-shift15))!important}:root.st-home #footer{background:rgba(var(--sc-mainColor-rgb),var(--sc-replyOp))!important;border-color:var(--sc-brderColor)!important;color:var(--sc-textColor)!important}:root.st-home .page-hero{background:rgba(var(--sc-mainColor-rgb),var(--sc-replyOp))!important;border-color:var(--sc-brderColor)!important}:root.st-home .page-crumbs{color:rgba(var(--sc-textColor-rgb),.7)!important;border-bottom-color:var(--sc-brderColor)!important}:root.st-home .page-crumbs-more{border-left-color:var(--sc-brderColor)!important}:root.st-home .page-title{color:var(--sc-titleColor)!important}:root.st-home .page-lead{color:rgba(var(--sc-textColor-rgb),.8)!important}:root.st-home .page-related,:root.st-home .page-toc{background:rgba(var(--sc-mainColor-rgb),var(--sc-replyOp))!important;border-color:var(--sc-brderColor)!important}:root.st-home .page-related-title,:root.st-home .page-toc-label{color:var(--sc-titleColor)!important}:root.st-home .page-toc-sep{color:rgba(var(--sc-textColor-rgb),.4)!important}:root.st-home .content-body{color:var(--sc-textColor)!important}:root.st-home .content-body h3,:root.st-home .content-body h4,:root.st-home .notice-title,:root.st-home .qa-q{color:var(--sc-titleColor)!important}:root.st-home .content-body strong{color:inherit!important}:root.st-home .content-body code,:root.st-home .example-query{background:rgba(var(--sc-codeBackground))!important;border-color:rgba(var(--sc-codeBorder))!important}:root.st-home .content-body pre code{background:0 0!important;border:0!important}:root.st-home .route-card{background:var(--sc-inputColor)!important;border-color:var(--sc-brderColor)!important}:root.st-home .answer-box,:root.st-home .notice{background:var(--sc-inputColor)!important;border-top-color:var(--sc-brderColor)!important;border-right-color:var(--sc-brderColor)!important;border-bottom-color:var(--sc-brderColor)!important}:root.st-home .answer-box{border-left-color:var(--sc-titleColor)!important}:root.st-home .example-note,:root.st-home .route-card-text{color:rgba(var(--sc-textColor-rgb),.8)!important}:root.st-home .content-table caption{color:rgba(var(--sc-textColor-rgb),.7)!important}:root.st-home .content-table td,:root.st-home .content-table th{border-color:rgba(var(--sc-brderColor-rgb),.5)!important}:root.st-home .content-table thead th{background:rgba(var(--sc-textColor-rgb),.1)!important;color:var(--sc-titleColor)!important}:root.st-home .content-table tbody tr:nth-child(2n) td{background:rgba(var(--sc-textColor-rgb),.05)!important}:root.st-home .example-list li,:root.st-home .qa-item{border-bottom-color:rgba(var(--sc-brderColor-rgb),.5)!important}:root.st-home .page-updated{color:rgba(var(--sc-textColor-rgb),.6)!important}#styletower-notifications{position:fixed;top:38px;right:10px;z-index:65;width:min(320px,calc(100vw - 20px));display:flex;flex-direction:column;gap:6px;pointer-events:none}.styletower-notification{pointer-events:auto;cursor:pointer;padding:7px 10px;border:1px solid;border-left-width:3px;border-radius:3px;box-shadow:rgba(0,0,0,.25) 0 2px 8px;opacity:0;transform:translateY(-4px);transition:opacity .15s ease,transform .15s ease;overflow-wrap:anywhere;font-size:12px;line-height:1.35;min-height:10px}.styletower-notification.visible{opacity:1;transform:translateY(0)}.styletower-notification.closing{opacity:0;transform:translateY(-4px)}.styletower-notification-text{pointer-events:none}.styletower-notification-text a{pointer-events:auto}#styletower-notifications .styletower-notification{color:var(--sc-textColor)!important;background:rgb(var(--sc-mainColor-rgb))!important;border-color:rgb(var(--sc-brderColor-rgb))!important;border-left-color:var(--sc-linkColor)!important}#styletower-notifications .styletower-notification-info{border-left-color:#6f8fb3!important}#styletower-notifications .styletower-notification-warning{border-left-color:#c7a85a!important}#styletower-notifications .styletower-notification-error{border-left-color:#c06b6b!important}#styletower-notifications .styletower-notification-success{border-left-color:var(--sc-quoteColor)!important}:root.ts-notifs #notification_container{position:fixed;top:38px;right:10px;left:auto;z-index:65;width:min(320px,calc(100vw - 20px));display:flex;flex-direction:column;gap:6px}:root.ts-notifs #notification_container .message_notification{margin:0!important;padding:0!important;background:0 0!important;border:none!important;width:auto!important}:root.ts-notifs #notification_container .notification_div{cursor:pointer;padding:7px 10px!important;border:1px solid rgb(var(--sc-brderColor-rgb))!important;border-left:3px solid var(--sc-linkColor)!important;border-radius:3px;box-shadow:rgba(0,0,0,.25) 0 2px 8px;overflow-wrap:anywhere;font-size:12px;line-height:1.35;min-height:10px;color:var(--sc-textColor)!important;background:rgb(var(--sc-mainColor-rgb))!important}:root.ts-notifs #notification_container .notification_div a.notification_close{float:right;margin-left:6px;color:var(--sc-linkColor)!important}:root.ts-notifs #notification_container .notification_div .alert_message{display:inline;margin:0!important;padding:0!important}"+($SS.conf["Center Notifications"] ? "#styletower-notifications{right:auto;left:50%;transform:translateX(-50%);width:min(500px,calc(100vw - 20px))}.ts-notifs #notification_container{right:auto!important;top:30px!important;left:50%!important;transform:translateX(-50%)!important;width:min(480px,calc(100vw - 20px))!important}" : "")+" "+($SS.conf["Full Border"] ? "#styletower-notifications .styletower-notification,.ts-notifs #notification_container .notification_div{border:" + $SS.conf["Width Decoration"] + "px " + $SS.conf["Highlight Style"] + "!important}#styletower-notifications .styletower-notification-info{border-color:#6f8fb3!important}#styletower-notifications .styletower-notification-warning{border-color:#c7a85a!important}#styletower-notifications .styletower-notification-error{border-color:#c06b6b!important}#styletower-notifications .styletower-notification-success{border-color:var(--sc-quoteColor)!important}" : "")+" "+($SS.conf["Style Scrollbars"] ? ":root{scrollbar-color:var(--sc-titleColor) var(--sc-bgColor)}#emote-list,.field{scrollbar-color:var(--sc-textColor) var(--sc-inputColor)}" : "")+" "+($SS.conf["Style Scrollbars"] && $SS.conf["Thin Scrollbars"] ? "*{scrollbar-width:thin}" : "")+" #add-theme,#oneechan-options{border:0!important;position:fixed;margin:auto}#oneechan-options{min-width:30em;max-width:45%;text-align:left!important;height:65vh;max-height:100em;top:0;bottom:0;left:0;right:0;box-shadow:rgba(0,0,0,.6) 0 0 10px!important;padding:.4em .4em 2.7em .4em}#options-container{padding:3px;box-shadow:inset rgba(0,0,0,.3) 0 0 5px;border-radius:5px}#options-container,.options-section{height:100%}.options-section{overflow-y:auto;overflow-x:hidden}#main-section .option,#mascot-section .option,#misc-section .option{display:block;border-top:1px solid rgba(0,0,0,.1);height:1.7em;padding:0 .45em}#main-section .option[hidden],#mascot-section .option[hidden],#misc-section .option[hidden]{display:none!important}#main-section>.option:nth-of-type(2n),#mascot-section>.option:nth-of-type(2n),#misc-section>.option:nth-of-type(2n){background:var(--sc-mainColor-shiftM5)!important}#main-section .buttons-container+.option,#mascot-section .buttons-container+.option{border-top:none!important}.option-title{line-height:1.7em}#main-section .option:first-child,#mascot-section .option:first-child,#misc-section .option:first-child{border-top:0!important}#main-section .option:last-child,#mascot-section .option:last-child,#misc-section .option:last-child{border-bottom:0!important}#main-section input,#main-section select,#mascot-section .option>input,#misc-section input,#misc-section select{float:right!important}#main-section input[type=checkbox],#mascot-section .option>input[type=checkbox],#misc-section input[type=checkbox]{float:left!important;margin-right:5px!important}.suboption::before{border-bottom:1px solid rgba(0,0,0,.1);border-left:1px solid rgba(0,0,0,.1);content:'';display:inline-block;margin-right:2px;height:50%;width:6px}.suboption{padding-left:16px!important}.option.header{cursor:auto!important}.option.header.has-subsections .option-title::after{content:' ▾';font-size:.7em}.theme-preview{cursor:default}.theme-preview a.pv-link{color:var(--pv-link)!important}.theme-preview a.pv-link:hover{color:var(--pv-linkh)!important}.theme-preview blockquote{margin:12px 40px!important}#themes-section .reply{padding:2px!important;position:relative;text-align:left;width:99.4%;border-radius:0!important}.theme-buttons-container{bottom:4px;right:2px;margin:0;opacity:0;position:absolute;z-index:3}.theme-preview:hover .theme-buttons-container{opacity:1}.theme-buttons-container>a{display:inline-block;margin:0 2px;padding:2px 5px;text-align:center;width:50px;border-radius:3px}.theme-preview .selected-label{bottom:-5px;font-size:32px!important;margin:0!important;opacity:0;position:absolute;right:300px;transition:opacity .3s,right .3s}.theme-preview.selected .selected-label{opacity:1;right:3px;z-index:1}.theme-preview-post{flex-shrink:0;margin-bottom:8px;background:var(--sc-mainColor);font-size:11px;line-height:1.4;cursor:default;text-align:left;border-bottom:1px solid var(--sc-brderColor);padding-bottom:12px;box-shadow:0 9px 15px -12px rgba(0,0,0,.25)}.theme-preview-post .preview-border{display:block;border:1px solid var(--sc-brderColor);padding:6px;cursor:pointer}.theme-preview-post .preview-border:hover{outline:1px dashed var(--sc-linkColor)}.theme-preview-post [data-color]{cursor:pointer;transition:outline .1s}.theme-preview-post [data-color]:hover{outline:1px dashed var(--sc-linkColor)}.preview-name{color:var(--sc-nameColor);font-weight:700}.preview-trip{color:var(--sc-tripColor)}.preview-subject{color:var(--sc-titleColor);font-weight:700}.preview-quote{color:var(--sc-quoteColor)}.preview-backlink{color:var(--sc-blinkColor)}.preview-date{color:var(--sc-textColor);font-size:10px}.preview-postnum .preview-link{color:var(--sc-linkColor)}.preview-link{text-decoration:underline;cursor:pointer}.theme-preview-post .theme-preview-hover{display:block;margin:8px 4px 8px 14px;padding:6px;background:rgba(var(--sc-hoverColor-rgb),var(--sc-hoverOp));outline:2px solid rgba(var(--sc-hoverOutColor-rgb),var(--sc-hoverOutOp));cursor:pointer;font-size:11px}.theme-body{flex:1 1 auto;min-height:0;overflow-y:auto}.side-switch{position:absolute;top:4px;right:8px;cursor:pointer;font-size:16px;opacity:.5;z-index:1}.side-switch:hover{opacity:1}#add-theme{padding:20px!important;position:fixed;top:0;right:0;left:auto;max-height:100vh;height:calc(100vh - 2.2em);max-width:45vw;overflow:hidden;text-align:left!important;box-sizing:border-box;display:flex;flex-direction:column;gap:6px;margin:2em .2em!important;box-shadow:-2px 0 12px rgba(0,0,0,.3)!important}#add-theme.left{right:auto;left:0;box-shadow:2px 0 12px rgba(0,0,0,.3)}#add-theme.left .side-switch{right:auto;left:8px}#add-theme .option-title{float:left;flex-shrink:0;padding-left:5px;padding-right:8px;min-width:120px}#add-theme .theme-fields>label{line-height:22px;display:flex;justify-content:space-between;align-items:center;width:100%;padding:2px 4px;box-sizing:border-box;border:1px solid transparent}#add-theme .theme-fields>label:nth-child(2n){background:rgba(var(--sc-mainColor-shiftM16),.35)}#add-theme .theme-fields>label.picked{outline:1px dashed var(--sc-linkColor);outline-offset:-2px}#add-theme .theme-fields>label>input[type=text],#add-theme .theme-fields>label>select{width:auto;max-width:100%;appearance:auto;text-align:left}#add-theme .theme-body{flex:0 1 auto;min-height:0;max-height:calc(85vh - 90px);overflow-y:auto;scrollbar-width:none}#add-theme .theme-body::-webkit-scrollbar{display:none}#add-theme .theme-body>label#customCSS{width:100%;display:flex;flex-direction:column;min-height:0;text-align:left}#add-theme .theme-body>label#customCSS>textarea{width:100%;max-width:100%;min-height:5em;height:clamp(4em,24vh,34vh);max-height:48vh;flex:0 1 auto;box-sizing:border-box;resize:vertical;overflow-y:auto;font-family:monospace}.color-picker-wrap{display:inline-flex;align-items:center;vertical-align:middle;gap:2px;margin-top:3px}#add-theme .color-hex{width:60px;height:20px;text-align:center;border:1px solid var(--sc-inputbColor)!important;border-radius:2px;outline:0;box-sizing:content-box;font-family:monospace;font-size:11px;background:0 0}.color-picker-btn{width:24px;height:24px;padding:0;border:1px solid var(--sc-inputbColor)!important;cursor:pointer;box-sizing:border-box;background:0 0}.color-picker-btn::-webkit-color-swatch-wrapper{padding:0}.color-picker-btn::-webkit-color-swatch{border:none}:root.rounded-corners #add-theme .color-hex,:root.rounded-corners .color-picker-btn{border-radius:3px!important}#add-theme>div{margin-top:.6em;text-align:left}#add-theme>.theme-buttons{flex:0 0 auto;margin-top:0;text-align:right;border-top:1px solid var(--sc-brderColor);padding-top:6px;box-shadow:0 -10px 12px -12px rgba(0,0,0,.25)}#options-tabs{list-style:none;margin:0;padding:0;position:absolute;top:-24px;left:-1px}.tab-item{float:left;margin:0;padding:0}.tab-label{display:block;height:16px;margin:0 1px;padding:5px;text-align:center;width:75px;transition:all .1s ease-in-out}#overlay{position:fixed;top:0;left:0;right:0;bottom:0;width:100%;height:100%;z-index:99!important;background-color:rgba(0,0,0,.3)!important}#overlay2{background:rgba(0,0,0,.1)!important;position:fixed;top:0;left:0;height:100%;width:100%;text-align:center;z-index:125!important}#overlay2::before{content:'';display:inline-block;height:100%;vertical-align:middle}#overlay.previewing{display:none}#overlay.previewing~#overlay2{background-color:rgba(0,0,0,0)!important}.buttons-container{bottom:3px;left:5px;right:5px;display:flex;justify-content:space-between;align-items:center;position:absolute;z-index:100;margin:0}.btn-center{text-align:center;flex:1}.btn-right{margin-left:auto}.options-button{display:inline-block;line-height:1.4em;margin:0 .15em;min-width:3em;padding:.15em .75em;text-align:center;cursor:pointer}#import-link{line-height:1.7em;overflow:hidden;position:relative;float:left;height:1.85em!important;margin-top:-.15em;padding-top:.15em}#import-settings{position:relative;overflow:hidden;vertical-align:bottom}#import-settings>.import-input{left:0}.import-input{position:absolute;opacity:0;cursor:pointer}label.option>input[type=checkbox]{margin:.3em .15em 0!important}.option>input[type=text],span.option>select{width:125px}#oneechan-options input[type=text],#oneechan-options select{max-height:1.55em;margin-top:0!important;padding:0 .25em!important}#oneechan-options textarea{background:0 0!important;border:0!important;height:100%!important;width:100%!important;resize:none}#oneechan-version{opacity:.7;font-size:x-small!important}.link-delim{opacity:.4}[data-tower-status]>.option-title::after,label.tab-label[data-tower-status]::after{display:inline-block;margin-left:6px;padding:0 5px;border-radius:8px;font-size:9px;font-weight:700;letter-spacing:.04em;line-height:14px;vertical-align:middle;white-space:nowrap}[data-tower-status=added]>.option-title::after,label.tab-label[data-tower-status=added]::after{content:'Tower';color:#fff;background:#3fb950}[data-tower-status=changed]>.option-title::after,label.tab-label[data-tower-status=changed]::after{content:'changed';color:#1a1a1a;background:#d29922}#mascot-section .option.mascot-gallery-wrap{height:auto!important;padding:4px 6px!important;overflow:visible}#mascot-section .option.mascot-gallery-wrap::before{display:none!important}.mascot-controls{display:flex;align-items:center;gap:4px;margin:2px 0 6px}.mascot-hint{opacity:.6;font-size:x-small;margin-left:6px}.mascot-gallery{display:grid;grid-template-columns:repeat(auto-fill,minmax(104px,1fr));gap:8px;padding:2px 0 6px}.mascot-empty{opacity:.6;font-style:italic;padding:8px 2px}.mascot-tile{position:relative;border:1px solid var(--sc-inputbColor);padding:4px 4px 2px;cursor:pointer;text-align:center;opacity:.5}.mascot-tile.selected{opacity:1;border-color:var(--sc-linkColor);box-shadow:0 0 3px var(--sc-linkColor)}:root.rounded-corners .mascot-tile{border-radius:3px}.mascot-tile img{max-width:100%;height:96px;object-fit:contain;display:block;margin:0 auto;pointer-events:none}.mascot-tile-name{display:block;font-size:11px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding-top:2px}.mascot-tile-btns{position:absolute;top:2px;right:2px;display:none}.mascot-tile:hover .mascot-tile-btns{display:block}.mascot-tile-btns a{display:inline-block;min-width:16px;padding:0 3px;cursor:pointer;background:rgb(var(--sc-mainColor-rgb));border:1px solid var(--sc-inputbColor);margin-left:2px;text-decoration:none!important}.mascot-tile-btns a:hover{border-color:var(--sc-linkColor)}.option>a.options-button{float:right;margin-top:.15em}.st-nav-status{float:right;opacity:.6;margin-right:.6em;line-height:1.7em}#st-nav-editor .mascot-hint{display:block;margin:0 0 6px}#add-mascot,#st-nav-editor{display:inline-block;vertical-align:middle;text-align:left;padding:8px 10px;min-width:340px;max-width:440px;max-height:92vh;overflow-y:auto;border:0!important;box-shadow:rgba(0,0,0,.6) 0 0 10px!important}#add-mascot:not(.advanced) .adv-only{display:none!important}#add-mascot.advanced .simple-only{display:none!important}#add-mascot .mascot-mode-row{border-bottom:1px solid rgba(128,128,128,.35);padding-bottom:4px;margin-bottom:6px!important}#add-mascot .mascot-mode-row .option-title{font-weight:700}#add-mascot select.mascot-input{height:auto!important;flex:none;width:auto!important}#add-mascot .mascot-filter-head,#st-nav-editor .mascot-filter-head{border-bottom:1px solid rgba(128,128,128,.35);margin-top:8px!important;opacity:.8}#add-mascot .mascot-filter-head .option-title,#st-nav-editor .mascot-filter-head .option-title{width:auto;font-weight:700}:root.rounded-corners #add-mascot,:root.rounded-corners #st-nav-editor{border-radius:3px!important}#add-mascot .add-mascot-label,#st-nav-editor .add-mascot-label{display:flex;align-items:center;gap:6px;margin:4px 0}#add-mascot .add-mascot-label>.option-title,#st-nav-editor .add-mascot-label>.option-title{width:125px;flex:none}#add-mascot .mascot-input{flex:1;min-width:0;height:20px!important;width:auto!important;float:none!important}#add-mascot .mascot-clip-inputs{display:flex;flex:1;gap:3px}#add-mascot .mascot-clip{width:34px!important;flex:1;text-align:center}#add-mascot .mascot-scale-row{gap:4px}#add-mascot .mascot-scale-btn{min-width:0;margin:0;padding:0 .5em;line-height:18px;flex:none;user-select:none}#add-mascot .mascot-scale-reset{margin-left:6px}#add-mascot input.mascot-scale-pct{margin:0 0 0 2px}#add-mascot .mascot-scale-row .mascot-opacity-val{min-width:0}#add-mascot input[type=range].mascot-opacity,#st-nav-editor input[type=range].mascot-opacity{flex:1;width:auto}#add-mascot .mascot-opacity-num,#st-nav-editor .mascot-opacity-num{width:60px;height:20px;flex:none;text-align:right;box-sizing:border-box}#add-mascot .mascot-opacity-val,#st-nav-editor .mascot-opacity-val{width:auto;min-width:1.4em;text-align:left;flex:none}#mascot-buttons-container,#st-nav-buttons-container{text-align:right;margin-top:8px}input[type=range].mascot-opacity{width:64px;float:none!important;margin:0!important;padding:0!important;height:20px;appearance:none;background:0 0}input[type=range].mascot-opacity::-webkit-slider-runnable-track{height:4px;background:rgba(0,0,0,.2);border-radius:2px}input[type=range].mascot-opacity::-webkit-slider-thumb{-webkit-appearance:none;width:12px;height:12px;border-radius:50%;background:var(--sc-textColor);margin-top:-4px;cursor:pointer}input[type=range].mascot-opacity::-moz-range-track{height:4px;background:rgba(0,0,0,.2);border-radius:2px;border:none}input[type=range].mascot-opacity::-moz-range-thumb{width:12px;height:12px;border-radius:50%;background:var(--sc-textColor);border:none;cursor:pointer}.mascot-opacity-val{width:30px;font-size:11px;text-align:right;line-height:20px;margin-right:.3em}:root.rounded-corners .mascot-input,:root.rounded-corners .mascot-opacity-val{border-radius:3px!important}:root.rounded-corners input[type=range],:root.rounded-corners input[type=range]::-moz-range-track,:root.rounded-corners input[type=range]::-webkit-slider-runnable-track{border-radius:3px!important}:root.rounded-corners input[type=range]::-moz-range-thumb,:root.rounded-corners input[type=range]::-webkit-slider-thumb{border-radius:50%!important}#oneechan-options input[type=range].mascot-opacity{float:right!important}#oneechan-options .mascot-opacity-val{float:right;margin-right:.8em}";

            // Rewriting the sheet re-parses it and restyles the page even
            // when the text is the same, which it is for every live change
            // that only flips root classes or theme variables
            if (!reload)
                $(getDocHead()).append($("<style type='text/css' id=ch4SS>").text(css));
            else if (css !== $SS._lastCSS)
                $("#ch4SS").text(css);
            $SS._lastCSS = css;

            // The theme's custom CSS gets its own element: a syntax slip in
            // it (an unclosed brace) must not swallow the rest of our
            // stylesheet, and sitting after it lets the theme's rules win ties
            var custom = document.getElementById("sc-custom-css");
            if (!custom) {
                custom = document.createElement("style");
                custom.id = "sc-custom-css";
                var main = document.getElementById("ch4SS");
                if (main && main.parentNode) main.parentNode.insertBefore(custom, main.nextSibling);
                else (document.head || document.documentElement).appendChild(custom);
            }
            var customCSS = ($SS.theme && $SS.theme.customCSS) || "";
            if (custom.textContent !== customCSS) custom.textContent = customCSS;

            $SS.disableSiteTheme();
        },
        disableSiteTheme: function () {
            // localStorage.stylesheet is set purely so the site pre-paints in a
            // matching light/dark style before this script runs (flashbang
            // mitigation). Once our CSS is inserted the site theme (e.g.
            // tomorrow.css with its blue-grey replies) must stop competing.
            document.querySelectorAll("link#stylesheet").forEach(function (l) {
                if (l.disabled && l.media === "none") return; // already off
                l.onload = null;
                l.media = "none";
                l.disabled = true;
            });
        },
        setThemeVariables: function () {
            var t = $SS.theme;
            if (!t || t.hidden) return;
            var sidebarBgOpacity = !t.mainColor.isLight ? ".9" : ".2",
                hoverRGB = t.hoverColor ? t.hoverColor.rgb : t.mainColor.shiftRGB(-16),
                hoverOutRGB = t.hoverOutColor ? t.hoverOutColor.rgb : t.linkColor.rgb,
                // A fixed-attachment body background is repainted on every
                // scroll frame; such an image goes on the fixed pseudo-element
                // in Colors.css (:root::before) instead, with the attachment
                // dropped since the element itself never scrolls
                bg = t.bgImg.get(),
                bgFixed = / fixed$/.test(bg),
                css = ":root{" +
                // The disabled site theme used to declare this; without it
                // native widgets (scrollbars, checkboxes, select dropdowns)
                // render light-mode on dark themes
                "color-scheme:" + (t.bgColor.isLight ? "light" : "dark") + ";" +
                "--sc-textColor:" + t.textColor.hex + ";" +
                "--sc-textColor-rgb:" + t.textColor.rgb + ";" +
                "--sc-nameColor:" + t.nameColor.hex + ";" +
                "--sc-tripColor:" + t.tripColor.hex + ";" +
                "--sc-linkColor:" + t.linkColor.hex + ";" +
                "--sc-linkHColor:" + t.linkHColor.hex + ";" +
                "--sc-headerColor:" + t.headerColor.hex + ";" +
                "--sc-headerLColor:" + t.headerLColor.hex + ";" +
                "--sc-headerLHColor:" + t.headerLHColor.hex + ";" +
                "--sc-quoteColor:" + t.quoteColor.hex + ";" +
                "--sc-titleColor:" + t.titleColor.hex + ";" +
                "--sc-boardColor:" + t.boardColor.hex + ";" +
                "--sc-blinkColor:" + t.blinkColor.hex + ";" +
                "--sc-qlColor:" + t.qlColor.hex + ";" +
                "--sc-bgColor:" + t.bgColor.hex + ";" +
                "--sc-mainColor:" + t.mainColor.hex + ";" +
                "--sc-mainColor-rgb:" + t.mainColor.rgb + ";" +
                "--sc-mainColor-shiftM30:" + t.mainColor.shiftRGB(-30) + ";" +
                "--sc-mainColor-shiftM16:" + t.mainColor.shiftRGB(-16) + ";" +
                "--sc-mainColor-shiftM15:" + t.mainColor.shiftRGB(-15) + ";" +
                "--sc-mainColor-shiftM10:" + t.mainColor.shiftRGB(-10) + ";" +
                "--sc-mainColor-shiftM5:" + t.mainColor.shiftRGB(-5) + ";" +
                "--sc-mainColor-shift4:" + t.mainColor.shiftRGB(4) + ";" +
                "--sc-mainColor-hover:" + t.mainColor.shiftRGB(18, true) + ";" +
                "--sc-mainColor-shift10:" + t.mainColor.shiftRGB(10) + ";" +
                "--sc-mainColor-shift15:" + t.mainColor.shiftRGB(15) + ";" +
                "--sc-brderColor:" + t.brderColor.hex + ";" +
                "--sc-brderColor-rgb:" + t.brderColor.rgb + ";" +
                "--sc-inputColor:" + t.inputColor.hex + ";" +
                "--sc-inputColor-shift25:" + t.inputColor.shiftRGB(25) + ";" +
                "--sc-inputColor-hover:" + t.inputColor.hover + ";" +
                "--sc-inputbColor:" + t.inputbColor.hex + ";" +
                "--sc-headerBGColor:" + t.headerBGColor.hex + ";" +
                "--sc-headerBGColor-rgb:" + t.headerBGColor.rgb + ";" +
                "--sc-headerBGColor-shift15:" + t.headerBGColor.shiftRGB(15) + ";" +
                "--sc-unreadColor-rgb:" + t.unreadColor.rgb + ";" +
                "--sc-threadHLColor-rgb:" + t.threadHLColor.rgb + ";" +
                "--sc-hoverColor-rgb:" + hoverRGB + ";" +
                "--sc-hoverOp:" + t.hoverOp + ";" +
                "--sc-hoverOutColor-rgb:" + hoverOutRGB + ";" +
                "--sc-hoverOutOp:" + t.hoverOutOp + ";" +
                "--sc-postHLColor-rgb:" + t.postHLColor.rgb + ";" +
                "--sc-quotesYouHLColor-rgb:" + t.quotesYouHLColor.rgb + ";" +
                "--sc-ownPostHLColor-rgb:" + t.ownPostHLColor.rgb + ";" +
                "--sc-replybgHLColor-rgb:" + t.replybgHLColor.rgb + ";" +
                "--sc-replyslctColor-rgb:" + t.replyslctColor.rgb + ";" +
                "--sc-codeBackground:" + t.codeBackground + ";" +
                "--sc-codeBorder:" + t.codeBorder + ";" +
                "--sc-replyOp:" + t.replyOp + ";" +
                "--sc-navOp:" + t.navOp + ";" +
                "--sc-sidebar-bg:rgba(" + t.mainColor.shiftRGB(-18) + "," + sidebarBgOpacity + ");" +
                "--sc-bgImg:" + (bgFixed ? "none" : bg) + ";" +
                "--sc-bgImgFixed:" + (bgFixed ? bg.replace(/ fixed$/, "") : "none") + ";" +
                "--sc-icon-backlink:url(\"data:image/svg+xml," + t.icons.backlink + "\");" +
                "--sc-icon-downArrow:url(\"data:image/svg+xml," + t.icons.downArrow + "\");" +
                "--sc-icon-navArrow:url(\"data:image/svg+xml," + t.icons.navArrow + "\");" +
                "--sc-icon-threadClosed:url(\"data:image/svg+xml," + t.icons.threadClosed + "\");" +
                "--sc-icon-threadPinned:url(\"data:image/svg+xml," + t.icons.threadPinned + "\");" +
                "--sc-icon-menu:url(\"data:image/svg+xml," + t.icons.menuIcon.replace("currentColor", "rgb(" + t.headerLColor.rgb + ")") + "\");" +
                "--sc-icon-options:url(\"data:image/svg+xml," + t.icons.options + "\");" +
                // Styling hooks exposed by Holotower TS
                "--subtle-border-color:" + t.brderColor.hex + ";" +
                "--inline-background-color:rgba(" + hoverRGB + "," + t.hoverOp + ");" +
                "--reply-background-color:rgba(" + t.mainColor.rgb + "," + t.replyOp + ");" +
                "--ts-hover-color:" + t.linkHColor.hex + ";" +
                "--link-hover-color:" + t.linkHColor.hex + ";" +
                "--text-color-muted:rgba(" + t.textColor.rgb + ",.5);" +
                "--error-text-color:#c06b6b;" +
                "--highlight-color:rgba(" + t.replyslctColor.rgb + ",.8)" +
                "}" +
                // Out-cascades htsu-style's per-site-theme var overrides (e.g. .tomorrow{--ts-hover-color})
                ":root.oneechan{--ts-hover-color:" + t.linkHColor.hex + ";--ts-mentioned-hover-color:" + t.linkHColor.hex + ";--ts-post-no-hover-color:" + t.linkHColor.hex + "}" +
                ($SS.conf && $SS.conf["QR Button Image"] ?
                    "a.quick-reply-btn img{display:none}" +
                    "a.quick-reply-btn::before{content:'';display:block;width:64px;height:64px;" +
                    "background:url('" + String($SS.conf["QR Button Image"]).replace(/['"\s()]/g, "") + "') center/contain no-repeat}"
                    : "");
            var el = document.getElementById("sc-theme-vars");
            if (!el) {
                el = document.createElement("style");
                el.id = "sc-theme-vars";
                (document.head || document.documentElement).appendChild(el);
            }
            // Unchanged variables (a live change elsewhere) are left alone:
            // rewriting them restyles the whole page and has TS re-sample
            if (el.textContent === css) return;
            el.textContent = css;
            // Holotower TS samples post/link colors from computed styles and caches
            // them in its own vars (--ts-link-color etc.); it re-samples on the
            // site's style-loaded event, so fire it whenever the theme changes
            clearTimeout($SS._styleLoadedTimer);
            $SS._styleLoadedTimer = setTimeout(function () {
                try { window.dispatchEvent(new Event("style-loaded")); } catch (e) {}
            }, 50);
        },
        /* 100-character cap on the name/subject fields, flashing the border
           when it is hit (the QR is a fresh clone each time it opens) */
        limitNameSubject: function (root) {
            $("input[name=subject], input[name=name]", root).each(function () {
                if (this._stLimited) return;
                this._stLimited = true;
                this.setAttribute("maxlength", "100");
                this.addEventListener("input", function () {
                    if (this.value.length >= 100) {
                        this.style.setProperty("border-color", "red", "important");
                        var el = this;
                        setTimeout(function () { el.style.removeProperty("border-color"); }, 600);
                    }
                });
            });
        },
        /* The site's ↑ ↓ navigation buttons (navbuttons.js builds
           #scroll-buttons on thread pages, fixed at right:20px bottom:35px
           as a flex row): a stored Nav Buttons setting overrides scale,
           offsets, spacing and order */
        navButtonDefaults: { scale: 100, x: 20, y: 35, gap: 0, reverse: false },
        navButtonSettings: function () {
            var raw = $SS.conf["Nav Buttons"], s;
            if (!raw) return null;
            try { s = JSON.parse(raw); } catch (e) { return null; }
            if (!s || typeof s !== "object") return null;
            var d = $SS.navButtonDefaults,
                num = function (v, f) { var n = parseInt(v, 10); return isNaN(n) ? f : n; };
            return { scale: num(s.scale, d.scale), x: num(s.x, d.x), y: num(s.y, d.y), gap: num(s.gap, d.gap), reverse: s.reverse === true };
        },
        applyNavButtons: function (s) {
            var box = document.getElementById("scroll-buttons");
            if (!box) return;
            if (s === undefined) s = $SS.navButtonSettings();
            var d = $SS.navButtonDefaults;
            if (!s) {
                // Back to what navbuttons.js set inline
                box.classList.remove("st-nav-custom");
                box.style.right = d.x + "px";
                box.style.bottom = d.y + "px";
                box.style.left = "";
                box.style.top = "";
                box.style.transform = "";
                box.style.transformOrigin = "";
                box.classList.remove("st-nav-reversed");
                box.style.removeProperty("--st-nav-gap");
                return;
            }
            box.classList.add("st-nav-custom");
            box.style.right = s.x + "px";
            box.style.bottom = s.y + "px";
            box.style.left = "auto";
            box.style.top = "auto";
            box.style.transform = s.scale !== 100 ? "scale(" + (s.scale / 100) + ")" : "";
            box.style.transformOrigin = "bottom right";
            // Swap the two buttons with CSS order: reversing the flex axis
            // also changes how the row packs and spaces its items
            box.classList.toggle("st-nav-reversed", s.reverse);
            box.style.setProperty("--st-nav-gap", s.gap + "px");
        },
        initNavButtons: function () {
            if (!$SS.location.reply) return;
            if (document.getElementById("scroll-buttons")) { $SS.applyNavButtons(); return; }
            if ($SS._navWait) return;
            $SS._navWait = true;
            $.waitFor("#scroll-buttons", function () { $SS.applyNavButtons(); });
        },
        getActiveFileInput: function () {
            return document.querySelector("#quick-reply input[type=file]") ||
                document.querySelector("form[name='post'] input[type=file]");
        },
        moveOPFiles: function (root) {
            // vichan puts the OP file block outside div.post.op; move it inside
            // (matching reply structure) so backgrounds and borders wrap the OP.
            var scope = root && root.querySelectorAll ? root : document;
            scope.querySelectorAll(".thread > .files").forEach(function (files) {
                var op = files.parentNode.querySelector(":scope > .post.op");
                if (op) op.insertBefore(files, op.firstChild);
            });
        },
        tidyFileInfo: function (root) {
            // Drop vichan's leading "File: " label so the file line matches
            // the 4chan layout (filename, size, dimensions, links). Site scripts
            // may wrap the line in a span, so look inside one level.
            var scope = root && root.querySelectorAll ? root : document;
            scope.querySelectorAll("p.fileinfo").forEach(function (p) {
                var n = p.firstChild;
                if (n && n.nodeType === 1 && n.tagName === "SPAN") n = n.firstChild;
                if (n && n.nodeType === 3 && /^\s*File:\s*$/.test(n.nodeValue)) n.remove();
            });
        },
        moveOmittedSpans: function (root) {
            // 4chan renders the "N posts omitted" summary between the OP block
            // and the replies on the page background; vichan nests it inside
            // .post.op, where the OP background swallows it (or float layout
            // spits it out under tall OPs). Hoist it to the thread level for a
            // consistent 4chan-style line. expand.js's listeners survive the
            // move, and its own thread-scoped selectors still find the span.
            var scope = root && root.querySelectorAll ? root : document;
            scope.querySelectorAll(".post.op > span.omitted:not(.hide-expanded)").forEach(function (span) {
                var op = span.parentNode,
                    thread = op.parentNode;
                if (thread && thread.classList && thread.classList.contains("thread"))
                    thread.insertBefore(span, op.nextSibling);
            });
        },
        /* Grid catalog cards: a click anywhere in a card opens its thread.
           Real links inside the card, text selection and modified clicks
           stay untouched; Ctrl+click follows the platform convention
           (background tab). */
        initCatalogCards: function () {
            if (!$SS.location.catalog || $SS._catalogCardsInit) return;
            $SS._catalogCardsInit = true;

            document.addEventListener("click", function (e) {
                var card = e.target.closest ? e.target.closest(".theme-catalog #Grid div.thread") : null;
                if (!card || e.target.closest("a")) return;
                if (e.shiftKey || e.altKey || e.metaKey) return;
                var sel = window.getSelection && window.getSelection();
                if (sel && String(sel).length) return;
                var link = card.querySelector("a[href]");
                if (!link) return;
                if (e.ctrlKey) {
                    if (typeof GM_openInTab !== "undefined") GM_openInTab(link.href, { active: false });
                    else { try { window.open(link.href, "_blank"); } catch (er) {} }
                    return;
                }
                location.href = link.href;
            });
        },
        /* TS inline quoting: mark the originals of currently-inlined posts.
           TS removes its containers from the DOM on collapse, so container
           presence == inlined. TS only adds its own iq-hidden-post class
           when its Hide Inlined Posts setting is on; this mark exists
           either way so the faded style can apply when TS is not hiding */
        syncInlinedMarks: function () {
            var inlined = {};
            document.querySelectorAll(".inline-quote-container[data-inlined-id]").forEach(function (c) {
                inlined[c.getAttribute("data-inlined-id")] = true;
            });
            document.querySelectorAll(".post.st-inlined").forEach(function (p) {
                var id = (p.id || "").replace(/^(?:reply_|op_)/, "");
                // Clones (hover previews, inlined copies) never keep the mark
                if (!inlined[id] || p.closest(".inline-quote-container") || p.classList.contains("post-hover"))
                    p.classList.remove("st-inlined");
            });
            for (var k in inlined) {
                var el = document.getElementById("reply_" + k) || document.getElementById("op_" + k);
                if (el && !el.closest(".inline-quote-container"))
                    el.classList.add("st-inlined");
            }
        },
        /* Sibling-positional pseudo-classes (:nth-child, :nth-last-child) on
           the thread's posts would make the browser re-resolve every post in
           the thread each time a child is inserted or removed -- and TS
           inserts its hidden .post.dummy beside the quoting post on every
           quote hover, post-hover.js parks fetched posts, the updater
           appends. The classes those selectors drove are kept by hand
           instead, from one walk over the thread's children: st-last-reply
           on the last real reply and st-last-post on an OP with no real post
           after it (both drop the trailing margin), st-even on every second
           real reply (Recolor Even Replies; marked only while the option is
           on, its rule is gated on the root class either way). Hover
           clones, TS's dummy and posts the site fetched and parked hidden
           are neither counted nor marked. Called with no argument for every
           thread on the page */
        syncThreadMarks: function (thread) {
            if (!thread || !thread.nodeType) {
                document.querySelectorAll(".thread").forEach($SS.syncThreadMarks);
                return;
            }
            var even = $SS.conf["Recolor Even Replies"] === true,
                mark = function (el, cls, on) {
                    if (el.classList.contains(cls) !== on) el.classList.toggle(cls, on);
                },
                replies = 0, lastReply = null, lastPost = null, op = null, el, cl;
            for (el = thread.firstElementChild; el; el = el.nextElementSibling) {
                cl = el.classList;
                if (!cl.contains("post") || cl.contains("post-hover") || cl.contains("dummy") || cl.contains("hidden")) continue;
                lastPost = el;
                if (cl.contains("reply")) {
                    if (even) mark(el, "st-even", ++replies % 2 === 0);
                    mark(el, "st-last-reply", false);
                    lastReply = el;
                } else if (cl.contains("op")) op = el;
            }
            if (lastReply) mark(lastReply, "st-last-reply", true);
            if (op) mark(op, "st-last-post", lastPost === op);
        },
        initIndexPostHiding: function () {
            // The site's post-filter.js only exposes per-post hiding through
            // the post menu (▶ → Hide post) and gives OPs a bare [–] link,
            // while TS's one-click hide buttons are thread-page only. Recreate
            // those buttons on the index by proxying the site controls, so all
            // hide state stays in the site's own filter storage.
            var doc = document,
                minusIcon = '<span class="hide-icon"><svg xmlns="http://www.w3.org/2000/svg" class="minus" viewBox="0 0 448 512"><path d="M64 80c-8.8 0-16 7.2-16 16V416c0 8.8 7.2 16 16 16H384c8.8 0 16-7.2 16-16V96c0-8.8-7.2-16-16-16H64zM0 96C0 60.7 28.7 32 64 32H384c35.3 0 64 28.7 64 64V416c0 35.3-28.7 64-64 64H64c-35.3 0-64-28.7-64-64V96zM152 232H296c13.3 0 24 10.7 24 24s-10.7 24-24 24H152c-13.3 0-24-10.7-24-24s10.7-24 24-24z" fill="currentColor"/></svg></span>',
                plusIcon = '<span class="show-icon"><svg xmlns="http://www.w3.org/2000/svg" class="plus" viewBox="0 0 448 512"><path d="M64 80c-8.8 0-16 7.2-16 16V416c0 8.8 7.2 16 16 16H384c8.8 0 16-7.2 16-16V96c0-8.8-7.2-16-16-16H64zM0 96C0 60.7 28.7 32 64 32H384c35.3 0 64 28.7 64 64V416c0 35.3-28.7 64-64 64H64c-35.3 0-64-28.7-64-64V96zM200 344V280H136c-13.3 0-24-10.7-24-24s10.7-24 24-24h64V168c0-13.3 10.7-24 24-24s24 10.7 24 24v64h64c13.3 0 24 10.7 24 24s-10.7 24-24 24H248v64c0 13.3-10.7 24-24 24s-24-10.7-24-24z" fill="currentColor"/></svg></span>';

            function postHidden(post) {
                // post-filter.js hides via jQuery .hide() on the child blocks
                var body = post.querySelector(":scope > .body");
                return body != null && body.style.display === "none";
            }
            function syncBtn(btn, post) {
                var hidden = postHidden(post);
                btn.innerHTML = hidden ? plusIcon : minusIcon;
                btn.classList.toggle("st-hidden", hidden);
                post.classList.toggle("st-index-hidden", hidden);
            }
            function proxyMenu(post, wantUnhide) {
                // Drive the site's own menu items so persistence and refresh
                // behavior stay entirely post-filter's
                var menuBtn = post.querySelector("a.post-btn");
                if (!menuBtn) return;
                var rootCl = doc.documentElement.classList;
                rootCl.add("st-menu-silent");
                try {
                    menuBtn.click();
                    var item = doc.querySelector(".post-menu li#filter-menu-" + (wantUnhide ? "unhide" : "hide") + ":not(.hidden)");
                    if (item) item.click();
                } finally {
                    $(".post-menu", doc).each(function () { this.remove(); });
                    $(".post-btn-open", doc).each(function () { this.classList.remove("post-btn-open"); });
                    rootCl.remove("st-menu-silent");
                }
            }
            function makeButton(post) {
                var btn = doc.createElement("a");
                btn.className = "reply hide-button st-index-hide";
                btn.href = "javascript:void(0)";
                btn.setAttribute("for", post.id);
                post._stHideBtn = btn;
                syncBtn(btn, post);
                post.parentNode.insertBefore(btn, post);
                return btn;
            }
            function addReplyButton(post) {
                if (post._stHideBtn || !post.id) return;
                var btn = makeButton(post);
                btn.addEventListener("click", function (e) {
                    e.preventDefault();
                    proxyMenu(post, postHidden(post));
                    syncBtn(btn, post);
                });
            }
            function addOPButton(op) {
                if (op._stHideBtn || !op.id) return;
                var btn = makeButton(op);
                btn.classList.add("st-thread-hide");
                btn.addEventListener("click", function (e) {
                    e.preventDefault();
                    // post-filter's own [–] quick-toggle (hidden by our CSS)
                    var link = op.querySelector("a.hide-thread-link");
                    if (link) link.click();
                    setTimeout(function () { syncBtn(btn, op); }, 0);
                });
            }
            $SS.addIndexHideButtons = function (root) {
                if (root && root.matches && root.matches(".post.reply")) {
                    if (root.parentNode && root.parentNode.classList &&
                        root.parentNode.classList.contains("thread"))
                        addReplyButton(root);
                    return;
                }
                var scope = root && root.querySelectorAll ? root : doc;
                scope.querySelectorAll(".thread > .post.reply").forEach(addReplyButton);
                scope.querySelectorAll(".thread > .post.op").forEach(addOPButton);
            };
            $SS.addIndexHideButtons();
            // post-filter applies stored hides around the same time we build
            // the buttons; resync once it has settled
            var resync = function () {
                $("a.st-index-hide", doc).each(function () {
                    var post = doc.getElementById(this.getAttribute("for"));
                    if (post && this.parentNode) syncBtn(this, post);
                });
            };
            setTimeout(resync, 800);
            // Collapsing expanded replies removes the posts; drop the orphaned
            // buttons and restore the omitted line expand.js only re-shows
            // inside the OP
            doc.addEventListener("click", function (e) {
                var t = e.target.closest && e.target.closest("span.hide-expanded");
                if (!t) return;
                var thread = t.closest(".thread");
                setTimeout(function () {
                    $("a.st-index-hide", doc).each(function () {
                        var post = doc.getElementById(this.getAttribute("for"));
                        if (!post || !post.isConnected) this.remove();
                    });
                    if (thread)
                        thread.querySelectorAll(":scope > span.omitted").forEach(function (s) {
                            s.style.display = "";
                        });
                }, 0);
            }, true);
        },
        initIndexNav: function () {
            // 4chan-X-style index control row above the post form: nav links
            // built from destinations the site actually has, a reload link with
            // a loaded-N-minutes-ago label, and a client-side OP search that
            // filters the threads on the loaded page. Bump-order/paged controls
            // are server-side on 4chan and have no tower backend, so no row for
            // them here.
            if (document.getElementById("st-index-nav")) return;
            var doc = document,
                anchor = doc.querySelector("form[name=post]:not(#quick-reply)") ||
                    doc.querySelector("form[name=postcontrols]");
            if (!anchor) return;

            var nav = doc.createElement("div");
            nav.id = "st-index-nav";

            function addLink(text, href, onclick) {
                var a = doc.createElement("a");
                a.textContent = text;
                a.href = href;
                if (onclick) a.addEventListener("click", onclick);
                nav.appendChild(a);
                return a;
            }
            addLink("Catalog", "/" + $SS.location.board + "/catalog.html");
            addLink("Archive", "https://archive.holotower.org/");
            addLink("Bottom", "javascript:void(0)", function (e) {
                e.preventDefault();
                window.scrollTo(0, doc.documentElement.scrollHeight);
            });
            addLink("Refresh", "javascript:void(0)", function (e) {
                e.preventDefault();
                location.reload();
            });

            var age = doc.createElement("span");
            age.id = "st-index-age";
            age.textContent = "just now";
            nav.appendChild(age);
            var loadedAt = Date.now();
            setInterval(function () {
                var m = Math.round((Date.now() - loadedAt) / 60000);
                age.textContent = m < 1 ? "just now" : m + " min ago";
            }, 60000);

            var search = doc.createElement("input");
            search.type = "text";
            search.id = "st-index-search";
            search.placeholder = "Search OPs…";
            search.addEventListener("input", function () {
                var q = search.value.trim().toLowerCase();
                // class-based hiding only: post-hover keeps its own inline-
                // hidden thread clones that must not be revealed on clear
                doc.querySelectorAll("div[id^='thread_']").forEach(function (t) {
                    var show = true;
                    if (q) {
                        var op = t.querySelector(".post.op");
                        show = (op ? op.textContent : t.textContent).toLowerCase().indexOf(q) !== -1;
                    }
                    t.classList.toggle("st-search-hidden", !show);
                });
            });
            nav.appendChild(search);

            anchor.parentNode.insertBefore(nav, anchor);
        },
        replaceThumbnails: function (root) {
            if (!$SS.conf["Replace Thumbnails"]) return;
            var formatConf = {
                gif: "Replace GIF", jpg: "Replace JPG", jpeg: "Replace JPG",
                png: "Replace PNG", webp: "Replace WEBP",
                webm: "Replace WEBM/MP4", mp4: "Replace WEBM/MP4"
            };
            var scope = root && root.querySelectorAll ? root : document;
            // Clones (hover previews, inline expansions) keep the video they
            // copied; it needs re-arming
            $SS.armClonedVideos(scope);
            scope.querySelectorAll(".file > a > img.post-image").forEach(function (img) {
                // Never build a second player inside a clone: the original
                // was already processed and its processed markers are JS
                // properties that cloning strips
                if (img.closest(".post-hover, .inline-cloned-post")) return;
                var href = img.parentNode.href || "";
                // Video thumbs link to the site player, with the actual file
                // in the v= parameter
                var pm = href.match(/\/player\.php\?[^#]*?\bv=([^&#]+)/);
                if (pm) {
                    try { href = decodeURIComponent(pm[1]); } catch (er) { href = pm[1]; }
                }
                var ext = (href.match(/\.([a-z0-9]+)(?:[?#]|$)/i) || [])[1];
                ext = ext && ext.toLowerCase();
                if (!ext || !formatConf[ext] || !$SS.conf[formatConf[ext]]) return;
                // Leave spoiler/deleted placeholder thumbs alone
                if (/\/static\//.test(img.getAttribute("src") || "")) return;
                if (img.classList.contains("full-image")) return;
                if (ext === "webm" || ext === "mp4") {
                    // Video thumbnail: the site's expand-video.js binds its
                    // click on the original img, so keep it (hidden via the
                    // st-video-thumb class) and forward clicks to it
                    if (img._scVideoThumb) return;
                    img._scVideoThumb = true;
                    // div.file: the player link itself carries class="file"
                    var file = img.closest("div.file");
                    var video = document.createElement("video");
                    video.className = "st-thumb-video";
                    video.src = href;
                    video.muted = true;
                    video.loop = true;
                    // No autoplay: playback is viewport-driven, and the
                    // observer's initial callback starts visible ones
                    video.playsInline = true;
                    // As attributes too: hover/inline previews clone this
                    // element, and cloning keeps attributes, not properties
                    video.setAttribute("muted", "");
                    video.setAttribute("loop", "");
                    video.setAttribute("playsinline", "");
                    // Playback is viewport-driven, so nothing loads until then
                    video.preload = "none";
                    video.setAttribute("preload", "none");
                    video.style.width = img.style.width || (img.width ? img.width + "px" : "");
                    video.style.height = img.style.height || (img.height ? img.height + "px" : "");
                    img.parentNode.insertBefore(video, img.nextSibling);
                    $SS._videoThumbCount++;
                    $SS.observeThumbVideo(video);
                    if (file) file.classList.add("st-video-thumb");
                    video.addEventListener("click", function (e) {
                        e.preventDefault();
                        e.stopPropagation();
                        img.click();
                    });
                    // Player open/close is tracked by the shared observers
                    // (syncVideoThumb) rather than one observer per thumb
                    $SS.watchThumbAttributes();
                    return;
                }
                if (img._scFullSrc) return; // done on an earlier pass
                // The full-size file loads only once the post nears the
                // viewport (the thumb stays on screen until it does) rather
                // than every image on the page at once, and decodes off the
                // frame: scrolling, and a hover clone of an off-screen post
                // (post-hover.js copies the attributes along), would
                // otherwise wait on a multi-megapixel decode before painting
                img.setAttribute("loading", "lazy");
                img.setAttribute("decoding", "async");
                img._scFullSrc = href;
                $SS.assertThumbSrc(img);
                // A lazy loader may overwrite the src with a placeholder and
                // later its cached static thumb; the shared attribute observer
                // re-asserts the full source whenever it changes away from it
                $SS.watchThumbAttributes();
            });
        },
        assertThumbSrc: function (img) {
            if (img._scFullSrc && !img.classList.contains("full-image") && img.src !== img._scFullSrc)
                img.src = img._scFullSrc;
        },
        /* Hover previews and TS's inline clones copy a replaced video thumb
           along with the post. Cloning keeps attributes, not property state,
           so the copy is muted and looped again (an unmuted clone would play
           sound) and handed to the viewport observer, which plays it while
           the preview is visible. Nothing to do until a loop video exists */
        armClonedVideos: function (root) {
            if (!$SS._videoThumbCount || !root.querySelectorAll) return;
            var vids = root.matches && root.matches("video.st-thumb-video") ? [root] : root.querySelectorAll("video.st-thumb-video");
            for (var i = 0; i < vids.length; ++i) {
                var v = vids[i];
                if (v._stCloneArmed || !v.closest(".post-hover, .inline-cloned-post")) continue;
                v._stCloneArmed = true;
                v.muted = true;
                v.loop = true;
                v.playsInline = true;
                $SS.observeThumbVideo(v);
            }
        },
        /* Follow Cursor: puts the current quote preview beside the cursor, on
           the roomier side, inside the viewport. Coalesced to one run per
           frame: the size read forces a layout of the preview after the
           site's own left/top writes, so it happens once per frame rather
           than once per mousemove. Only left is written: the site sets left
           on every move, and a right value alongside it would over-constrain
           the box and reflow the whole preview twice a frame */
        placeHover: function () {
            if (!$SS.conf["Follow Cursor"] || $SS._mouseX == null || $SS._placing) return;
            $SS._placing = true;
            requestAnimationFrame(function () {
                $SS._placing = false;
                var img = $SS._hoverEl;
                if (!img || !img.isConnected) return;
                var de = document.documentElement,
                    cw = de.clientWidth, ch = de.clientHeight,
                    x = $SS._mouseX, y = $SS._mouseY,
                    h = img.offsetHeight, w = img.offsetWidth,
                    onLeft = x <= cw / 2,
                    marginX = Math.min((onLeft ? x : cw - x) + 45, cw - w);
                img.style.position = "fixed";
                img.style.right = "";
                img.style.top = Math.max(0, y * (ch - h) / ch) + "px";
                img.style.left = (onLeft ? marginX : cw - w - marginX) + "px";
            });
        },
        /* Shows the looping stand-in only while the site's expanded player
           (a div > video it drops beside the thumb) is absent or hidden */
        syncVideoThumb: function (el) {
            var file = el && el.closest ? el.closest("div.file.st-video-thumb") : null;
            if (!file) return;
            var video = file.querySelector("video.st-thumb-video");
            if (!video) return;
            var expanded = false;
            file.querySelectorAll("div > video").forEach(function (v) {
                if (v !== video && v.parentNode.style.display !== "none") expanded = true;
            });
            video.style.display = expanded ? "none" : "";
            if (expanded) { try { video.pause(); } catch (er) {} }
            else if (video._stInView !== false) { try { video.play(); } catch (er) {} }
        },
        /* One attribute observer for every replaced thumb: src rewrites by
           the lazy loader, and style toggles on the expanded player wrapper */
        watchThumbAttributes: function () {
            if ($SS._thumbAttrObserver) return;
            $SS._thumbAttrObserver = new MutationObserver(function (mutations) {
                for (var i = 0; i < mutations.length; i++) {
                    var t = mutations[i].target;
                    if (mutations[i].attributeName === "src") {
                        // Our own write reports here too; only a foreign
                        // value needs the re-assert timer
                        if (t._scFullSrc && t.src !== t._scFullSrc) setTimeout($SS.assertThumbSrc, 60, t);
                    } else if ($SS._videoThumbCount)
                        $SS.syncVideoThumb(t);
                }
            });
            $SS._thumbAttrObserver.observe(getDocBody(), { attributes: true, attributeFilter: ["src", "style"], subtree: true });
        },
        /* Playing videos hold a display wake lock and decode continuously,
           so thumbnail videos only play while actually in the viewport: a
           shared IntersectionObserver starts them as they scroll in (its
           initial callback covers the on-load autoplay for visible ones)
           and pauses them once out of view. The expanded-player logic keeps
           its own display:none pause; its collapse resume checks _stInView
           so a collapsed-offscreen video stays paused. */
        observeThumbVideo: function (video) {
            if (!$SS._thumbVideoIO) {
                $SS._thumbVideoIO = new IntersectionObserver(function (entries) {
                    entries.forEach(function (entry) {
                        var v = entry.target;
                        v._stInView = entry.isIntersecting;
                        if (entry.isIntersecting) {
                            if (v.style.display !== "none") { try { v.play(); } catch (e) {} }
                        } else {
                            try { v.pause(); } catch (e) {}
                        }
                    });
                }, { rootMargin: "100px" });
            }
            $SS._thumbVideoIO.observe(video);
        },
        initImageConvertOnDrop: function () {
            var MAX_BYTES = $SS.location.maxFileSize;

            function notify(msg) {
                $SS.notify({
                    type: 'success',
                    content: msg,
                    lifetime: 5
                });
            }

            // Hands a file to the input and replays the events the site's
            // listeners missed while ours held the original change
            function pass(file, input) {
                try {
                    var dt = new DataTransfer();
                    dt.items.add(file);
                    input.files = dt.files;
                    input.dispatchEvent(new Event("input", { bubbles: true }));
                    input.dispatchEvent(new Event("change", { bubbles: true }));
                } catch (err) { console.warn("Failed to hand the file back:", err); }
                input._scConverting = false;
            }

            // Only raster images go through the canvas; videos, PDFs and
            // files with no MIME type are the site's business
            function isConvertible(file) {
                return /^image\//.test(file.type) && file.type !== "image/gif" && file.type !== "image/svg+xml";
            }

            function convertToJPEG(file, baseName, qrInput) {
                createImageBitmap(file).then(function (bitmap) {
                    var canvas = document.createElement("canvas"),
                        w = bitmap.width, h = bitmap.height,
                        maxDim = $SS.maxImageDim,
                        outName = baseName + ".jpg",
                        wasResized = false,
                        qualities = [0.99, 0.95, 0.90, 0.85, 0.80, 0.75, 0.70, 0.60, 0.50, 0.40, 0.30, 0.20, 0.10, 0.05, 0.01];

                    if (w > maxDim || h > maxDim) {
                        var scale = Math.min(maxDim / w, maxDim / h);
                        w = Math.round(w * scale);
                        h = Math.round(h * scale);
                        wasResized = true;
                    }
                    canvas.width = w;
                    canvas.height = h;
                    canvas.getContext("2d").drawImage(bitmap, 0, 0, w, h);
                    bitmap.close();

                    function emitFile(blob, q) {
                        var converted = new File([blob], outName, { type: "image/jpeg" });
                        var dt = new DataTransfer();
                        dt.items.add(converted);
                        qrInput.files = dt.files;
                        qrInput.dispatchEvent(new Event("input", { bubbles: true }));
                        qrInput.dispatchEvent(new Event("change", { bubbles: true }));
                        var msg = "Converted " + file.name + " to " + outName + " (q=" + Math.round(q * 100) + "%)";
                        if (wasResized) msg += ", resized to " + w + "x" + h;
                        notify(msg);
                        qrInput._scConverting = false;
                    }

                    function tryQuality(index) {
                        var q = qualities[index];
                        canvas.toBlob(function (blob) {
                            if (blob.size <= MAX_BYTES || index === qualities.length - 1) {
                                emitFile(blob, q);
                            } else {
                                tryQuality(index + 1);
                            }
                        }, "image/jpeg", q);
                    }

                    tryQuality(0);
                }).catch(function (err) {
                    console.warn("Image conversion failed:", err);
                    // The selection was cleared for the conversion: put the
                    // original back rather than lose the upload
                    pass(file, qrInput);
                });
            }

            function shouldConvert(file) {
                if (file.type === "image/jpeg" || file.type === "image/png") return file.size > MAX_BYTES;
                return true;
            }

            function findQRFileInput() {
                return $SS.getActiveFileInput();
            }

            function clearSelectedFile(input) {
                try {
                    input.files = new DataTransfer().files;
                } catch (err) { console.warn("Failed to clear file:", err); }
            }

            function checkAndConvert(file, input) {
                var baseName = file.name.replace(/\.[^.]+$/, "");

                if (shouldConvert(file)) {
                    clearSelectedFile(input);
                    convertToJPEG(file, baseName, input);
                    return;
                }

                var maxDim = $SS.maxImageDim;

                createImageBitmap(file).then(function (bitmap) {
                    var tooBig = bitmap.width > maxDim || bitmap.height > maxDim;
                    bitmap.close();
                    if (tooBig) {
                        clearSelectedFile(input);
                        convertToJPEG(file, baseName, input);
                    } else
                        pass(file, input);
                }).catch(function (err) {
                    console.warn("Image dimension check failed:", err);
                    pass(file, input);
                });
            }

            // File picker: intercept change on the QR input
            function changeHandler(e) {
                var input = e.target;
                if (input._scConverting) return;
                if (input.type !== "file") return;
                if (!input.closest("#quick-reply, form[name='post']")) return;
                var file = input.files && input.files[0];
                if (!file || !isConvertible(file)) return;

                e.stopImmediatePropagation();
                input._scConverting = true;
                checkAndConvert(file, input);
            }
            window.addEventListener("change", changeHandler, true);
            $SS._scChangeHandler = changeHandler;

            // Drag and drop
            function dropHandler(e) {
                var files = e.dataTransfer && e.dataTransfer.files;
                if (!files || !files.length) return;

                var file = files[0];
                if (!isConvertible(file)) return;

                // Find the active file input (quick reply or main form)
                var qrInput = findQRFileInput();
                if (!qrInput) return;

                e.preventDefault();
                e.stopPropagation();

                qrInput._scConverting = true;
                checkAndConvert(file, qrInput);
            }
            window.addEventListener("drop", dropHandler, true);
            $SS._scDropHandler = dropHandler;
        },
        getNotificationRoot: function () {
            var root = document.getElementById('styletower-notifications');

            if (root) return root;
            if (!getDocBody()) return null;

            root = document.createElement('div');
            root.id = 'styletower-notifications';
            root.setAttribute('aria-live', 'polite');
            root.setAttribute('aria-atomic', 'true');

            getDocBody().appendChild(root);
            return root;
        },
        dismissNotification: function (node) {
            if (!node || node.dataset.closing === 'true') return;

            node.dataset.closing = 'true';
            node.classList.add('closing');

            setTimeout(function () {
                if (node.parentNode)
                    node.parentNode.removeChild(node);
            }, 180);
        },
        notify: function (detail) {
            var root, note, text, lifetime;

            if ($SS.conf && !$SS.conf["Toast Notifications"])
                return;

            if (typeof detail === 'string')
                detail = { content: detail };

            if (!detail || !detail.content)
                return;

            root = $SS.getNotificationRoot();
            if (!root) {
                return setTimeout(function () {
                    $SS.notify(detail);
                }, 25);
            }

            note = document.createElement('div');
            text = document.createElement('div');
            lifetime = detail.lifetime === undefined ? 4 : detail.lifetime;

            note.className = 'styletower-notification styletower-notification-' + (detail.type || 'info');
            note.setAttribute('role', 'status');
            note.setAttribute('tabindex', '0');
            note.title = 'Dismiss';

            text.className = 'styletower-notification-text';
            if (typeof detail.content === 'string')
                text.textContent = detail.content;
            else
                text.appendChild(detail.content);
            note.appendChild(text);

            note.addEventListener('click', function (e) {
                if (e.target.closest('a'))
                    return;
                $SS.dismissNotification(note);
            });
            note.addEventListener('keydown', function (e) {
                if (e.target.closest && e.target.closest('a'))
                    return;
                if (e.key === "Enter" || e.key === "Escape") {
                    e.preventDefault();
                    $SS.dismissNotification(note);
                }
            });

            root.appendChild(note);
            if (root.childElementCount > 4)
                $SS.dismissNotification(root.firstElementChild);

            setTimeout(function () {
                note.classList.add('visible');
            }, 0);

            if (lifetime > 0) {
                setTimeout(function () {
                    $SS.dismissNotification(note);
                }, lifetime * 1000);
            }
            return note;
        },
        initRememberComment: function () {
            if (!$SS.conf["Remember Comment Draft"]) return;
            $SS.handleFormNode();
        },
        getRememberCommentPrefix: function () {
            return NAMESPACE + "RememberComment:";
        },
        getRememberCommentKey: function () {
            // /board/res/N.html and /board/res/N+50.html are the same thread
            var thread = $SS.getThreadId(),
                where = thread ? $SS.location.board + "/res/" + thread :
                    location.pathname.replace(/index\.html$/, "");
            return $SS.getRememberCommentPrefix() + where;
        },
        getRememberCommentExpiry: function () {
            return 24 * 60 * 60 * 1000;
        },
        saveRememberedComment: function (storageKey, text) {
            var val = JSON.stringify({ text: text, savedAt: Date.now() });
            if ($SS.hasGM) { try { GM_setValue(storageKey, val); } catch (e) {} }
            else { try { localStorage.setItem(storageKey, val); } catch (e) {} }
            $SS.cleanupRememberedComments();
        },
        clearRememberedComment: function () {
            var key = $SS.getRememberCommentKey();
            if ($SS.hasGM) { try { GM_deleteValue(key); } catch (e) {} }
            try { localStorage.removeItem(key); } catch (e) {}
        },
        cleanupRememberedComments: function () {
            var prefix;
            try { prefix = $SS.getRememberCommentPrefix(); } catch (e) { return; }
            if (!prefix) return;
            var keptEntries = [];
            var i, key, entry, keys = {}, allKeys;

            if ($SS.hasGM) {
                try { allKeys = GM_listValues(); for (i = 0; i < allKeys.length; i++) { if (allKeys[i].indexOf(prefix) === 0) keys[allKeys[i]] = true; } } catch (e) {}
            }
            try { for (i = 0; i < localStorage.length; i++) { key = localStorage.key(i); if (key && key.indexOf(prefix) === 0) keys[key] = true; } } catch (e) {}

            allKeys = Object.keys(keys);
            for (i = 0; i < allKeys.length; i++) {
                entry = $SS.loadRememberedComment(allKeys[i]);
                if (!entry) continue;
                keptEntries.push({ key: allKeys[i], savedAt: entry.savedAt });
            }

            keptEntries.sort(function (a, b) { return b.savedAt - a.savedAt; });
            keptEntries.slice(10).forEach(function (entry) {
                if ($SS.hasGM) { try { GM_deleteValue(entry.key); } catch (e) {} }
                try { localStorage.removeItem(entry.key); } catch (e) {}
            });
        },
        loadRememberedComment: function (storageKey) {
            var rawValue, parsedValue;
            if ($SS.hasGM) { try { rawValue = GM_getValue(storageKey); } catch (e) {} }
            if (!rawValue) { try { rawValue = localStorage.getItem(storageKey); } catch (e) { return null; } }
            if (!rawValue) return null;

            try { parsedValue = JSON.parse(rawValue); } catch (error) {
                if ($SS.hasGM) { try { GM_deleteValue(storageKey); } catch (e) {} }
                try { localStorage.removeItem(storageKey); } catch (e) {}
                return null;
            }

            if (!parsedValue || typeof parsedValue.text !== "string" || typeof parsedValue.savedAt !== "number") {
                if ($SS.hasGM) { try { GM_deleteValue(storageKey); } catch (e) {} }
                try { localStorage.removeItem(storageKey); } catch (e) {}
                return null;
            }

            if (Date.now() - parsedValue.savedAt > $SS.getRememberCommentExpiry()) {
                if ($SS.hasGM) { try { GM_deleteValue(storageKey); } catch (e) {} }
                try { localStorage.removeItem(storageKey); } catch (e) {}
                return null;
            }

            return parsedValue;
        },
        bindRememberComment: function (qrNode) {
            if (!qrNode || !$SS.conf["Remember Comment Draft"]) return;
            if (qrNode._rememberCommentBound) return;

            var commentField = qrNode.querySelector("textarea");
            var formNode = qrNode.querySelector("form") || qrNode.closest("form");
            var storageKey = $SS.getRememberCommentKey();
            var saveTimer = null;
            var savedDraft;

            if (!commentField) return;

            savedDraft = $SS.loadRememberedComment(storageKey);
            if (savedDraft && !commentField.value) {
                commentField.value = savedDraft.text;
                commentField.dispatchEvent(new Event("input", { bubbles: true }));
            }

            function queueSave() {
                clearTimeout(saveTimer);
                saveTimer = setTimeout(function () {
                    if (commentField.value.trim())
                        $SS.saveRememberedComment(storageKey, commentField.value);
                    else
                        $SS.clearRememberedComment();
                }, $SS.draftDelay);
            }

            function clearSavedComment() {
                clearTimeout(saveTimer);
                $SS.clearRememberedComment();
            }

            commentField.addEventListener("input", queueSave);
            if (formNode)
                formNode.addEventListener("submit", clearSavedComment, true);
            qrNode.addEventListener("click", function (e) {
                var submitNode = e.target.closest("input[type=submit], button[type=submit]");
                if (submitNode)
                    clearSavedComment();
            });

            qrNode._rememberCommentBound = true;
        },
        handleFormNode: function (form) {
            if (!form) {
                document.querySelectorAll("#quick-reply, form[name='post']").forEach($SS.handleFormNode);
                return;
            }
            if ($SS.conf["Remember Comment Draft"]) {
                $SS.bindRememberComment(form);
            }
            if ($SS.conf["Watch Thread on Reply"]) {
                form.querySelectorAll("input[type=submit]").forEach(function (btn) {
                    if (!btn._watchThreadBound) {
                        btn.addEventListener("click", $SS.watchThread);
                        btn._watchThreadBound = true;
                    }
                });
            }
            var spoiler = form.querySelector("input[name=spoiler]");
            if (spoiler && !spoiler.title) spoiler.title = "Spoiler image";
            if ($SS.conf["Auto-Convert Images"] && $SS._scChangeHandler) {
                var fi = form.querySelector("input[type=file]");
                if (fi && !fi._scHooked) {
                    fi._scHooked = true;
                    fi.addEventListener("change", $SS._scChangeHandler, true);
                }
                if (!form._scDropHooked) {
                    form._scDropHooked = true;
                    form.addEventListener("drop", $SS._scDropHandler, true);
                }
            }
        },
        toggleAutohideQR: function () {
            // All three autohide styles expand on the .focus class (maintained
            // by initNativeQRAutohide's focus delegation), so showing = focus
            // the comment box and hiding = blur it
            var qr = document.getElementById("quick-reply");
            if (!qr || qr.style.display === "none") {
                var btn = document.querySelector("a.quick-reply-btn");
                if (btn) btn.click();
                qr = document.getElementById("quick-reply");
                if (qr && qr.style.display === "none") qr.style.display = "";
            }
            if (!qr) return;
            if (qr.classList.contains("focus")) {
                var active = document.activeElement;
                if (active && qr.contains(active)) active.blur();
                qr.classList.remove("focus");
            } else {
                var body = qr.querySelector("textarea[name=body]");
                if (body) body.focus();
                else qr.classList.add("focus");
            }
        },
        initNativeQRAutohide: function () {
            // The quick reply is recreated each time it opens, so use delegation
            document.addEventListener("focusin", function (e) {
                var qr = e.target.closest && e.target.closest("#quick-reply");
                if (qr) qr.classList.add("focus");
            });
            document.addEventListener("focusout", function (e) {
                var qr = e.target.closest && e.target.closest("#quick-reply");
                if (!qr || qr.contains(e.relatedTarget)) return;
                // Decide once focus has settled: a file picker (or another
                // window) taking the window's focus fires focusout too, but
                // the field stays the document's active element, and the
                // form should stay open for the pick
                setTimeout(function () {
                    var active = document.activeElement;
                    if (!qr.isConnected || !active || !qr.contains(active))
                        qr.classList.remove("focus");
                });
            });
        },
        localJSON: {
            get: function (key) {
                try { return JSON.parse(localStorage.getItem(key)); } catch (e) { return null; }
            },
            set: function (key, data) {
                try { localStorage.setItem(key, JSON.stringify(data)); } catch (e) {}
            }
        },
        getThreadId: function () {
            var pathname = window.location.pathname.slice(1).split("/");
            if (pathname[1] !== "res") return null;
            return (pathname[2] || "").replace(/(?:\+\d+)?\.html$/, "") || null;
        },
        getOwnPosts: function (board) {
            var posts = $SS.localJSON.get("own_posts") || {};
            return posts[board] || [];
        },
        watchThread: function () {
            if (!$SS.conf["Watch Thread on Reply"] || !$SS.location.reply) return;
            try {
                var board = $SS.location.board,
                    threadId = $SS.getThreadId();
                if (!board || !threadId) return;
                var watchData = $SS.localJSON.get("watch_js") || {};
                var bc = watchData[board] || {};
                bc.threads = bc.threads || {};
                bc.slugs = bc.slugs || {};
                if (!bc.threads[threadId]) {
                    bc.threads[threadId] = Date.now();
                    bc.slugs[threadId] = window.location.pathname + window.location.search;
                    watchData[board] = bc;
                    $SS.localJSON.set("watch_js", watchData);
                }
            } catch (e) {}
        },
        replacePostMenuBtn: function (root) {
            root = root || document;
            var btns = root.querySelectorAll ? root.querySelectorAll("a.post-btn") : [];
            [].forEach.call(btns, function (btn) {
                if (btn.textContent === "▶" || btn.textContent === "\u25B6") btn.textContent = "\u2771";
                // vichan puts the menu button before the poster name, indenting
                // every post header; 4chan-X keeps it after the post number.
                var intro = btn.closest ? btn.closest("p.intro") : null;
                if (intro) {
                    var nums = intro.querySelectorAll("a.post_no");
                    if (nums.length) {
                        var last = nums[nums.length - 1];
                        if (last.nextSibling !== btn)
                            intro.insertBefore(btn, last.nextSibling);
                    }
                }
            });
        },
        // Sidebar-fit width cap for mascots (the #styletower-mascots img max-width)
        mascotCap: 300,
        // Whether the cap applies to a mascot: its own Max Width setting, or
        // the Mascot Max Width option when it has none
        mascotCapped: function (m) {
            return m.maxwidth === undefined || m.maxwidth === null ?
                $SS.conf["Mascot Max Width"] !== false : m.maxwidth !== false;
        },
        // Mascots used to carry a Scale percentage. Sizing is Width and Height
        // now (the editor's scale tool rewrites those), so a stored Scale is
        // converted once, from the image's real width, into the Width it
        // produced: natural x scale under the original rule, or the shown
        // size x scale when marked "display". Nothing changes on screen. An
        // entry with an exact size already ignored its Scale, which is dropped
        migrateMascotScale: function () {
            var list;
            try { list = JSON.parse($SS.conf["Mascots"] || "[]"); } catch (e) { return; }
            if (!Array.isArray(list)) return;
            var hasScale = function (m) {
                    return !!(m && m.url && parseInt(m.scale, 10) && parseInt(m.scale, 10) !== 100);
                },
                sized = function (m) {
                    return !!((m.width && m.width !== "auto") || (m.height && m.height !== "auto"));
                },
                dropStale = function (current) {
                    var changed = false;
                    current.forEach(function (m) {
                        if (!m || !("scale" in m || "scaleBase" in m)) return;
                        if (hasScale(m) && !sized(m)) return;
                        delete m.scale;
                        delete m.scaleBase;
                        changed = true;
                    });
                    return changed;
                },
                save = function (current) {
                    $SS.conf["Mascots"] = JSON.stringify(current);
                    $SS.Config.set("Mascots", $SS.conf["Mascots"]);
                    // Export reads this snapshot (rebuilt only by Config.init)
                    if ($SS.exportOptions) $SS.exportOptions["Mascots"] = $SS.conf["Mascots"];
                },
                todo = list.filter(function (m) { return hasScale(m) && !sized(m); });
            if (!todo.length) {
                if (dropStale(list)) save(list);
                return;
            }
            var widths = {}, left = todo.length;
            var finish = function () {
                if (--left) return;
                var current;
                try { current = JSON.parse($SS.conf["Mascots"] || "[]"); } catch (e) { return; }
                if (!Array.isArray(current)) return;
                var changed = dropStale(current);
                current.forEach(function (m) {
                    if (!hasScale(m) || sized(m) || !(m.url in widths)) return;
                    var natural = widths[m.url],
                        base = m.scaleBase === "display" && $SS.mascotCapped(m) ? Math.min(natural, $SS.mascotCap) : natural;
                    m.width = Math.round(base * parseInt(m.scale, 10) / 100) + "px";
                    delete m.scale;
                    delete m.scaleBase;
                    changed = true;
                });
                if (changed) save(current);
            };
            todo.forEach(function (m) {
                var img = new Image();
                img.onload = function () {
                    if (img.naturalWidth) widths[m.url] = img.naturalWidth;
                    finish();
                };
                img.onerror = finish;
                img.src = m.url;
            });
        },
        mascotFilterCSS: function (m) {
            // Per-mascot image filters; only non-default values contribute
            var f = (m && m.filters) || {},
                parts = [];
            if (f.gray) parts.push("grayscale(" + f.gray + "%)");
            if (f.sepia) parts.push("sepia(" + f.sepia + "%)");
            if (f.invert) parts.push("invert(" + f.invert + "%)");
            if (f.hue) parts.push("hue-rotate(" + f.hue + "deg)");
            if (f.bright != null && f.bright !== 100) parts.push("brightness(" + f.bright + "%)");
            if (f.contrast != null && f.contrast !== 100) parts.push("contrast(" + f.contrast + "%)");
            if (f.sat != null && f.sat !== 100) parts.push("saturate(" + f.sat + "%)");
            if (f.blur) parts.push("blur(" + f.blur + "px)");
            return parts.join(" ");
        },
        displayMascots: function (previewMascot) {
            // One mascot at a time, OneeChan-style: picked at random from the
            // selected set (or forced by the editor's live preview)
            try {
                var existing = document.getElementById("styletower-mascots"),
                    drop = function () { if (existing) existing.remove(); };
                var m = previewMascot;
                if (!m) {
                    if (!$SS.conf["Enable Mascots"]) { drop(); return; }
                    if ($SS.conf["Hide Mascots in Catalog"] && $SS.location.catalog) { drop(); return; }
                    var mascots = [];
                    try { mascots = JSON.parse($SS.conf["Mascots"] || "[]"); } catch (e) {}
                    var board = $SS.location.board;
                    var available = mascots.filter(function (mm) {
                        if (mm.enabled === false || !mm.url) return false;
                        if (mm.boards) {
                            var list = String(mm.boards).split(",").map(function (b) {
                                return b.trim();
                            }).filter(Boolean);
                            if (list.length && list.indexOf(board) === -1) return false;
                        }
                        return true;
                    });
                    if (!available.length) { drop(); return; }
                    // Random on load, but stable across live settings
                    // changes (every apply re-runs this): the same mascot
                    // stays put unless it has left the selected set
                    var keep = $SS._mascotPick;
                    m = null;
                    if (keep) for (var ai = 0; ai < available.length; ai++)
                        if (available[ai].url === keep) { m = available[ai]; break; }
                    if (!m) m = available.length > 1 ? available[Math.floor(Math.random() * available.length)] : available[0];
                    $SS._mascotPick = m.url;
                }
                var side = m.side === "left" || m.side === "right" ? m.side :
                    (document.documentElement.classList.contains("left-sidebar") ? "left" : "right");
                // Max Width makes a capped mascot a 300px window (see the
                // .mascots-capped rule): an auto-sized image is scaled down to
                // fit it, an exact size shows as typed and anything past the
                // window is clipped out. Push In moves the image inside the
                // window, so a negative value hides the pushed-out part
                var capped = $SS.mascotCapped(m);
                // Every live settings change renders again; a mascot that
                // would come out identical is left in place rather than
                // rebuilt and repainted
                var sig = JSON.stringify(m) + "|" + side + "|" + capped;
                if (existing && existing.getAttribute("data-st-sig") === sig) return;
                drop();
                var container = document.createElement("div");
                container.id = "styletower-mascots";
                container.setAttribute("data-st-sig", sig);
                container.className = "mascots-" + side + (capped ? " mascots-capped" : "");
                var left = side === "left";
                var off = parseInt(m.offset, 10) || 0,
                    hoff = parseInt(m.hoffset, 10) || 0;
                if (off) container.style.bottom = off + "px";
                var img = document.createElement("img");
                img.src = m.url;
                if (hoff) img.style[left ? "marginLeft" : "marginRight"] = hoff + "px";
                img.style.opacity = (m.opacity == null ? 100 : m.opacity) / 100;
                if (m.flip) img.style.transform = "scaleX(-1)";
                // Free CSS sizes like OneeChan ("auto", "300px", "40vh"); bare
                // numbers are treated as px
                var size = function (v) {
                    v = String(v == null ? "" : v).trim();
                    if (!v || v === "auto") return "";
                    return /^\d+$/.test(v) ? v + "px" : v;
                };
                var wCss = size(m.width),
                    hCss = size(m.height),
                    scale = parseInt(m.scale, 10) || 100;
                if (wCss) img.style.width = wCss;
                if (hCss) img.style.height = hCss;
                // The img max-width scales an auto-sized image down to the
                // cap; an exact size shows as typed (the window clips it),
                // and Natural Size (per mascot, or the option off) is uncapped
                if (wCss || hCss || !capped) img.style.maxWidth = "none";
                if (!wCss && !hCss && scale !== 100) {
                    // A Scale from before the scale tool still renders as it
                    // did (natural width x percentage, or the shown size x
                    // percentage when marked "display") until
                    // migrateMascotScale turns it into a Width
                    if (m.scaleBase !== "display") img.style.maxWidth = "none";
                    else if (capped) img.style.maxWidth = Math.round($SS.mascotCap * scale / 100) + "px";
                    var applyScale = function () {
                        if (img.naturalWidth)
                            img.style.width = Math.round(img.naturalWidth * scale / 100) + "px";
                    };
                    if (img.complete && img.naturalWidth) applyScale();
                    else img.addEventListener("load", applyScale);
                }
                if (m.clip && (m.clip[0] || m.clip[1] || m.clip[2] || m.clip[3])) {
                    // Clip values describe the VISIBLE image (OneeChan
                    // semantics). clip-path applies before the flip transform,
                    // so swap L/R for flipped mascots to keep that meaning
                    var cT = m.clip[0] || 0, cL = m.clip[1] || 0,
                        cB = m.clip[2] || 0, cR = m.clip[3] || 0;
                    if (m.flip) { var cTmp = cL; cL = cR; cR = cTmp; }
                    img.style.clipPath = "inset(" + cT + "px " + cR + "px " + cB + "px " + cL + "px)";
                }
                var filterCSS = $SS.mascotFilterCSS(m);
                if (filterCSS) img.style.filter = filterCSS;
                container.appendChild(img);
                document.body.appendChild(container);
            } catch (e) {}
        },
        getOpenMenuPostId: function () {
            var btn = document.querySelector(".post-btn-open");
            var post = btn && btn.closest(".post");
            if (!post || !post.id) return null;
            return post.id.replace(/^(?:reply_|op_)/, "") || null;
        },
        insertToggleYou: function (menu) {
            menu = menu || document.querySelector(".post-menu");
            if (!menu || menu.querySelector("[data-cmd='toggle-you']")) return;
            var ul = menu.querySelector("ul");
            if (!ul) return;
            var postId = $SS.getOpenMenuPostId();
            if (!postId) return;
            var li = document.createElement("li");
            li.className = "post-item";
            li.setAttribute("data-cmd", "toggle-you");
            li.setAttribute("data-id", postId);
            li.textContent = $SS.getOwnPosts($SS.location.board).indexOf(postId) !== -1 ? "✓ You" : "Toggle You";
            ul.appendChild(li);
        },
        toggleYou: function (li) {
            var postId = li.getAttribute("data-id");
            if (!postId) return;
            try {
                var board = $SS.location.board;
                if (!board) return;
                var posts = $SS.localJSON.get("own_posts") || {};
                posts[board] = posts[board] || [];
                var el = document.getElementById("reply_" + postId) || document.getElementById("op_" + postId);
                var idx = posts[board].indexOf(postId);
                if (idx !== -1) {
                    posts[board].splice(idx, 1);
                    li.textContent = "Toggle You";
                    if (el) {
                        el.classList.remove("yourPost");
                        el.classList.remove("you");
                        var mark = el.querySelector(".intro span.own_post");
                        if (mark) mark.remove();
                    }
                } else {
                    posts[board].push(postId);
                    li.textContent = "✓ You";
                    if (el) {
                        el.classList.add("yourPost");
                        el.classList.add("you");
                        var name = el.querySelector(".intro span.name");
                        if (name && !el.querySelector(".intro span.own_post")) {
                            var span = document.createElement("span");
                            span.className = "own_post";
                            span.textContent = "(You)";
                            name.parentNode.insertBefore(span, name.nextSibling);
                            name.parentNode.insertBefore(document.createTextNode(" "), span);
                        }
                    }
                }
                if (posts[board].length === 0) delete posts[board];
                $SS.localJSON.set("own_posts", posts);
            } catch (e) {}
        },
        insertDeletePost: function (menu) {
            menu = menu || document.querySelector(".post-menu");
            if (!menu || menu.querySelector("[data-cmd='delete-post']")) return;
            var ul = menu.querySelector("ul");
            if (!ul) return;
            var postId = $SS.getOpenMenuPostId();
            if (!postId) return;
            var subUl = document.createElement("ul");
            var postLi = document.createElement("li");
            postLi.className = "post-item";
            postLi.setAttribute("data-cmd", "delete-post");
            postLi.setAttribute("data-id", postId);
            postLi.textContent = "Post";
            subUl.appendChild(postLi);
            var fileLi = document.createElement("li");
            fileLi.className = "post-item";
            fileLi.setAttribute("data-cmd", "delete-file");
            fileLi.setAttribute("data-id", postId);
            fileLi.textContent = "File only";
            subUl.appendChild(fileLi);
            var li = document.createElement("li");
            li.className = "post-submenu";
            li.appendChild(subUl);
            li.appendChild(document.createTextNode("Delete"));
            var arrow = document.createElement("span");
            arrow.className = "post-menu-arrow";
            arrow.textContent = "»";
            li.appendChild(arrow);
            ul.appendChild(li);
        },
        deletePost: function (li, fileOnly) {
            var postId = li.getAttribute("data-id");
            if (!postId) return;
            var delForm = document.querySelector("form[name='postcontrols']");
            var url = (delForm && delForm.action) || "/post.php";
            var boardInput = delForm && delForm.querySelector("input[name='board']");
            var board = (boardInput && boardInput.value) || $SS.location.board;
            var pwdInput = document.getElementById("password");
            var password = (pwdInput && pwdInput.value) || localStorage.password || "";
            var formData = new FormData();
            formData.append("board", board);
            formData.append("delete_" + postId, "on");
            formData.append("password", password);
            if (fileOnly) formData.append("file", "on");
            formData.append("delete", "Delete");
            formData.append("json_response", "1");
            var delNote = $SS.notify({ type: 'success', content: "Deleting...", lifetime: 0 });
            var xhr = new XMLHttpRequest();
            xhr.open("POST", url, true);
            xhr.withCredentials = true;
            xhr.onloadend = function () {
                $SS.dismissNotification(delNote);
                var msg, type = 'success', res = null;
                try { res = JSON.parse(xhr.responseText); } catch (e) {}
                if (!res) {
                    msg = "Connection error, please retry.";
                    type = 'warning';
                } else if (res.error) {
                    msg = res.error;
                    type = 'warning';
                } else {
                    msg = fileOnly ? "File deleted." : "Post deleted.";
                    $SS.removeDeletedPost(postId, fileOnly, board);
                }
                $SS.notify({ type: type, content: msg, lifetime: 5 });
            };
            xhr.send(formData);
        },
        /* Reflects a successful deletion without a reload: the file block
           goes, or the whole post; an OP takes its thread with it, so head
           back to the index */
        removeDeletedPost: function (postId, fileOnly, board) {
            var post = document.getElementById("reply_" + postId) || document.getElementById("op_" + postId);
            if (!post) return;
            if (fileOnly) {
                post.querySelectorAll(".files").forEach(function (f) { f.remove(); });
                return;
            }
            if (post.classList.contains("op")) {
                location.href = "/" + (board || $SS.location.board) + "/";
                return;
            }
            if (post._stHideBtn && post._stHideBtn.parentNode) post._stHideBtn.remove();
            post.remove();
        },
        QRDialogCreationHandler: function (e) {
            var qr = e.target;

            $SS.limitNameSubject(qr);
            if ($SS.conf["Watch Thread on Reply"] && $SS.location.reply) {
                $SS.handleFormNode(qr);
            }
            $SS.bindRememberComment(qr);

            var spoiler = qr.querySelector("input[name=spoiler]");
            if (spoiler) spoiler.title = "Spoiler image";

            $SS.syncTSPostingControls(qr, 10);
            $SS.restructureQRSubmit(qr);
            $SS.watchQRSize(qr);

            $SS.QRhandled = true;
        },
        keepQRInView: function (qr) {
            // Keep the whole quick reply inside the window. The site only
            // clamps its saved position when the QR opens; growing it (a
            // resized comment box, TS rows, file thumbnails, the captcha) or
            // shrinking the window can push part of it off-screen. Vertical
            // Tabbed docks it bottom-right by CSS (and hides it with a
            // translateX), so it is left alone.
            qr = qr || document.getElementById("quick-reply");
            if (!qr || !qr.isConnected || qr.style.display === "none") return;
            var de = document.documentElement;
            if (de.classList.contains("vertical-qr")) return;
            var cw = de.clientWidth, ch = de.clientHeight,
                r = qr.getBoundingClientRect();
            if (!cw || !ch || !r.width || !r.height) return;
            // The anchor is where the QR belongs: its spot when it opened,
            // or where it was last dropped (see initKeepQRInView). Growth is
            // measured from there, so a form that was pushed up or left to
            // fit returns to its place once it shrinks again.
            var a = qr._stAnchor;
            if (!a) a = qr._stAnchor = { top: r.top, right: cw - r.right };
            var top = a.top, left = cw - a.right - r.width;
            if (top + r.height > ch) top = ch - r.height;
            if (top < 0) top = 0;
            if (left + r.width > cw) left = cw - r.width;
            if (left < 0) left = 0;
            if (Math.abs(top - r.top) > 0.5 || Math.abs(left - r.left) > 0.5) {
                // The site positions a dragged QR by top/right with left:auto;
                // keep that convention so its draggable and saved position
                // keep working
                qr.style.top = top + "px";
                qr.style.right = (cw - left - r.width) + "px";
                qr.style.left = "auto";
            }
            // A QR taller than the window can't fit by moving: cap the comment
            // box at the room left under the rest of the form. The cap tracks
            // window and form changes, so it only ever bites when needed.
            var ta = qr.querySelector("textarea[name=body]");
            if (ta && ta.offsetHeight)
                ta.style.maxHeight = Math.max(25, ta.offsetHeight + ch - r.height) + "px";
        },
        watchQRSize: function (qr) {
            // Re-clamp whenever the QR's box changes; the observer also fires
            // (with a zero box) when the QR is closed, which drops the watch
            if (qr._stSizeWatch || typeof ResizeObserver === "undefined") return;
            var ro = new ResizeObserver(function () {
                if (!qr.isConnected) {
                    ro.disconnect();
                    qr._stSizeWatch = null;
                    return;
                }
                $SS.keepQRInView(qr);
            });
            ro.observe(qr);
            qr._stSizeWatch = ro;
        },
        initKeepQRInView: function () {
            // Resize events arrive in bursts while the window is dragged;
            // one clamp per frame reads the layout once
            var resizeQueued = false;
            window.addEventListener("resize", function () {
                if (resizeQueued) return;
                resizeQueued = true;
                requestAnimationFrame(function () {
                    resizeQueued = false;
                    $SS.keepQRInView();
                });
            });
            // A drag by the title bar moves the QR's anchor to where it is
            // dropped. The site's draggable only starts after 10px, so a
            // plain click on the handle leaves the anchor alone
            var press = null;
            document.addEventListener("mousedown", function (e) {
                var handle = e.target.closest && e.target.closest("#quick-reply th .handle");
                press = handle ? { qr: handle.closest("#quick-reply"), x: e.clientX, y: e.clientY } : null;
            });
            document.addEventListener("mouseup", function (e) {
                if (!press) return;
                var from = press;
                press = null;
                if (Math.hypot(e.clientX - from.x, e.clientY - from.y) < 10) return;
                // the site's drag stop handler writes the dropped position;
                // read it once that has run
                setTimeout(function () {
                    var qr = from.qr;
                    if (!qr.isConnected) return;
                    var r = qr.getBoundingClientRect();
                    qr._stAnchor = { top: r.top, right: document.documentElement.clientWidth - r.right };
                    $SS.keepQRInView(qr);
                });
            });
        },
        restructureQRSubmit: function (qr) {
            // Move the submit button out of the subject row into its own
            // full-width row at the bottom of the QR.
            if (qr.querySelector(".st-submit-row")) return;
            var submit = qr.querySelector("input[type=submit]");
            var table = qr.querySelector("table");
            if (!submit || !table) return;
            var submitTd = submit.closest("td");
            var tr = document.createElement("tr");
            tr.className = "st-submit-row";
            var td = document.createElement("td");
            td.setAttribute("colspan", "2");
            td.appendChild(submit);
            tr.appendChild(td);
            (table.tBodies[0] || table).appendChild(tr);
            if (submitTd && submitTd.classList.contains("submit")) {
                var subjectTd = submitTd.previousElementSibling;
                if (subjectTd) subjectTd.setAttribute("colspan", "2");
                // Keep the emptied cell as a hidden anchor: companion scripts
                // (e.g. the emote menu) insert their rows relative to
                // td.submit, and removing it made their injection silently
                // no-op whenever we processed the QR before they did
                submitTd.hidden = true;
            }
        },
        syncTSPostingControls: function (qr, attempts) {
            // The QR can be cloned before Holotower TS adds its posting controls
            // to the main form (an emote script pre-builds the QR at load), so
            // copy them over. TS's handlers are document-delegated and sync all
            // inputs by name, so the copies stay fully functional.
            if (!qr.isConnected) return;
            var mainRand = document.querySelector("form[name='post']:not(#quick-reply) input[name=randfn]");
            if (!mainRand) {
                // TS may not be done yet; retry briefly (never without TS)
                if (attempts > 0 && $SS.isTS()) setTimeout(function () { $SS.syncTSPostingControls(qr, attempts - 1); }, 500);
                return;
            }
            var qrSpoiler = qr.querySelector("input[name=spoiler]");
            if (!qr.querySelector("input[name=randfn]") && qrSpoiler) {
                var lbl = document.createElement("label"),
                    cb = document.createElement("input");
                cb.type = "checkbox";
                cb.name = "randfn";
                cb.checked = mainRand.checked;
                lbl.appendChild(cb);
                lbl.appendChild(document.createTextNode(" Randomize Filename"));
                qrSpoiler.parentNode.appendChild(document.createTextNode(" "));
                qrSpoiler.parentNode.appendChild(lbl);
            }
            var mainFnRow = document.getElementById("upload_filename");
            if (mainFnRow && !qr.querySelector("input[name=filename]") && qrSpoiler) {
                var spoilerRow = qrSpoiler.closest("tr");
                if (spoilerRow) {
                    var row = mainFnRow.cloneNode(true);
                    row.removeAttribute("id");
                    var th = row.querySelector("th");
                    if (th) th.remove();
                    var td = row.querySelector("td");
                    if (td) td.setAttribute("colspan", "2");
                    var inp = row.querySelector("input[name=filename]");
                    if (inp) {
                        inp.removeAttribute("size");
                        inp.setAttribute("placeholder", "Filename");
                        inp.value = mainFnRow.querySelector("input[name=filename]").value;
                    }
                    spoilerRow.parentNode.insertBefore(row, spoilerRow.nextSibling);
                }
            }
        },

        /* INTEGRATIONS
           Features folded in from the standalone Holotower userscripts:
           - Holotower X/BSKY Sauce (MIT, KanashiiWolf)
           - Holotower Auto Scroll (MIT)
           - Holotower Catalog Highlights and Pin (CC0, anonymous)
           Inline quoting, custom fixes, soundposts and imgops links live in Holotower TS.
           Disable the matching option before running a standalone copy alongside. */
        integrations: {
            pageWindow: function () {
                return typeof unsafeWindow !== "undefined" ? unsafeWindow : window;
            },
            jq: function () {
                try { return $SS.integrations.pageWindow().jQuery || null; } catch (e) { return null; }
            },
            addStyle: function (id, css) {
                var el = document.getElementById(id);
                if (!el) {
                    el = document.createElement("style");
                    el.id = id;
                    (document.head || document.documentElement).appendChild(el);
                }
                el.textContent = css;
            },
            init: function () {
                var I = $SS.integrations;
                if ($SS.conf["Auto Scroll"] && $SS.location.reply && !I._autoScroll) { I._autoScroll = true; I.initAutoScroll(); }
                if ($SS.conf["Sauce Links"] && !I._sauce) { I._sauce = true; I.initSauceLinks(); }
                if ($SS.conf["Catalog Highlights"] && $SS.location.catalog && !I._catalog) { I._catalog = true; I.initCatalogHighlights(); }
            },
            /* Called by the main DOM observer for each added element; the
               integrations hook in here instead of observing on their own */
            onNodeAdded: function (node) {
                var I = $SS.integrations;
                if (I._sauceSweep) I._sauceSweep(node);
                if (I._autoScrollNode) I._autoScrollNode(node);
            },

            /* X/BSKY sauce links on file info (Holotower X/BSKY Sauce) */
            initSauceLinks: function () {
                var regexAll = /@(?:([a-zA-Z0-9-.]+)-bsky|(\w+))-(\d{19}|\S{13})(-\d)?.*\.\w+$/i;

                function addSauceButton(el, data) {
                    if (el == null) return;
                    var site, url;
                    var sauceEl = document.createElement("span");
                    sauceEl.className = "sc-sauce-link";
                    if (data[1]) {
                        site = "🦋"; /* butterfly */
                        url = "https://bsky.app/profile/" + data[1] + "/post/" + data[3];
                    } else {
                        site = "𝕏"; /* X */
                        url = "https://x.com/" + data[2] + "/status/" + data[3];
                    }
                    var a = document.createElement("a");
                    a.href = url;
                    a.target = "_blank";
                    a.rel = "noopener noreferrer";
                    a.textContent = site;
                    sauceEl.appendChild(document.createTextNode("["));
                    sauceEl.appendChild(a);
                    sauceEl.appendChild(document.createTextNode("]"));
                    if (el.parentElement && el.parentElement.parentElement)
                        el.parentElement.parentElement.appendChild(sauceEl);
                }

                function sweep(root) {
                    var scope = root && root.querySelectorAll ? root : document;
                    scope.querySelectorAll(".fileinfo span.unimportant a").forEach(function (file) {
                        if (!file.hasAttribute("sauced")) {
                            file.setAttribute("sauced", "");
                            var data = (file.download || "").match(regexAll);
                            if (data) addSauceButton(file, data);
                        }
                    });
                }

                sweep(document);
                // Later posts are swept from the main observer (onNodeAdded)
                $SS.integrations._sauceSweep = sweep;
            },

            /* Scroll to new posts only when already at the bottom (Holotower Auto Scroll) */
            initAutoScroll: function () {
                var VISIBILITY_THRESHOLD = 5;
                var STORAGE_KEY = "holotower_auto_scroll_enabled";
                var originalScrollCheckbox = null;
                var autoScrollCheckbox = null;
                var lastPostElements = [];

                function saveAutoScrollState(enabled) {
                    try { localStorage.setItem(STORAGE_KEY, enabled ? "true" : "false"); } catch (e) {}
                }
                function loadAutoScrollState() {
                    try { return localStorage.getItem(STORAGE_KEY) === "true"; } catch (e) { return false; }
                }
                function isElementInView(element) {
                    if (!element) return false;
                    var rect = element.getBoundingClientRect();
                    var windowHeight = window.innerHeight || document.documentElement.clientHeight;
                    return rect.top < windowHeight && rect.bottom > 0 &&
                        (rect.bottom - Math.max(rect.top, 0)) >= VISIBILITY_THRESHOLD;
                }
                function isNearBottom() {
                    var scrollPosition = window.innerHeight + window.scrollY;
                    return document.documentElement.scrollHeight - scrollPosition <= 200;
                }
                function getCurrentPosts() {
                    // Real posts only: TS hover previews and inlined quotes
                    // clone p.intro too, and would inflate the record
                    return Array.prototype.slice.call(document.querySelectorAll("p.intro")).filter(function (p) {
                        return !p.closest(".post-hover, .inline-quote-container, .inline-cloned-post");
                    });
                }
                function isLastPostInView() {
                    var lastPost = lastPostElements[lastPostElements.length - 1];
                    return lastPost ? isElementInView(lastPost) : false;
                }
                function shouldScroll() {
                    return isLastPostInView() || isNearBottom();
                }
                function scrollToBottom() {
                    window.scrollTo({ top: document.documentElement.scrollHeight, behavior: "instant" });
                }
                function updatePostRecord() {
                    lastPostElements = getCurrentPosts();
                }
                function checkForNewPosts() {
                    return getCurrentPosts().length > lastPostElements.length;
                }
                function findOriginalScrollCheckbox() {
                    return document.querySelector("input.auto-scroll");
                }
                function createAutoScrollCheckbox() {
                    var originalCheckbox = originalScrollCheckbox;
                    if (!originalCheckbox) return null;
                    originalCheckbox.style.display = "none";
                    var nextSibling = originalCheckbox.nextSibling;
                    while (nextSibling) {
                        if (nextSibling.nodeType === 3 && nextSibling.textContent.indexOf("Scroll to New posts") !== -1) {
                            var span = document.createElement("span");
                            span.style.display = "none";
                            span.textContent = nextSibling.textContent;
                            nextSibling.parentNode.replaceChild(span, nextSibling);
                            break;
                        }
                        nextSibling = nextSibling.nextSibling;
                    }
                    var autoCheckbox = document.createElement("input");
                    autoCheckbox.type = "checkbox";
                    autoCheckbox.id = "auto-scroll-claude";
                    autoCheckbox.className = "auto-scroll-claude";
                    autoCheckbox.checked = loadAutoScrollState();
                    var labelText = document.createTextNode(" Auto Scroll)");
                    var parentContainer = originalCheckbox.parentElement;
                    parentContainer.insertBefore(autoCheckbox, originalCheckbox);
                    parentContainer.insertBefore(labelText, originalCheckbox);
                    return autoCheckbox;
                }
                function handleNewPosts() {
                    var shouldScrollToNew = shouldScroll();
                    updatePostRecord();
                    if (autoScrollCheckbox && autoScrollCheckbox.checked && shouldScrollToNew)
                        scrollToBottom();
                }
                function monitorForNewPosts() {
                    if (checkForNewPosts()) handleNewPosts();
                }
                function setupCheckboxListeners() {
                    if (autoScrollCheckbox) {
                        autoScrollCheckbox.addEventListener("change", function () {
                            saveAutoScrollState(this.checked);
                            if (this.checked && originalScrollCheckbox && originalScrollCheckbox.checked)
                                originalScrollCheckbox.checked = false;
                        });
                    }
                    if (originalScrollCheckbox) {
                        originalScrollCheckbox.addEventListener("change", function () {
                            if (this.checked && autoScrollCheckbox && autoScrollCheckbox.checked) {
                                autoScrollCheckbox.checked = false;
                                saveAutoScrollState(false);
                            }
                        });
                    }
                }

                function initialize() {
                    originalScrollCheckbox = findOriginalScrollCheckbox();
                    if (!originalScrollCheckbox) return;
                    autoScrollCheckbox = createAutoScrollCheckbox();
                    if (!autoScrollCheckbox) return;
                    updatePostRecord();
                    setupCheckboxListeners();
                    if (autoScrollCheckbox.checked && originalScrollCheckbox.checked)
                        originalScrollCheckbox.checked = false;
                }

                $.waitFor("input.auto-scroll", initialize);

                // Fed by the main DOM observer: new posts outside TS's inline
                // quote containers and hover previews trigger a check, and a
                // rebuilt updater row (the site recreates its checkbox) gets
                // ours re-attached
                var checkTimeout, reinitTimeout;
                $SS.integrations._autoScrollNode = function (node) {
                    if (!node.matches) return;
                    if ((node.matches("p.intro, div.post, .post_no") || node.querySelector("p.intro, div.post, .post_no")) &&
                        !node.closest(".inline-quote-container, .post-hover")) {
                        clearTimeout(checkTimeout);
                        checkTimeout = setTimeout(monitorForNewPosts, 100);
                    }
                    if ((node.matches("input.auto-scroll") || node.querySelector("input.auto-scroll")) &&
                        (!autoScrollCheckbox || !document.contains(autoScrollCheckbox))) {
                        clearTimeout(reinitTimeout);
                        reinitTimeout = setTimeout(initialize, 100);
                    }
                };
            },

            /* Highlight and pin catalog threads (Holotower Catalog Highlights and Pin) */
            initCatalogHighlights: function () {
                var STORAGE_KEY = "pinnedThreadSettings";
                var settings = getSettings();

                function getSettings() {
                    var defaults = {
                        highlights: [{ name: "Hololive Global", color: "#00bfff" }],
                        pinThreads: true,
                        hideOlderThreads: false,
                        customSearchBar: true
                    };
                    try {
                        var parsed = JSON.parse(localStorage.getItem(STORAGE_KEY));
                        if (!parsed || !Array.isArray(parsed.highlights)) throw new Error();
                        for (var key in defaults) {
                            if (!(key in parsed)) parsed[key] = defaults[key];
                        }
                        return parsed;
                    } catch (e) {
                        saveSettings(defaults);
                        return defaults;
                    }
                }
                function saveSettings(s) {
                    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(s)); } catch (e) {}
                }

                function el(tag, attrs, styles, text) {
                    var node = document.createElement(tag);
                    var k;
                    if (attrs) for (k in attrs) node.setAttribute(k, attrs[k]);
                    if (styles) for (k in styles) node.style[k] = styles[k];
                    if (text != null) node.textContent = text;
                    return node;
                }

                function postContainsText(mix, searchText) {
                    var subjectEl = mix.querySelector(".subject");
                    var subjectText = subjectEl ? subjectEl.textContent.trim().replace(/\s+/g, " ").toLowerCase() : "";
                    if (!subjectText) {
                        var strong = mix.querySelector(".replies strong");
                        if (strong && strong.parentNode) {
                            var parts = [];
                            strong.parentNode.childNodes.forEach(function (n) {
                                if (n.nodeType === 3) parts.push(n.textContent);
                            });
                            subjectText = parts.join(" ").toLowerCase();
                        }
                    }
                    var matchText = searchText.trim().replace(/\s+/g, " ").toLowerCase();
                    return !!matchText && subjectText.indexOf(matchText) !== -1;
                }

                function mixSort() {
                    /* Re-sort through the page's MixItUp plugin when reachable */
                    try {
                        var $j = $SS.integrations.jq();
                        if (!$j || !$j.fn || !$j.fn.mixItUp) return;
                        var sortSel = document.getElementById("sort_by");
                        var sortBy = sortSel ? sortSel.value : "bump:desc";
                        $j("#Grid").mixItUp("sort", (sortBy === "random" ? sortBy : "sticky:desc " + sortBy));
                    } catch (e) {}
                }

                function highlightLatestThreads() {
                    if (!settings.highlights || !settings.highlights.length) return;
                    var grid = document.getElementById("Grid");
                    if (!grid) return;
                    var highlightedThreads = {};

                    grid.querySelectorAll(":scope > div.mix").forEach(function (mix) {
                        var thread = mix.querySelector(".thread");
                        if (mix.getAttribute("data-thread-highlighter-hidden") === "true") {
                            mix.style.display = "";
                            mix.setAttribute("data-thread-highlighter-hidden", "false");
                        }
                        mix.classList.remove("highlighted");
                        if (thread) thread.style.boxShadow = "";

                        settings.highlights.forEach(function (setting) {
                            if (!postContainsText(mix, setting.name)) return;
                            mix.classList.add("highlighted");
                            if (setting.color)
                                mix.style.setProperty("--pin-color", setting.color);
                            else
                                mix.style.removeProperty("--pin-color");
                            var matchText = setting.name.trim().replace(/\s+/g, " ").toLowerCase();
                            if (!highlightedThreads[matchText]) highlightedThreads[matchText] = [];
                            highlightedThreads[matchText].push(mix);
                        });
                    });

                    var matchText;
                    for (matchText in highlightedThreads) {
                        highlightedThreads[matchText].sort(function (a, b) {
                            return (+b.getAttribute("data-bump") || 0) - (+a.getAttribute("data-bump") || 0);
                        });
                    }
                    var sortedThreads = Object.keys(highlightedThreads).map(function (key) {
                        return [key, highlightedThreads[key]];
                    }).sort(function (a, b) {
                        return (+a[1][0].getAttribute("data-bump") || 0) - (+b[1][0].getAttribute("data-bump") || 0);
                    });

                    mixSort();

                    sortedThreads.forEach(function (entry) {
                        var threads = entry[1];
                        if (settings.pinThreads) {
                            var first = grid.querySelector(".mix");
                            if (first && first !== threads[0]) {
                                grid.insertBefore(threads[0], first);
                                grid.insertBefore(document.createTextNode(" "), first);
                            }
                        }
                        if (settings.hideOlderThreads) {
                            for (var i = 1; i < threads.length; i++) {
                                threads[i].style.display = "none";
                                threads[i].setAttribute("data-thread-highlighter-hidden", "true");
                            }
                        }
                    });
                }

                function createSettingsButtonAndPopup() {
                    var afterElement = document.querySelector("span.catalog_search") || document.querySelector("select#image_size");
                    if (!afterElement) return;

                    var button = el("button", null, { marginLeft: "6px", padding: "2px 8px", fontSize: "13px" }, "Pin Settings");
                    afterElement.parentNode.insertBefore(button, afterElement.nextSibling);

                    var pinSettings = el("div", { id: "pin-settings", "class": "dialog" }, {
                        position: "fixed", overflow: "auto", maxHeight: "90vh", top: "50%", left: "50%",
                        transform: "translate(-50%, -50%)", padding: "14px", zIndex: 999,
                        width: "330px", borderRadius: "6px", display: "none"
                    });
                    getDocBody().appendChild(pinSettings);

                    button.addEventListener("click", function () {
                        refreshList();
                        pinSettings.style.display = pinSettings.style.display === "none" ? "" : "none";
                    });

                    var closeBtn = el("button", null, {
                        border: "none", background: "transparent", fontSize: "16px", cursor: "pointer",
                        position: "absolute", top: "8px", right: "12px"
                    }, "✖");
                    closeBtn.addEventListener("click", function () { pinSettings.style.display = "none"; });
                    pinSettings.appendChild(closeBtn);

                    pinSettings.appendChild(el("h3", null, { margin: "0", padding: "0" }, "Highlight Settings"));

                    var list = el("div", null, { padding: "0", marginTop: "8px" });
                    pinSettings.appendChild(list);

                    function refreshList() {
                        list.textContent = "";
                        settings.highlights.forEach(function (entry, index) {
                            var listItem = el("div", null, { marginBottom: "8px", display: "flex", alignItems: "center", gap: "4px" });
                            list.appendChild(listItem);

                            var subjectInput = el("input", {
                                type: "text", placeholder: "Subject",
                                title: "Text to search in threads subject. If a thread has no subject, its comment is searched instead. Case insensitive"
                            }, { flex: "2", padding: "3px" });
                            subjectInput.value = entry.name;
                            subjectInput.addEventListener("change", function () {
                                entry.name = this.value;
                                saveSettings(settings);
                                highlightLatestThreads();
                            });
                            listItem.appendChild(subjectInput);

                            var colorInput = el("input", { type: "color", "class": "color-picker" }, {
                                width: "30px", height: "30px", border: "none", background: "transparent"
                            });
                            colorInput.value = entry.color;
                            listItem.appendChild(colorInput);

                            var hexInput = el("input", { type: "text", "class": "hex-color", placeholder: "Hex" }, {
                                width: "54px", padding: "3px"
                            });
                            hexInput.value = entry.color;
                            listItem.appendChild(hexInput);

                            colorInput.addEventListener("change", function () {
                                entry.color = this.value;
                                hexInput.value = this.value;
                                saveSettings(settings);
                                highlightLatestThreads();
                            });
                            hexInput.addEventListener("change", function () {
                                if (/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/.test(this.value)) {
                                    entry.color = this.value;
                                    colorInput.value = this.value;
                                    saveSettings(settings);
                                    highlightLatestThreads();
                                }
                            });

                            var removeBtn = el("button", null, { cursor: "pointer" }, "✖");
                            removeBtn.addEventListener("click", function () {
                                settings.highlights.splice(index, 1);
                                saveSettings(settings);
                                refreshList();
                                highlightLatestThreads();
                            });
                            listItem.appendChild(removeBtn);
                        });
                    }

                    var addBtn = el("button", null, { margin: "8px 0", padding: "4px 8px 4px 5px", cursor: "pointer", display: "block" }, "+ Add");
                    addBtn.addEventListener("click", function () {
                        settings.highlights.push({ name: "", color: "#00bfff" });
                        saveSettings(settings);
                        refreshList();
                        setTimeout(function () {
                            var inputs = list.querySelectorAll("input[placeholder='Subject']");
                            if (inputs.length) inputs[inputs.length - 1].focus();
                        }, 0);
                    });
                    pinSettings.appendChild(addBtn);

                    function checkboxLabel(text, title, checked, marginLeft, onChange) {
                        var label = el("label", { title: title }, marginLeft ? {} : null);
                        var cb = el("input", { type: "checkbox" }, marginLeft ? { marginLeft: marginLeft } : null);
                        cb.checked = checked;
                        cb.addEventListener("change", onChange);
                        label.appendChild(cb);
                        label.appendChild(document.createTextNode(text));
                        pinSettings.appendChild(label);
                        return cb;
                    }
                    checkboxLabel("Pin", "Pin the most recently bumped highlighted threads", settings.pinThreads, null, function () {
                        settings.pinThreads = this.checked;
                        saveSettings(settings);
                        highlightLatestThreads();
                    });
                    checkboxLabel("Hide older threads", "Hide all the older highlighted threads", settings.hideOlderThreads, "10px", function () {
                        settings.hideOlderThreads = this.checked;
                        saveSettings(settings);
                        highlightLatestThreads();
                    });
                    checkboxLabel("Fallback search", "Show a custom search bar if the built-in search bar is missing", settings.customSearchBar, "10px", function () {
                        settings.customSearchBar = this.checked;
                        var bar = document.querySelector(".custom-search-bar");
                        if (bar) bar.style.display = this.checked ? "" : "none";
                        saveSettings(settings);
                    });
                }

                function addSearchBar() {
                    if (document.querySelector("span.catalog_search")) return;
                    var imageSize = document.querySelector("select#image_size");
                    if (!imageSize) return;
                    var searchInput = el("input", { type: "text", placeholder: "Search..." }, { marginLeft: "6px", width: "90px" });
                    searchInput.addEventListener("input", function () {
                        var searchText = this.value;
                        document.querySelectorAll("#Grid > div.mix").forEach(function (mix) {
                            mix.style.display = (!searchText || postContainsText(mix, searchText)) ? "" : "none";
                        });
                    });
                    var span = el("span", { "class": "catalog_search custom-search-bar" });
                    if (!settings.customSearchBar) span.style.display = "none";
                    span.appendChild(searchInput);
                    imageSize.parentNode.insertBefore(span, imageSize.nextSibling);
                }

                $SS.integrations.addStyle("sc-catalog-highlights-css",
                    "/* Generated by StyleTower (Catalog Highlights and Pin) */\n" +
                    ".highlighted > div { box-shadow: inset 0 0 2px 2px var(--pin-color, rgb(var(--sc-threadHLColor-rgb))); }");

                createSettingsButtonAndPopup();
                addSearchBar();
                highlightLatestThreads();
                var sortBy = document.getElementById("sort_by");
                if (sortBy) sortBy.addEventListener("change", function () { highlightLatestThreads(); });
            }
        },

        /* CONFIG */
        Config: {
            /* overrides: values the open options panel holds that are not
               stored yet (live preview); they sit on top of storage */
            init: function (overrides) {
                var parseVal = function (key, val) {
                    if (key === "Selected Theme" || key === "NSFW Theme")
                        return parseInt(val, 10);
                    if (key === "Hidden Themes") {
                        for (var i = 0, MAX = val.length, ret = []; i < MAX; ++i)
                            ret[i] = parseInt(val[i], 10);
                        return ret;
                    }
                    return (Array.isArray(val) && typeof val[0] !== "object") ? val[0] : val;
                };

                $SS.conf = {};
                $SS.exportOptions = {};

                for (var key in defaultConfig) {
                    $SS.conf[key] = parseVal(key, this.get(key));
                    if (!(/^::/.test(key))) {
                        $SS.exportOptions[key] = $SS.conf[key];
                    };
                };
                if (overrides)
                    for (var ok in overrides)
                        if (ok in defaultConfig) $SS.exportOptions[ok] = $SS.conf[ok] = overrides[ok];

                // One-time migration: "Animated GIF Thumbnails" became the
                // Replace Thumbnails group (GIF-only to preserve behavior)
                try {
                    var oldGif = this.get("Animated GIF Thumbnails"),
                        newRaw = $SS.hasGM ? GM_getValue(NAMESPACE + "Replace Thumbnails") :
                            localStorage.getItem(NAMESPACE + "Replace Thumbnails");
                    if (oldGif === true && newRaw == undefined) {
                        this.set("Replace Thumbnails", true);
                        this.set("Replace JPG", false);
                        this.set("Replace PNG", false);
                        $SS.conf["Replace Thumbnails"] = true;
                        $SS.conf["Replace JPG"] = false;
                        $SS.conf["Replace PNG"] = false;
                    }
                } catch (e) {}

                // "Relative Post Dates" duplicated the site's own Show relative
                // time option (Options → General) and never parsed vichan's
                // datetime format; hand an enabled setting over to the site
                try {
                    if (this.get("Relative Post Dates") === true)
                        localStorage.show_relative_time = "true";
                    this.remove("Relative Post Dates");
                } catch (e) {}

                // Include saved site settings in exports
                var chanKeys = ["stylesheet", "name", "email", "password", "own_posts", "watch_js", "hidden_threads", "catalog"];
                chanKeys.forEach(function (key) {
                    try {
                        if (localStorage[key]) {
                            var v;
                            try { v = JSON.parse(localStorage[key]); } catch (er) { v = localStorage[key]; }
                            $SS.exportOptions["SavedSite." + key] = v;
                        }
                    } catch (e) {}
                });

                $SS.conf["Margin Left"] = $SS.conf["Left Margin"] !== 999 ? $SS.conf["Left Margin"] : $SS.conf["Custom Left Margin"];
                $SS.conf["Margin Right"] = $SS.conf["Right Margin"] !== 999 ? $SS.conf["Right Margin"] : $SS.conf["Custom Right Margin"];
                // "Normal" maps to 4chan's native blockquote margin; vichan's own
                // div.body default is nearly zero, which makes text hug the post
                // edge and wrap fully under thumbnails.
                $SS.conf["Margin Post Message"] = $SS.conf["Post Message Margin"] === 1 ? "4px 16px" : ($SS.conf["Post Message Margin"] === 3 ? "20px 40px" : "13px 40px");
                $SS.conf["Width Decoration"] = $SS.conf["Decoration Width"] !== 999 ? $SS.conf["Decoration Width"] : $SS.conf["Custom Decoration Width"];
            },
            get: function (name) {
                var key = NAMESPACE + name, val;
                try {
                    val = $SS.hasGM ? GM_getValue(key) : localStorage.getItem(key);
                    if (val != undefined) return JSON.parse(val);
                } catch (e) {}
                return defaultConfig[name];
            },
            set: function (name, val) {
                var key = NAMESPACE + name;
                if (typeof val !== "number") val = JSON.stringify(val);
                try {
                    if ($SS.hasGM) GM_setValue(key, val);
                    else localStorage.setItem(key, val);
                    return true;
                } catch (e) {
                    // Quota or blocked storage: remember it so Save can say so
                    ($SS.Config.failed = $SS.Config.failed || []).push(name);
                    console.error("[StyleTower] could not save " + name + ":", e);
                    return false;
                }
            },
            remove: function (name) {
                var key = NAMESPACE + name;
                try {
                    if ($SS.hasGM) GM_deleteValue(key);
                    else localStorage.removeItem(key);
                } catch (e) {}
            }
        },

        /* OPTIONS */
        options: {
            saveAndClose: false,
            init: function () {
                $(document).bind("keydown", $SS.options.keydown);

                function makeNavLink() {
                    var link = document.createElement("a");
                    link.title = "StyleTower Settings";
                    link.href = "javascript:;";
                    link.addEventListener("click", $SS.options.show);
                    return link;
                }
                function makeNavSpan() {
                    var span = document.createElement("span");
                    span.id = "StyleTowerLink";
                    span.appendChild(document.createTextNode("["));
                    var link = makeNavLink();
                    link.textContent = "StyleTower";
                    span.appendChild(link);
                    span.appendChild(document.createTextNode("]"));
                    return span;
                }
                $.waitFor(".boardlist", function () {
                    document.querySelectorAll(".boardlist").forEach(function (boardlist) {
                        if (boardlist.querySelector("#StyleTowerLink") || boardlist.classList.contains("watch-menu")) return;
                        boardlist.appendChild(makeNavSpan());
                    });
                });
                // The header links are floated right, so DOM order runs right-to-left.
                // Target order (left to right): [Options] [StyleTower] [caret], i.e.
                // DOM order caret, StyleTower, Options. TS builds the caret late,
                // so reposition once it exists.
                $.waitFor(".boardlist a[title='Options']", function (optionsLink) {
                    var boardlist = optionsLink.closest(".boardlist"),
                        span = boardlist && boardlist.querySelector("#StyleTowerLink");
                    if (!span) return;
                    var place = function () {
                        var toggle = boardlist.querySelector(".hb-toggle");
                        if (toggle) boardlist.insertBefore(span, toggle.nextSibling);
                        else boardlist.insertBefore(span, optionsLink);
                    };
                    place();
                    if (!boardlist.querySelector(".hb-toggle") && $SS.isTS())
                        $.waitFor(".boardlist .hb-toggle", place);
                });
            },
            show: function () {
                // A theme/mascot editor is open: closing the panel under it
                // would leave the editor orphaned and its Save with nothing
                // to write to
                if ($("#overlay2").exists())
                    return;
                if ($("#overlay").exists())
                    $SS.options.close();
                else {
                    var overlay = $("<div id=overlay>").bind("click", $SS.options.close),
                        tOptions = $("<div id='oneechan-options' class=dialog>").bind("click", function (e) {
                            return e.stopPropagation();
                        }),
                        optionsHTML = [
                            "<ul id=options-tabs>",
                            "<li class='tab-item'><label class='tab-label selected' for=main-select>Main</label></li>",
                            "<li class='tab-item'><label class='tab-label' for=misc-select>Misc</label></li>",
                            "<li class='tab-item'><label class='tab-label' for=mascots-select>Mascots</label></li>",
                            "<li class='tab-item'><label class='tab-label' for=themes-select>Themes</label></li>",
                            "</ul><div id=options-container><input type=radio class=tab-select name=tab-select id=main-select hidden checked><div id='main-section' class='options-section'>",
                            "<p class='buttons-container'>",
                            "<span class='btn-left'><a class='options-button' title='Export your settings as JSON. Includes the saved Holotower name, email and post password.' name=Export>Export</a><a class='options-button' id='import-settings'><input type=file class='import-input' riced=true accept='application/json'>Import</a><a class='options-button' title='Reset StyleTower settings.' name=resetSettings>Reset</a></span>",
                            "<span class='btn-center' id=oneechan-version><span>StyleTower</span> v" + VERSION + "<span class=link-delim> | </span><a href='https://github.com/vampiricwulf/StyleTower/releases/latest' id=changelog-link target='_blank' title='Read the changelog.'>Changelog</a><span class=link-delim> | </span><a href='https://github.com/vampiricwulf/StyleTower/issues' id=issues-link target='_blank' title='Report an issue.'>Issues</a></span>",
                            "<span class='btn-right'><a class='options-button' name=save>Save</a><a class='options-button' name=cancel>Cancel</a></span></p>"
                        ];
                    var key, val, des, id;

                    // Working copy for the Mascots tab; serialized on Save
                    try { $SS.options._mascotWork = JSON.parse($SS.conf["Mascots"] || "[]"); }
                    catch (e) { $SS.options._mascotWork = []; }
                    // Changes apply at once but only Save stores them; the
                    // reload notice compares against what was stored at open
                    $SS.options.dirty = false;
                    $SS.options._baseline = {};
                    $SS.options.reloadKeys.concat($SS.options.reloadWhenOff).forEach(function (k) {
                        $SS.options._baseline[k] = $SS.conf[k];
                    });

                    for (key in defaultConfig) {
                        if (/^(Selected|Hidden)+\s(Themes?)+$/.test(key))
                            continue;

                        if (key === "Style Holotower TS Notifications" && !$SS.isTS())
                            continue;

                        // Set from the mascot editor's own checkbox, not the list
                        if (key === "Advanced Mascot Editor")
                            continue;

                        if (defaultConfig[key][0] === "header") {
                            optionsHTML.push("<label class='option header" + (key === ":: Holotower" || key === ":: Header" ? " has-subsections" : "") + "'><span class='option-title'>" + key + "</span></label>");
                            if (key === ":: Holotower") {
                                optionsHTML.push("<p class='option-actions'><a class='options-button' name=saveSiteSettings>Save Holotower settings</a><span class=link-delim> | </span><a class='options-button' name=restoreSiteSettings>Restore</a></p>");
                            }
                            continue;
                        }

                        val = $SS.conf[key];
                        des = defaultConfig[key][1];

                        if ((defaultConfig[key][4] === true) && /^Custom /.test(key)) {
                            // Pixel sub-inputs (Custom Left/Right Margin, Custom
                            // Decoration Width), shown while the parent select
                            // sits on its "Custom" value
                            var pVal = $SS.conf[defaultConfig[key][2]];
                            id = defaultConfig[key][2].replace(/\s/g, "_") + defaultConfig[key][3];
                            optionsHTML.push("<span class='option suboption " + id + "' title=\"" + des + "\"" +
                                (pVal != defaultConfig[key][3] ? "hidden" : "") + "><span class='option-title'>" + key +
                                "</span><input name='" + key + "' type=text value=" + val + "px></span>");
                        } else if ((defaultConfig[key][4] === true) && (key === "Dark Theme" || key === "Light Theme")) {
                            var pVal = $SS.conf[defaultConfig[key][2]];
                            id = defaultConfig[key][2].replace(/\s/g, "_") + defaultConfig[key][3];
                            var html = "<label class='option suboption " + id + "' title=\"" + des + "\"" +
                                (pVal != defaultConfig[key][3] ? "hidden" : "") + "><span class='option-title'>" + key + "</span>" +
                                "<select name='" + key + "'>";
                            for (var i = 0, MAX = $SS.conf["Themes"].length; i < MAX; ++i) {
                                html += "<option value='" + i + "'" + (i == val ? " selected" : "") + ">" +
                                    $SS.escapeHTML($SS.conf["Themes"][i].name) + "</option>";
                            }
                            html += "</select></label>";
                            optionsHTML.push(html);
                        } else if (key === "Nav Buttons") {
                            optionsHTML.push("<span class='option st-nav-row' data-tower-status='added' title=\"" + des + "\"><span class='option-title'>Navigation Buttons</span>" +
                                "<a class='options-button' name=navPosition title='Scale, position, spacing and order of the ↑ ↓ buttons; drag them on the page while editing.'>Set Position</a>" +
                                "<span class='st-nav-status'>" + (val ? "Custom" : "Site default") + "</span></span>");
                        } else if (key === "Enable Mascots") {
                            // The Mascots tab: master toggle + display options render
                            // into it via the generic branches below, then the
                            // "Mascots" key emits the gallery
                            optionsHTML.push("</div><input type=radio class=tab-select name=tab-select id=mascots-select hidden><div id='mascot-section' class='options-section'>" +
                                "<p class='buttons-container'><span class='btn-right'><a class='options-button' name=save>Save</a><a class='options-button' name=cancel>Cancel</a></span></p>" +
                                "<label class='option header'><span class='option-title'>:: Mascots</span></label>" +
                                "<label class=option title=\"" + des + "\"><span class='option-title'>" + key + "</span><input" + (val ? " checked" : "") + " name='" + key + "' type=checkbox></label>");
                        } else if ((defaultConfig[key][4] === true) && (key === "Mascots")) {
                            optionsHTML.push($SS.options.mascotGalleryHTML());
                        } else if (defaultConfig[key][4] === true) // sub-option
                        {
                            var pVal = $SS.conf[defaultConfig[key][2]];
                            id = defaultConfig[key][2].replace(/\s/g, "_") + defaultConfig[key][3];
                            optionsHTML.push("<label class='option suboption " + id + "' title=\"" + des + "\"" +
                                (pVal != defaultConfig[key][3] ? "hidden" : "") + "><span class='option-title'>" + key +
                                "</span><input" + (val ? " checked" : "") + " name='" + key + "' type=checkbox></label>");
                        } else if (Array.isArray(defaultConfig[key][2])) // select
                        {
                            var opts = defaultConfig[key][2],
                                cFonts = [],
                                html = ["<label class=option title=\"" + des + "\"><span class='option-title'>" + key + "</span>",
                                    "<select name='" + key + "'" + (defaultConfig[key][3] === true ? " has-suboption" : "") + ">"];

                            for (var i = 0, MAX = opts.length; i < MAX; ++i) {
                                var name, value;

                                if (typeof opts[i] === "object") {
                                    name = opts[i].name;
                                    value = opts[i].value;
                                } else
                                    name = value = opts[i];

                                if (key === "Font Family") cFonts.push(value);
                                html.push("<option" + (key === "Font Family" ? " style=\"font-family:" + $SS.formatFont(value) + "!important\"" : "") +
                                    " value='" + value + "'" + (value == val ? " selected" : "") + ">" + name + "</option>");
                            }

                            if (key === "Font Family") {
                                var osFonts = $SS.systemFonts[$SS.getOS()] || [];
                                osFonts.forEach(function (font) {
                                    if (cFonts.indexOf(font) === -1) {
                                        cFonts.push(font);
                                        html.push("<option style=\"font-family:" + $SS.formatFont(font) + "!important\" value='" + font + "'" + (font == val ? " selected" : "") + ">" + font + "</option>");
                                    }
                                });
                            }
                            if (key === "Font Family" && cFonts.indexOf($SS.conf["Font Family"]) == -1)
                                html.push("<option style=\"font-family:" + $SS.formatFont($SS.conf["Font Family"]) + "!important\" value='" + $SS.conf["Font Family"] + "' selected>" + $SS.conf["Font Family"] + "</option>");
                            html.push("</select></label>");
                            optionsHTML.push(html.join(""));
                        } else if (key === "Custom Font") {
                            optionsHTML.push("<label class='option visible' title=\"" + des + "\"><span class='option-title'>Custom Font</span>" +
                                "<input type=text name='Custom Font' value=\"" + $SS.escapeHTML($SS.conf["Custom Font"] || "") + "\" placeholder='system font name'></label>");
                        } else if (key === "QR Button Image") {
                            optionsHTML.push("<label class='option visible' title=\"" + des + "\"><span class='option-title'>" + key + "</span>" +
                                "<input type=text name='QR Button Image' value=\"" + String($SS.conf["QR Button Image"] || "").replace(/"/g, "&quot;") + "\" placeholder='image URL or data URI'></label>");
                        } else if (/Font Size$/.test(key)) {
                            optionsHTML.push("<label class='option visible' title=\"" + des + "\"><span class='option-title'>" + key + "</span>" +
                                "<input type=text name='" + key + "' value=" + val + "px></label>");
                        } else if (key === "Misc") {
                            optionsHTML.push("</div><input type=radio class=tab-select name=tab-select id=misc-select hidden><div id='misc-section' class='options-section'>" +
                                "<p class='buttons-container'><span class='btn-right'><a class='options-button' name=save>Save</a><a class='options-button' name=cancel>Cancel</a></span></p>");
                        } else if (key === "Themes") {
                            optionsHTML.push("</div><input type=radio class=tab-select name=tab-select id=themes-select hidden><div id='themes-section' class='options-section'>");
                        } else if (key === "Opacity") {
                            optionsHTML.push("<label class='option' title=\"" + des + "\"><span class='option-title'>" + key + "</span>" +
                                "<input type=range name=Opacity min=0 max=100 value=" + val + " class='mascot-opacity'><span class='mascot-opacity-val'>" + val + "%</span></label>");
                        } else // checkbox
                            optionsHTML.push("<label class=option title=\"" + des + "\"><span class='option-title'>" + key + "</span><input" + (val ? " checked" : "") +
                                " name='" + key + "' " + (defaultConfig[key][3] === true ? " has-suboption" : "") + " type=checkbox></label>");
                    }

                    optionsHTML.push("</div></div>");
                    tOptions.html(optionsHTML.join(""));
                    overlay.append(tOptions);

                    // Provenance badges (4chan-neXT-style): 'Tower' marks
                    // options added relative to upstream StyleChan, 'changed'
                    // marks ones whose behavior differs here
                    (function () {
                        var status = {
                                "Replace Thumbnails": "added",
                                "QR Button Image": "added",
                                "Auto Scroll": "added",
                                "Sauce Links": "added",
                                "Catalog Highlights": "added",
                                "Hide Mascots in Catalog": "added",
                                "Mascots Overlap Posts": "added",
                                "Reduce Mascot Opacity": "added",
                                "Mascot Max Width": "added",
                                "Use StyleTower Icons": "changed",
                                "Style Holotower TS Notifications": "changed",
                                "Margin Between Replies": "changed",
                                "Autohide Style": "changed",
                                "Enable Mascots": "changed",
                                "Fit Expanded Images": "changed",
                                "Follow Cursor": "changed"
                            },
                            rootEl = tOptions.elems[0];
                        if (!rootEl) return;
                        Object.keys(status).forEach(function (k) {
                            var input = rootEl.querySelector("[name='" + k + "']"),
                                row = input && (input.closest("label.option") || input.closest(".option"));
                            if (row) row.setAttribute("data-tower-status", status[k]);
                        });
                        rootEl.querySelectorAll("label.option.header").forEach(function (h) {
                            var t = h.textContent || "";
                            if (t.indexOf(":: Holotower") !== -1) h.setAttribute("data-tower-status", "added");
                            if (t.indexOf(":: Mascots") !== -1) h.setAttribute("data-tower-status", "changed");
                        });
                        var mtab = rootEl.querySelector("label.tab-label[for=mascots-select]");
                        if (mtab) mtab.setAttribute("data-tower-status", "changed");
                    })();

                    $(".import-input", tOptions).bind("change", function () {
                        var file = this.files[0],
                            reader = new FileReader(),
                            imported;
                        if (this.files[0].name.match(/\.json$/) == null) {
                            alert('Only JSON files are accepted!');
                            return;
                        } else if (!confirm('Your current settings will be entirely overwritten, are you sure?')) {
                            return;
                        }
                        reader.onload = (function () {
                            return function (e) {
                                try {
                                    imported = JSON.parse(e.target.result);
                                } catch (err) {
                                    alert("Invalid settings file!");
                                    return;
                                }

                                $SS.options.importSettings(imported);

                                if (confirm('Import successful. Refresh now?')) {
                                    return window.location.reload();
                                }
                                // Close so the open dialog's pre-import state
                                // can't overwrite the import via a later Save
                                $SS.options.close(true);
                                $SS.init(true);

                            };
                        })(file);

                        reader.readAsText(file);
                    });
                    // Export swaps the button for a download link. Clicking
                    // the link is a plain download: the panel stays open with
                    // its unsaved changes (closing here used to raise the
                    // discard prompt, and confirming threw the changes away),
                    // and the button comes back for another export
                    var exportTitle = $("a[name=Export]", tOptions).attr("title"),
                        bindExport = function (btn) {
                            btn.bind("click", function () {
                                if ($("a[download]", tOptions).exists())
                                    return;
                                var link = $("<a class='options-button' download='StyleTower v" + VERSION + " Settings.json' href='data:application/json;base64," + btoa(unescape(encodeURIComponent(JSON.stringify($SS.exportOptions, null, 2)))) + "'>Save me!");
                                link.bind("click", function () {
                                    setTimeout(function () {
                                        var fresh = $("<a class='options-button' title=\"" + exportTitle + "\" name=Export>Export");
                                        link.replace(fresh);
                                        bindExport(fresh);
                                    });
                                });
                                $(this).replace(link);
                            });
                        };
                    bindExport($("a[name=Export]", tOptions));
                    // Reset settings
                    $("a[name=resetSettings]", tOptions).bind("click", function () {
                        var confirmReset = confirm('Your current StyleTower settings will be wiped, are you sure?');
                        if (confirmReset) {
                            try {
                                if ($SS.hasGM) {
                                    var keys = GM_listValues();
                                    for (var i = 0, key = null; key = keys[i]; i++) {
                                        GM_deleteValue(key);
                                    }
                                }
                            } catch (e) {}
                            try {
                                Object.keys(localStorage).forEach(function (key) {
                                    if (/^(?:StyleTower)/.test(key)) {
                                        localStorage.removeItem(key);
                                    }
                                });
                            } catch (e) {}
                            alert('Your StyleTower settings have been reset. Reloading.');
                            return window.location.reload();
                        } else return;
                    });
                    // options window
                    $(".tab-label", tOptions).bind("click", function (e) {
                        var $this = $(this);
                        if ($this.hasClass("selected")) return;

                        $(".tab-label.selected").removeClass("selected");
                        $this.addClass("selected");
                    });
                    $("[has-suboption]", tOptions).bind("change", function () {
                        var id = this.name.replace(/\s/g, "_") + $(this).val(),
                            sub = $("." + id);

                        if (sub.exists())
                            sub.each(function () {
                                this.removeAttribute("hidden");
                            });
                        else
                            $("[class*='" + this.name.replace(/\s/g, "_") + "']").each(function () {
                                this.setAttribute("hidden", "");
                            });
                    });
                    $("input[name='System Theming']", tOptions).bind("change", function () {
                        var id = this.name.replace(/\s/g, "_") + this.checked,
                            sub = $("." + id);
                        if (sub.exists())
                            sub.each(function () { this.removeAttribute("hidden"); });
                        else
                            $("[class*='" + this.name.replace(/\s/g, "_") + "']").each(function () {
                                this.setAttribute("hidden", "");
                            });
                    });
                    // Every setting applies as soon as it changes (typed
                    // values after a short pause); Save is what stores them
                    var optsNode = tOptions.elems[0];
                    if (optsNode) {
                        optsNode.addEventListener("change", function (e) {
                            if (!$SS.options.isSetting(e.target)) return;
                            $SS.options.dirty = true;
                            $SS.options.applyLive();
                        });
                        optsNode.addEventListener("input", function (e) {
                            if (!$SS.options.isSetting(e.target)) return;
                            $SS.options.dirty = true;
                            $SS.options.applyLiveSoon();
                        });
                    }
                    // Mascots tab: gallery interactions on the working copy
                    if (optsNode) {
                        optsNode.addEventListener("click", function (e) {
                            var work = $SS.options._mascotWork;
                            if (!work) return;
                            if (e.target.closest(".mascot-add")) {
                                $SS.options.showMascotEditor(-1);
                                return;
                            }
                            if (e.target.closest(".mascot-select-all") || e.target.closest(".mascot-select-none")) {
                                var on = !!e.target.closest(".mascot-select-all");
                                work.forEach(function (m) { m.enabled = on; });
                                $SS.options.renderMascotGallery();
                                $SS.options.touched();
                                return;
                            }
                            var edit = e.target.closest(".mascot-edit");
                            if (edit) {
                                $SS.options.showMascotEditor(parseInt(edit.closest(".mascot-tile").getAttribute("data-idx"), 10));
                                return;
                            }
                            var del = e.target.closest(".mascot-del");
                            if (del) {
                                work.splice(parseInt(del.closest(".mascot-tile").getAttribute("data-idx"), 10), 1);
                                $SS.options.renderMascotGallery();
                                $SS.options.touched();
                                return;
                            }
                            var tile = e.target.closest(".mascot-tile");
                            if (tile) {
                                var m = work[parseInt(tile.getAttribute("data-idx"), 10)];
                                if (m) {
                                    m.enabled = m.enabled === false;
                                    tile.classList.toggle("selected", m.enabled);
                                    $SS.options.touched();
                                }
                            }
                        });
                    }
                    $("a[name=save]", tOptions).bind("click", function () {
                        $SS.options.saveAndClose = true;
                        $SS.options.save();
                        $SS.options.saveAndClose = false;
                    });
                    $("a[name=cancel]", tOptions).bind("click", $SS.options.close);
                    $("a[name=navPosition]", tOptions).bind("click", function () { $SS.options.showNavEditor(); });

                    // main tab
                    $("input[name='Font Size'], input[name='UI Font Size'], input[name='Backlink Font Size']", tOptions).bind("keydown", function (e) {
                        var val = parseInt($(this).val(), 10);
                        if (isNaN(val) || (e.key !== "ArrowUp" && e.key !== "ArrowDown")) return;
                        e.preventDefault();
                        $(this).val((e.key === "ArrowUp" ? val + 1 : val - 1) + "px");
                        this.dispatchEvent(new Event("input", { bubbles: true }));
                    });
                    $("input[name='Opacity']", tOptions).bind("input", function () {
                        var v = this.parentNode.querySelector(".mascot-opacity-val");
                        if (v) v.textContent = this.value + "%";
                    });

                    // themes tab
                    $SS.options.createThemesTab(tOptions);

                    // Holotower settings button handlers
                    (function () {
                        var chanKeys = ["stylesheet", "name", "email", "password", "own_posts", "watch_js", "hidden_threads", "catalog"];
                        $("a[name=saveSiteSettings]", tOptions).bind("click", function () {
                            var count = 0;
                            chanKeys.forEach(function (key) {
                                var val = localStorage[key];
                                if (val) {
                                    $SS.Config.set("SavedSiteSettings." + key, val);
                                    count++;
                                }
                            });
                            if (count > 0)
                                $SS.notify({ content: 'Holotower settings saved.', type: 'success', lifetime: 3 });
                            else
                                $SS.notify({ content: 'No Holotower settings found.', type: 'info', lifetime: 3 });
                        });
                        $("a[name=restoreSiteSettings]", tOptions).bind("click", function () {
                            var count = 0;
                            chanKeys.forEach(function (key) {
                                var saved = $SS.Config.get("SavedSiteSettings." + key);
                                if (saved) {
                                    localStorage[key] = saved;
                                    count++;
                                }
                            });
                            if (count > 0) {
                                $SS.notify({ content: 'Holotower settings restored. Reloading...', type: 'success', lifetime: 2 });
                                setTimeout(function () { location.reload(); }, 2000);
                            } else
                                $SS.notify({ content: 'No saved Holotower settings to restore.', type: 'info', lifetime: 3 });
                        });
                    })();

                    return $(getDocBody()).append(overlay);
                }
            },
            /* Reduces an imported theme object to known keys with validated
               values. Foreign flags never survive: an imported "default"
               would be skipped by every save and vanish on reload, and
               editor bookkeeping must not enter the array */
            sanitizeTheme: function (raw) {
                var t = {},
                    strKeys = ["name", "authorName", "authorTrip", "customCSS"],
                    i, k, v;

                for (i = 0; i < strKeys.length; i++)
                    if (typeof raw[strKeys[i]] === "string" && raw[strKeys[i]] !== "")
                        t[strKeys[i]] = raw[strKeys[i]];
                if (!t.name)
                    t.name = "Imported Theme";

                for (i = 0; i < themeInputs.length; i++) {
                    k = themeInputs[i].name;
                    v = $SS.normalizeHex(raw[k]);
                    if (v) t[k] = v;
                }
                // OneeChan-era themes name the post highlight differently
                if (!t.postHLColor && (v = $SS.normalizeHex(raw.highlightColor)))
                    t.postHLColor = v;

                t.replyOp = $SS.normalizeOpacity(raw.replyOp, "1.0");
                t.navOp = $SS.normalizeOpacity(raw.navOp, "0.9");
                t.hoverOp = $SS.normalizeOpacity(raw.hoverOp, "0.8");
                t.hoverOutOp = $SS.normalizeOpacity(raw.hoverOutOp, "0.5");

                if (typeof raw.bgImg === "string" && raw.bgImg !== "") {
                    v = $SS.cleanBase64(raw.bgImg);
                    if ($SS.validImageURL(v) || $SS.validBase64(v)) {
                        t.bgImg = v;
                        t.bgRPA = typeof raw.bgRPA === "string" && /^\S+ \S+ \S+ \S+$/.test(raw.bgRPA) ?
                            raw.bgRPA : "repeat top left scroll";
                    }
                }

                return t;
            },
            createThemesTab: function (tOptions) {
                var themes = $("#themes-section", tOptions).html(""),
                    p = $("<p class='buttons-container'>"),
                    left = $("<span class='btn-left'>");

                left.append($("<a class='options-button' name=addTheme title='Create a new theme.'>Create", tOptions).bind("click", $SS.options.showTheme));
                left.append($("<a class='options-button' href='https://github.com/3nly/StyleChan/wiki/Custom-Themes#custom-themes' target='_blank' title='Browse more themes on GitHub.'>More Themes</a>"));
                left.append($("<div id='import-link' title='Import a new theme file.'>").append($("<input type=file class='import-input' riced=true accept='application/json'>")
                    .bind("change", function () {
                        var file = this.files[0],
                            reader = new FileReader(),
                            theme, div, index;

                        reader.onload = (function () {
                            return function (e) {
                                try {
                                    theme = JSON.parse(e.target.result);
                                } catch (err) {
                                    alert("Invalid theme file!");
                                    return;
                                }

                                if (!theme || typeof theme !== "object" || Array.isArray(theme) ||
                                    !theme.textColor || !theme.mainColor) {
                                    alert("Invalid theme file!");
                                    return;
                                }

                                theme = $SS.options.sanitizeTheme(theme);

                                index = $SS.conf["Themes"].push(theme);
                                theme = new $SS.Theme(--index);
                                div = theme.preview();
                                $("#overlay #themes-section").append(div);
                                // The list itself is stored now; the tile
                                // click below only previews the selection
                                $SS.options.saveThemeState();
                                div.fire("click").scrollIntoView(true);
                                $SS.options.refreshThemeSelects();
                            };
                        })(file);

                        reader.readAsText(file);
                    })).append($("<span class='options-button'>Import")));
                left.append($("<a class='options-button' name=restoreThemes title='Restore hidden default themes'>Restore", tOptions)
                    .bind("click", function () {
                        $SS.conf["Hidden Themes"] = [];
                        $SS.Config.set("Hidden Themes", []);
                        $("#themes-section>div[hidden]").show();
                        $(this).hide();
                    })
                );

                p.append(left);
                p.append($("<span class='btn-right'><a class='options-button' name=save>Save</a><a class='options-button' name=cancel>Cancel</a></span>"));
                $("a[name=save]", p).bind("click", function () {
                    $SS.options.saveAndClose = true;
                    $SS.options.save();
                    $SS.options.saveAndClose = false;
                });
                $("a[name=cancel]", p).bind("click", $SS.options.close);

                if ($SS.conf["Hidden Themes"].length === 0)
                    $("a[name=restoreThemes]", p).hide();

                themes.append(p);

                for (var i = 0, MAX = $SS.conf["Themes"].length, tTheme; i < MAX; ++i) {
                    tTheme = new $SS.Theme(i);
                    themes.append(tTheme.preview());
                }
            },
            /* Closes the panel. Unsaved changes are applied live, so ask
               first and revert to the stored settings when discarding;
               force skips the question (Save, import) */
            close: function (force) {
                if (force !== true && $SS.options.dirty) {
                    if (!confirm("Discard unsaved changes?")) return false;
                    $SS.init(true);
                }
                $SS.options.dirty = false;
                $("#overlay").remove();
                return true;
            },
            /* Panel controls that hold settings (not the tab radios or the
               import file inputs) */
            isSetting: function (el) {
                return !!(el && el.matches && el.matches("input[name]:not(.tab-select):not([type=file]), select"));
            },
            /* The panel's current values, parsed the way Save stores them */
            collect: function () {
                var out = {};
                $("#oneechan-options input[name]:not(.tab-select), #oneechan-options select").each(function () {
                    var $this = $(this),
                        name = $this.attr("name"),
                        val = $this.val();
                    if (/^(Font Size|Custom (Right|Left) Margin|Custom Decoration Width|UI Font Size|Backlink Font Size|Dark Theme|Light Theme|Opacity)$/.test(name)) {
                        val = parseInt(val, 10);
                        // A size still being typed stays out of the preview
                        if (isNaN(val) || (/Font Size$/.test(name) && val < 6)) return;
                    }
                    out[name] = val;
                });
                if ($SS.options._mascotWork)
                    out["Mascots"] = JSON.stringify($SS.options._mascotWork);
                var sel = $("#oneechan-options #themes-section>div.selected");
                if (sel.exists()) {
                    var idx = parseInt(sel.attr("id").substr(5), 10);
                    if ($SS.conf["Themes"][idx]) {
                        out["Selected Theme"] = idx;
                        out["NSFW Theme"] = idx;
                    }
                }
                return out;
            },
            /* Applies the panel's values on top of the stored settings */
            applyLive: function () {
                clearTimeout($SS.options._liveTimer);
                if (!$("#oneechan-options").exists()) return;
                $SS.init(true, $SS.options.collect());
            },
            applyLiveSoon: function () {
                clearTimeout($SS.options._liveTimer);
                $SS.options._liveTimer = setTimeout($SS.options.applyLive, 250);
            },
            touched: function () {
                $SS.options.dirty = true;
                $SS.options.applyLive();
            },
            /* Re-applies settings: the panel's live values while it is open,
               the stored ones otherwise */
            refresh: function () {
                if ($("#oneechan-options").exists()) $SS.options.applyLive();
                else $SS.init(true);
            },
            keydown: function (e) {
                if (e.ctrlKey && e.key === "F1") {
                    e.preventDefault();
                    e.stopPropagation();
                    $SS.options.show();
                } else if (e.key === "Escape") {
                    var cancel = document.querySelector("#overlay2 a[name=cancel], #overlay2 a[name=mCancel], #overlay2 a[name=nCancel]");
                    if (cancel) {
                        e.preventDefault();
                        e.stopPropagation();
                        cancel.click();
                    } else if ($("#overlay").exists()) {
                        e.preventDefault();
                        e.stopPropagation();
                        $SS.options.close();
                    }
                }
            },
            /* Persists only theme state (list, selection, hidden). Callers
               re-apply with $SS.init(true). Guarded: writing while the
               panel is gone would collect nothing and wipe every user
               theme from storage. */
            saveThemeState: function () {
                if (!$("#oneechan-options #themes-section").exists())
                    return false;

                var themes = [],
                    selectedTheme;

                $("#oneechan-options #themes-section>div").each(function () {
                    var oldIndex = parseInt(this.id.substr(5), 10),
                        t = $SS.conf["Themes"][oldIndex];
                    if (t && !t.default && !t._isPreview) {
                        // Editor bookkeeping must not reach storage
                        delete t.modified;
                        delete t.mHandler;
                        themes.push(t);
                    }
                });

                selectedTheme = (selectedTheme = $("#oneechan-options #themes-section>div.selected")).exists() ?
                    parseInt(selectedTheme.attr("id").substr(5), 10) : 0;
                // Ensure selectedTheme is valid
                if (selectedTheme >= $SS.conf["Themes"].length || !$SS.conf["Themes"][selectedTheme]) {
                    selectedTheme = 0;
                }

                $SS.Config.set("Themes", themes);
                $SS.Config.set("Selected Theme", selectedTheme);
                // Kept in step with the selection: StyleChan-format exports
                // still carry the key
                $SS.Config.set("NSFW Theme", selectedTheme);
                $SS.Config.set("Hidden Themes", $SS.conf["Hidden Themes"]);
                return true;
            },
            /* Rebuilds the Dark/Light Theme select options after the theme
               list changes shape (delete/import), so their indices can't go
               stale against the compacted array */
            refreshThemeSelects: function () {
                $("#oneechan-options select[name='Dark Theme'], #oneechan-options select[name='Light Theme']").each(function () {
                    var cur = parseInt($SS.conf[this.name], 10) || 0,
                        html = "";
                    for (var i = 0, MAX = $SS.conf["Themes"].length; i < MAX; ++i)
                        html += "<option value='" + i + "'" + (i === cur ? " selected" : "") + ">" +
                            $SS.escapeHTML($SS.conf["Themes"][i].name) + "</option>";
                    this.innerHTML = html;
                });
            },
            /* Options wired up once at page load (listeners, form hooks,
               link rewrites) and integrations that cannot be switched off
               without a reload */
            reloadKeys: ["Follow Cursor", "Auto-Convert Images", "Remember Comment Draft", "Watch Thread on Reply",
                "Catalog Links", "Pin Quick Reply", "Autohide Style"],
            reloadWhenOff: ["Auto Scroll", "Sauce Links", "Catalog Highlights", "Replace Thumbnails",
                "Replace GIF", "Replace JPG", "Replace PNG", "Replace WEBP", "Replace WEBM/MP4"],
            noteReloadNeeded: function (before) {
                var changed = [];
                $SS.options.reloadKeys.forEach(function (k) {
                    if (before[k] !== $SS.conf[k]) changed.push(k);
                });
                $SS.options.reloadWhenOff.forEach(function (k) {
                    if (before[k] === true && $SS.conf[k] === false) changed.push(k);
                });
                if (!changed.length) return;
                var content = document.createElement("span"),
                    link = document.createElement("a");
                content.appendChild(document.createTextNode("Applies after a reload: " + changed.join(", ") + ". "));
                link.href = "javascript:;";
                link.textContent = "Reload now";
                link.addEventListener("click", function (e) { e.preventDefault(); location.reload(); });
                content.appendChild(link);
                $SS.notify({ type: "info", content: content, lifetime: 10 });
            },
            save: function () {
                // Never write from a dead panel: the collectors below would
                // see nothing and wipe stored state
                if (!$("#oneechan-options").exists())
                    return;
                var before = $SS.options._baseline || {},
                    vals = $SS.options.collect();
                $SS.Config.failed = [];

                for (var name in vals)
                    if (name !== "Selected Theme" && name !== "NSFW Theme")
                        $SS.Config.set(name, vals[name]);

                $SS.options.saveThemeState();
                $SS.options.dirty = false;

                if ($SS.options.saveAndClose)
                    $SS.options.close(true);

                $SS.init(true);
                $SS.options.noteReloadNeeded(before);
                if ($SS.Config.failed.length)
                    $SS.notify({ type: "warning", lifetime: 10,
                        content: "Could not save " + $SS.Config.failed.join(", ") + " (storage full or blocked?)." });
            },
            /* Settings import: accepts StyleTower, upstream StyleChan and
               original OneeChan exports, normalizing renamed keys and both
               foreign mascot formats into ours */
            importSettings: function (imported) {
                // OneeChan's default theme list in its own order (v5.x): its
                // exported theme indices point into this, not into our list
                var ONEECHAN_THEMES = ["Vimyanized Dark", "Muted", "Surf", "Stilig",
                        "Minimalistic Mayhem", "Blackboard", "Dark Flat", "Yukimura",
                        "Photons + Odin", "Photon", "Original Minimalistic Mayhem",
                        "Tomorrow", "Yotsuba", "Yotsuba B", "Yotsuba Purple",
                        "安心院なじみ", "Solarized Dark", "4chan Rewired Modded",
                        "4chan Dark Upgrade", "Yasashii", "AppChan", "Zenburned",
                        "Monokai", "Ao ni sarasu", "Blue Tone", "Cold Snap",
                        "Midnight Caek", "Cyber Blue", "Colorblind", "Stalenhag",
                        "Blue Phallus", "Prisma Magica"],
                    keyMap = {
                        "Use StyleChan Icons": "Use StyleTower Icons",
                        "Style 4chanX Notifications": "Style Holotower TS Notifications",
                        "Post Decoration Style": "Decoration Style",
                        "Post Decoration Width": "Decoration Width",
                        "Post Highlight Style": "Highlight Style"
                    },
                    num = function (v) {
                        var n = parseInt(v, 10);
                        return isNaN(n) ? 0 : n;
                    },
                    rawMascots = imported["Mascots"],
                    // OneeChan stores mascots as a plain array (and has no
                    // master toggle); StyleChan/StyleTower as a JSON string
                    isOneeChan = Array.isArray(rawMascots) || ("Version Fix" in imported),
                    mascots = null;

                // OneeChan's three-state scrollbars → our two toggles
                if (typeof imported["Scrollbar Type"] === "number") {
                    imported["Style Scrollbars"] = imported["Scrollbar Type"] > 0;
                    imported["Thin Scrollbars"] = imported["Scrollbar Type"] === 2;
                }

                if (typeof rawMascots === "string") {
                    try { mascots = JSON.parse(rawMascots); } catch (e) { mascots = null; }
                } else if (Array.isArray(rawMascots)) {
                    mascots = rawMascots;
                }
                if (Array.isArray(mascots)) {
                    var grayAll = imported["Grayscale Mascots"] === true;
                    mascots = mascots.filter(function (m) {
                        return m && (m.url || m.img);
                    }).map(function (m) {
                        var out = {
                            name: m.name || "",
                            url: m.url || m.img,
                            width: m.width || "auto",
                            height: m.height || "auto",
                            opacity: m.opacity == null ? 100 : num(m.opacity),
                            offset: num(m.offset),
                            hoffset: num(m.hoffset),
                            flip: m.flip === true,
                            enabled: m.enabled !== false
                        };
                        if (m.scale) out.scale = num(m.scale);
                        if (m.scaleBase) out.scaleBase = String(m.scaleBase);
                        // OneeChan marks maxwidth per mascot; keep both states
                        // explicit so our global default can't flip them
                        if (m.maxwidth === false) out.maxwidth = false;
                        else if (m.maxwidth === true) out.maxwidth = true;
                        if (m.side === "left" || m.side === "right") out.side = m.side;
                        if (m.boards) out.boards = String(m.boards);
                        // ours is an array; OneeChan uses flat tclip/lclip/…
                        var clip = Array.isArray(m.clip) ? m.clip :
                            [num(m.tclip), num(m.lclip), num(m.bclip), num(m.rclip)];
                        if (clip[0] || clip[1] || clip[2] || clip[3]) out.clip = clip;
                        var fl = {}, fk, has = false;
                        for (fk in (m.filters || {})) fl[fk] = m.filters[fk];
                        if (grayAll && fl.gray == null) fl.gray = 100;
                        for (fk in fl) { has = true; break; }
                        if (has) out.filters = fl;
                        return out;
                    });
                    imported["Mascots"] = JSON.stringify(mascots);
                    if (imported["Enable Mascots"] === undefined && mascots.length)
                        imported["Enable Mascots"] = true;
                }
                delete imported["Grayscale Mascots"];

                // Custom themes: each goes through the theme-file sanitizer so
                // foreign flags and editor bookkeeping stay out of storage. The
                // stored list is replaced, so theme indices below are checked
                // against defaults + what was just imported
                var themeCount = ($SS.conf["Themes"] || []).length;
                if (Array.isArray(imported["Themes"])) {
                    var themes = [];
                    imported["Themes"].forEach(function (t) {
                        if (t && typeof t === "object" && !Array.isArray(t))
                            themes.push($SS.options.sanitizeTheme(t));
                    });
                    $SS.Config.set("Themes", themes);
                    themeCount = $SS.Themes.defaults.length + themes.length;
                }

                for (var key in imported) {
                    var target = keyMap[key] || key,
                        val = imported[key];
                    // Foreign bookkeeping never transfers
                    if (/^(Themes|Selected Mascots|Hidden Mascots|Total Mascots|Version Fix|Scrollbar Type)$/.test(target))
                        continue;
                    if (/^Saved4chan\./.test(key))
                        continue;
                    // Site settings saved into an export: store them where the
                    // Restore button reads (raw strings, as localStorage holds them)
                    if (/^SavedSite\./.test(key)) {
                        $SS.Config.set("SavedSiteSettings." + key.slice(10),
                            typeof val === "string" ? val : JSON.stringify(val));
                        continue;
                    }
                    // Retired option: the site's own Show relative time replaced it
                    if (key === "Relative Post Dates") {
                        if (val === true) { try { localStorage.show_relative_time = "true"; } catch (e) {} }
                        continue;
                    }
                    if (target === "Hidden Themes") {
                        // Indices into the default list; OneeChan's list differs
                        if (isOneeChan || !Array.isArray(val)) continue;
                        val = val.filter(function (i) {
                            return typeof i === "number" && i >= 0 && i < $SS.Themes.defaults.length;
                        });
                    } else if (/^(Selected Theme|NSFW Theme|Dark Theme|Light Theme)$/.test(target)) {
                        if (typeof val !== "number" || val < 0) continue;
                        if (isOneeChan) {
                            // OneeChan's theme order differs from ours: resolve
                            // the index to a theme name, then find that name in
                            // our list. Themes we don't ship are skipped
                            var tName = ONEECHAN_THEMES[val], mapped = -1;
                            ($SS.conf["Themes"] || []).forEach(function (t, ti) {
                                if (mapped === -1 && t && t.name === tName) mapped = ti;
                            });
                            if (mapped === -1) continue;
                            val = mapped;
                        } else if (val >= themeCount) {
                            // StyleChan/StyleTower share the default list;
                            // just guard the range
                            continue;
                        }
                    } else if (!(target in defaultConfig)) {
                        continue;
                    } else if (val === null || typeof val === "object") {
                        // Plain options hold primitives; anything else is junk
                        continue;
                    }
                    $SS.Config.set(target, val);
                }
            },
            /* Mascots tab (OneeChan-style gallery + editor over a working copy) */
            mascotName: function (m, i) {
                if (m.name) return m.name;
                var base = String(m.url || "").split("/").pop().split("?")[0]
                    .replace(/\.[a-z0-9]+$/i, "").replace(/[_-]+/g, " ").trim();
                if (/^data:/i.test(m.url || "") || !base) base = "Mascot " + (i + 1);
                return base;
            },
            mascotGalleryHTML: function () {
                var work = $SS.options._mascotWork || [],
                    esc = $SS.escapeHTML,
                    html = ["<div class='option mascot-gallery-wrap'>",
                        "<p class='mascot-controls'>",
                        "<a class='options-button mascot-add' title='Add a new mascot.'>Add Mascot</a>",
                        "<a class='options-button mascot-select-all' title='Select every mascot.'>All</a>",
                        "<a class='options-button mascot-select-none' title='Deselect every mascot.'>None</a>",
                        "<span class='mascot-hint'>Click a tile to select it; hover a tile to edit or delete.</span></p>",
                        "<div class='mascot-gallery'>"];
                if (!work.length)
                    html.push("<span class='mascot-empty'>No mascots yet &mdash; use Add Mascot to create one.</span>");
                work.forEach(function (m, i) {
                    var name = esc($SS.options.mascotName(m, i)),
                        filterCSS = $SS.mascotFilterCSS(m),
                        tileStyle = (m.flip ? "transform:scaleX(-1);" : "") + (filterCSS ? "filter:" + filterCSS + ";" : "");
                    html.push("<div class='mascot-tile" + (m.enabled !== false ? " selected" : "") + "' data-idx='" + i + "'>" +
                        "<img src=\"" + esc(m.url) + "\" loading='lazy'" + (tileStyle ? " style='" + tileStyle + "'" : "") + ">" +
                        "<span class='mascot-tile-name' title=\"" + name + "\">" + name + "</span>" +
                        "<span class='mascot-tile-btns'><a class='mascot-edit' title='Edit mascot'>&#9998;</a><a class='mascot-del' title='Delete mascot'>&times;</a></span></div>");
                });
                html.push("</div></div>");
                return html.join("");
            },
            renderMascotGallery: function () {
                var wrap = document.querySelector("#mascot-section .mascot-gallery-wrap");
                if (!wrap) return;
                var tmp = document.createElement("div");
                tmp.innerHTML = $SS.options.mascotGalleryHTML();
                wrap.parentNode.replaceChild(tmp.firstChild, wrap);
            },
            /* One slider row of the editor dialogs */
            sliderRow: function (title, name, val, min, max, unit, tip, modeCls) {
                // A stored value past the slider's range widens it (a range
                // input clamps its value otherwise, and Save reads the range)
                var v = parseFloat(val);
                if (!isNaN(v)) {
                    min = Math.min(min, v);
                    max = Math.max(max, v);
                }
                return "<label class='add-mascot-label" + (modeCls || "") + "' title='" + tip + "'><span class='option-title'>" + title + ":</span>" +
                    "<input type=range name=" + name + " min=" + min + " max=" + max + " value='" + val + "' data-unit='" + unit + "' class='mascot-opacity'>" +
                    "<input type=number class='mascot-opacity-num' data-for='" + name + "' value='" + val + "' step=1>" +
                    "<span class='mascot-opacity-val'>" + unit + "</span></label>";
            },
            /* Keeps a slider and its typed field together: the field follows
               the slider, and a typed value past the slider's range widens it */
            syncSlider: function (el) {
                if (!el || !el.classList) return;
                if (el.type === "range" && el.classList.contains("mascot-opacity")) {
                    var num = el.parentNode.querySelector(".mascot-opacity-num");
                    if (num) num.value = el.value;
                } else if (el.classList.contains("mascot-opacity-num")) {
                    var range = el.parentNode.querySelector("input[type=range]"),
                        v = parseInt(el.value, 10);
                    if (!range || isNaN(v)) return;
                    if (v > parseInt(range.max, 10)) range.max = v;
                    if (v < parseInt(range.min, 10)) range.min = v;
                    range.value = v;
                }
            },
            /* Arrow keys step a value field in an editor: 1 per press, 10
               with Shift. Sliders take all four arrows; typed number fields
               and data-step text fields only Up/Down, so Left/Right still
               move the caret. A text value keeps its unit ("20px", "40vh");
               non-numeric text ("auto") is left alone. Firing input keeps
               the slider/field pair in sync and the live preview current */
            stepWithArrows: function (node) {
                node.addEventListener("keydown", function (e) {
                    var el = e.target;
                    if (!el || el.tagName !== "INPUT" || e.ctrlKey || e.altKey || e.metaKey) return;
                    var isRange = el.type === "range";
                    if (!isRange && el.type !== "number" && !(el.type === "text" && el.hasAttribute("data-step"))) return;
                    var dir = e.key === "ArrowUp" || (isRange && e.key === "ArrowRight") ? 1 :
                        e.key === "ArrowDown" || (isRange && e.key === "ArrowLeft") ? -1 : 0;
                    if (!dir) return;
                    var m = /^\s*(-?\d+(?:\.\d+)?)([a-z%]*)\s*$/i.exec(el.value);
                    if (!m) return;
                    e.preventDefault();
                    var v = parseFloat(m[1]) + dir * (e.shiftKey ? 10 : 1);
                    if (isRange) {
                        if (el.min !== "" && v < parseFloat(el.min)) v = parseFloat(el.min);
                        if (el.max !== "" && v > parseFloat(el.max)) v = parseFloat(el.max);
                    }
                    el.value = Math.round(v * 100) / 100 + m[2];
                    el.dispatchEvent(new Event("input", { bubbles: true }));
                });
            },
            /* Rendered size of the mascot being previewed: what the user sees
               (the img box; a window clip does not change it) */
            mascotShownSize: function () {
                var img = document.querySelector("#styletower-mascots img");
                if (!img) return null;
                var r = img.getBoundingClientRect();
                return r.width && r.height ? { width: r.width, height: r.height } : null;
            },
            refreshNavStatus: function () {
                var el = document.querySelector("#oneechan-options .st-nav-status");
                if (el) el.textContent = $SS.conf["Nav Buttons"] ? "Custom" : "Site default";
            },
            /* Navigation buttons editor: sliders plus dragging the buttons on
               the page; Save persists at once (there is no list to commit) */
            showNavEditor: function () {
                // The theme and mascot editors share the #overlay2 id; never allow two
                $("#overlay2").remove();
                var d = $SS.navButtonDefaults,
                    cur = $SS.navButtonSettings() || { scale: d.scale, x: d.x, y: d.y, gap: d.gap, reverse: d.reverse },
                    maxX = Math.max(200, (window.innerWidth || 1024) - 40),
                    maxY = Math.max(200, (window.innerHeight || 768) - 40),
                    slider = $SS.options.sliderRow,
                    div = $("<div id='st-nav-editor' class='dialog'>").html(
                        "<label class='add-mascot-label mascot-filter-head'><span class='option-title'>Navigation Buttons</span></label>" +
                        "<p class='mascot-hint'>Drag the ↑ ↓ buttons on the page to place them, or use the sliders.</p>" +
                        slider("Scale", "nScale", cur.scale, 25, 300, "%", "Size of the buttons relative to the site's 32px.") +
                        slider("Horizontal", "nX", cur.x, 0, maxX, "px", "Distance from the right edge of the window.") +
                        slider("Vertical", "nY", cur.y, 0, maxY, "px", "Distance from the bottom edge of the window.") +
                        slider("Spacing", "nGap", cur.gap, 0, 300, "px", "Gap between the two buttons (type a larger value for more).") +
                        "<label class='add-mascot-label' title='Swap the order of the two buttons.'><span class='option-title'>Reverse Order:</span><input type=checkbox name=nReverse" + (cur.reverse ? " checked" : "") + "></label>" +
                        "<div id='st-nav-buttons-container'><a class='options-button' name=nDefault title=\"Forget the custom placement and use the site's.\">Use Site Default</a><a class='options-button' name=nSave>Save</a><a class='options-button' name=nCancel>Cancel</a></div>"),
                    node = div.elems[0],
                    collect = function () {
                        var g = function (n) { return parseInt(node.querySelector("[name=" + n + "]").value, 10) || 0; };
                        return { scale: g("nScale") || 100, x: g("nX"), y: g("nY"), gap: g("nGap"), reverse: node.querySelector("[name=nReverse]").checked };
                    },
                    overlay2 = $("<div id=overlay2>").append(div),
                    box = document.getElementById("scroll-buttons"),
                    preview = function () { $SS.applyNavButtons(collect()); },
                    setField = function (n, v) {
                        var el = node.querySelector("[name=" + n + "]");
                        if (!el) return;
                        el.value = v;
                        $SS.options.syncSlider(el);
                    },
                    drag = null, dragged = false,
                    onMove = function (e) {
                        if (!drag) return;
                        // Offsets are measured from the right/bottom edges, so
                        // moving the pointer left or up grows them
                        var x = Math.min(Math.max(drag.x - (e.clientX - drag.sx), 0), maxX),
                            y = Math.min(Math.max(drag.y - (e.clientY - drag.sy), 0), maxY);
                        if (x !== drag.x || y !== drag.y) dragged = true;
                        setField("nX", x);
                        setField("nY", y);
                        preview();
                        e.preventDefault();
                    },
                    onUp = function () {
                        document.removeEventListener("mousemove", onMove);
                        document.removeEventListener("mouseup", onUp);
                        drag = null;
                    },
                    onDown = function (e) {
                        if (e.button !== 0) return;
                        var c = collect();
                        drag = { sx: e.clientX, sy: e.clientY, x: c.x, y: c.y };
                        dragged = false;
                        document.addEventListener("mousemove", onMove);
                        document.addEventListener("mouseup", onUp);
                        e.preventDefault();
                    },
                    // The click that ends a drag must not scroll the page
                    onClick = function (e) {
                        if (dragged) { dragged = false; e.preventDefault(); e.stopPropagation(); }
                    },
                    closeEditor = function () {
                        if (box) {
                            box.classList.remove("st-nav-editing");
                            box.removeEventListener("mousedown", onDown);
                            box.removeEventListener("click", onClick, true);
                        }
                        onUp();
                        overlay2.remove();
                        $("#overlay").removeClass("previewing");
                        $SS.applyNavButtons();
                        $SS.options.refreshNavStatus();
                    };
                $(document.body).append(overlay2);
                // Hide the options window while the buttons preview live
                $("#overlay").addClass("previewing");
                if (box) {
                    box.classList.add("st-nav-editing");
                    box.addEventListener("mousedown", onDown);
                    box.addEventListener("click", onClick, true);
                }
                preview();
                node.addEventListener("input", function (e) {
                    $SS.options.syncSlider(e.target);
                    preview();
                });
                $SS.options.stepWithArrows(node);
                node.addEventListener("change", preview);
                $("a[name=nSave]", div).bind("click", function () {
                    $SS.conf["Nav Buttons"] = JSON.stringify(collect());
                    $SS.Config.set("Nav Buttons", $SS.conf["Nav Buttons"]);
                    closeEditor();
                });
                $("a[name=nDefault]", div).bind("click", function () {
                    $SS.conf["Nav Buttons"] = "";
                    $SS.Config.set("Nav Buttons", "");
                    closeEditor();
                });
                $("a[name=nCancel]", div).bind("click", closeEditor);
                overlay2.bind("click", function (e) {
                    if (e.target === overlay2.elems[0]) closeEditor();
                });
            },
            showMascotEditor: function (mIndex) {
                var bEdit = typeof mIndex === "number" && mIndex >= 0,
                    work = $SS.options._mascotWork || ($SS.options._mascotWork = []),
                    m = bEdit ? work[mIndex] : {},
                    esc = $SS.escapeHTML;
                if (!m) return;
                var f = function (v, d) { return v === undefined || v === null ? d : v; },
                    clip = m.clip || [0, 0, 0, 0],
                    filters = m.filters || {},
                    advanced = $SS.conf["Advanced Mascot Editor"] === true,
                    off = parseInt(f(m.offset, 0), 10),
                    hoff = parseInt(f(m.hoffset, 0), 10),
                    slider = $SS.options.sliderRow,
                    div = $("<div id='add-mascot' class='dialog" + (advanced ? " advanced" : "") + "'>").html(
                        "<label class='add-mascot-label mascot-mode-row' title='Simple mode keeps the intuitive controls; advanced exposes raw CSS sizes, precise offsets, clipping, page side and per-board lists.'><span class='option-title'>Advanced Editing:</span><input type=checkbox name=mAdvanced" + (advanced ? " checked" : "") + "></label>" +
                        "<label class='add-mascot-label' title='Name shown in the gallery.'><span class='option-title'>Name:</span><input class='mascot-input' type=text name=mName value=\"" + esc(f(m.name, "")) + "\" placeholder='Mascot name'></label>" +
                        "<label class='add-mascot-label' title='Image URL or data URI.'><span class='option-title'>Image:</span><input class='mascot-input' type=text name=mImg value=\"" + esc(f(m.url, "")) + "\" placeholder='https://&hellip; or data:image/&hellip;'></label>" +
                        "<label class='add-mascot-label' title='Exact CSS width (e.g. 500px, 25vw). Use auto for the image&#39;s own size, scaled down to the cap when capped.'><span class='option-title'>Width:</span><input class='mascot-input' type=text data-step name=mWidth value=\"" + esc(f(m.width, "auto")) + "\"></label>" +
                        "<label class='add-mascot-label' title='Exact CSS height. Use auto to keep the image&#39;s shape.'><span class='option-title'>Height:</span><input class='mascot-input' type=text data-step name=mHeight value=\"" + esc(f(m.height, "auto")) + "\"></label>" +
                        "<label class='add-mascot-label' title='Cap this mascot at the 300px sidebar width: an auto-sized image is scaled down to fit, an exact size is shown as typed and anything past the cap is clipped out. Default follows the Mascot Max Width option; Natural Size lifts the cap.'><span class='option-title'>Max Width:</span><select name=mMaxwidth class='mascot-input'><option value='default'" + (m.maxwidth === undefined || m.maxwidth === null ? " selected" : "") + ">Default</option><option value='on'" + (m.maxwidth === true ? " selected" : "") + ">Capped</option><option value='off'" + (m.maxwidth === false ? " selected" : "") + ">Natural Size</option></select></label>" +
                        "<div class='add-mascot-label mascot-scale-row' title='Resize by percent. The sizes above are the 100% size, taken when you start scaling; an auto size scales from the size the mascot shows at, and the clip values scale with it. Single arrows step 5%, double arrows 10%, and the field itself steps 1% with the arrow keys (10% with Shift). The percent is not saved, the resized values are.'><span class='option-title'>Scale:</span>" +
                        "<a class='options-button mascot-scale-btn' data-step='-10' title='10% smaller'>&laquo;</a><a class='options-button mascot-scale-btn' data-step='-5' title='5% smaller'>&lsaquo;</a>" +
                        "<input type=number class='mascot-opacity-num mascot-scale-pct' name=mScalePct value='100' min='1' step='1'><span class='mascot-opacity-val'>%</span>" +
                        "<a class='options-button mascot-scale-btn' data-step='5' title='5% larger'>&rsaquo;</a><a class='options-button mascot-scale-btn' data-step='10' title='10% larger'>&raquo;</a>" +
                        "<a class='options-button mascot-scale-btn mascot-scale-reset' title='Back to the 100% size'>&#8634;</a></div>" +
                        slider("Opacity", "mOpacity", parseInt(f(m.opacity, 100), 10), 0, 100, "%", "0 is transparent, 100 is opaque.") +
                        slider("Raise", "mOffsetS", off, -100, 400, "px", "Slide the mascot up from the bottom edge.", " simple-only") +
                        slider("Push In", "mHOffsetS", hoff, -100, 400, "px", "Slide the mascot away from the screen edge toward the center.", " simple-only") +
                        "<label class='add-mascot-label adv-only' title='Positive values lift the mascot up from the bottom edge; negative push it down.'><span class='option-title'>Vertical Offset:</span><input class='mascot-input' type=text data-step name=mOffset value='" + off + "px'></label>" +
                        "<label class='add-mascot-label adv-only' title='Positive values push the mascot from the screen edge toward the center; negative push it off-screen.'><span class='option-title'>Horizontal Offset:</span><input class='mascot-input' type=text data-step name=mHOffset value='" + hoff + "px'></label>" +
                        "<label class='add-mascot-label adv-only' title='Which side of the page the mascot sits on. Auto follows the sidebar position.'><span class='option-title'>Side:</span><select name=mSide class='mascot-input'><option value='auto'" + (f(m.side, "auto") === "auto" ? " selected" : "") + ">Auto</option><option value='right'" + (m.side === "right" ? " selected" : "") + ">Right</option><option value='left'" + (m.side === "left" ? " selected" : "") + ">Left</option></select></label>" +
                        "<label class='add-mascot-label adv-only' title='Clip the edges of the image as displayed, in pixels: top, left, bottom, right. Left/right always mean the visible sides, even when the image is flipped.'><span class='option-title'>Clip (T/L/B/R):</span>" +
                        "<span class='mascot-clip-inputs'><input class='mascot-input mascot-clip' type=text data-step name=mTClip value='" + parseInt(f(clip[0], 0), 10) + "'><input class='mascot-input mascot-clip' type=text data-step name=mLClip value='" + parseInt(f(clip[1], 0), 10) + "'><input class='mascot-input mascot-clip' type=text data-step name=mBClip value='" + parseInt(f(clip[2], 0), 10) + "'><input class='mascot-input mascot-clip' type=text data-step name=mRClip value='" + parseInt(f(clip[3], 0), 10) + "'></span></label>" +
                        "<label class='add-mascot-label' title='Flip the mascot image horizontally.'><span class='option-title'>Flip Image:</span><input type=checkbox name=mFlip" + (m.flip ? " checked" : "") + "></label>" +
                        "<label class='add-mascot-label mascot-filter-head'><span class='option-title'>Image Filters</span></label>" +
                        slider("Grayscale", "mFGray", parseInt(f(filters.gray, 0), 10), 0, 100, "%", "Desaturate the mascot.") +
                        slider("Sepia", "mFSepia", parseInt(f(filters.sepia, 0), 10), 0, 100, "%", "Warm brownish tone.") +
                        slider("Invert", "mFInvert", parseInt(f(filters.invert, 0), 10), 0, 100, "%", "Invert the image colors.") +
                        slider("Hue Rotate", "mFHue", parseInt(f(filters.hue, 0), 10), 0, 360, "°", "Shift every color around the hue wheel.") +
                        slider("Brightness", "mFBright", parseInt(f(filters.bright, 100), 10), 0, 200, "%", "100 is the original brightness.") +
                        slider("Contrast", "mFContrast", parseInt(f(filters.contrast, 100), 10), 0, 200, "%", "100 is the original contrast.") +
                        slider("Saturation", "mFSat", parseInt(f(filters.sat, 100), 10), 0, 200, "%", "100 is the original saturation; above boosts colors.") +
                        slider("Blur", "mFBlur", parseInt(f(filters.blur, 0), 10), 0, 20, "px", "Gaussian blur radius.") +
                        "<label class='add-mascot-label adv-only' title='Comma-separated boards to show this mascot on. Leave empty for all boards. Example: hlgg,jp'><span class='option-title'>Boards:</span><input class='mascot-input' type=text name=mBoards value=\"" + esc(f(m.boards, "")) + "\" placeholder='all boards'></label>" +
                        "<div id='mascot-buttons-container'><a class='options-button' name=mSave>" + (bEdit ? "Save Mascot" : "Add Mascot") + "</a><a class='options-button' name=mCancel>Cancel</a></div>"),
                    node = div.elems[0],
                    collect = function () {
                        var g = function (n) {
                                var el = node.querySelector("[name=" + n + "]");
                                return el ? el.value : "";
                            },
                            num = function (v) {
                                var n = parseInt(v, 10);
                                return isNaN(n) ? 0 : n;
                            };
                        var fl = {};
                        if (num(g("mFGray"))) fl.gray = num(g("mFGray"));
                        if (num(g("mFSepia"))) fl.sepia = num(g("mFSepia"));
                        if (num(g("mFInvert"))) fl.invert = num(g("mFInvert"));
                        if (num(g("mFHue"))) fl.hue = num(g("mFHue"));
                        if (num(g("mFBright")) !== 100) fl.bright = num(g("mFBright"));
                        if (num(g("mFContrast")) !== 100) fl.contrast = num(g("mFContrast"));
                        if (num(g("mFSat")) !== 100) fl.sat = num(g("mFSat"));
                        if (num(g("mFBlur"))) fl.blur = num(g("mFBlur"));
                        var hasFilters = Object.keys(fl).length > 0;
                        var sideVal = g("mSide");
                        return {
                            name: g("mName").trim(),
                            url: g("mImg").trim(),
                            maxwidth: g("mMaxwidth") === "on" ? true :
                                g("mMaxwidth") === "off" ? false : undefined,
                            width: g("mWidth").trim() || "auto",
                            height: g("mHeight").trim() || "auto",
                            opacity: num(g("mOpacity")),
                            offset: num(g("mOffset")),
                            hoffset: num(g("mHOffset")),
                            side: sideVal === "left" || sideVal === "right" ? sideVal : undefined,
                            clip: [num(g("mTClip")), num(g("mLClip")), num(g("mBClip")), num(g("mRClip"))],
                            flip: !!node.querySelector("[name=mFlip]").checked,
                            filters: hasFilters ? fl : undefined,
                            boards: g("mBoards").trim(),
                            enabled: bEdit ? m.enabled !== false : true
                        };
                    },
                    overlay2 = $("<div id=overlay2>").append(div),
                    preview = function () {
                        var o = collect();
                        if (o.url) $SS.displayMascots(o);
                    },
                    closeEditor = function () {
                        overlay2.remove();
                        $("#overlay").removeClass("previewing");
                        $SS.displayMascots();
                    };
                // The theme editor shares the #overlay2 id; never allow two
                $("#overlay2").remove();
                $(document.body).append(overlay2);
                // Hide the options window while the editor previews on the live
                // page (same pattern as the theme editor)
                $("#overlay").addClass("previewing");
                preview();
                var setField = function (name, val) {
                    var el = node.querySelector("[name=" + name + "]");
                    if (!el) return;
                    el.value = val;
                    $SS.options.syncSlider(el);
                };
                // Scale tool: rewrites Width, Height and the clip values by a
                // percentage of their values at 100%, captured when scaling
                // starts. An auto size scales from the size the mascot shows
                // at (what the user sees, not the raw image); a lone auto side
                // stays auto so the image keeps its shape. The percent is
                // never saved; typing a size by hand makes it the new 100%
                var clipNames = ["mTClip", "mLClip", "mBClip", "mRClip"],
                    scaledFields = ["mWidth", "mHeight"].concat(clipNames),
                    pctField = node.querySelector("[name=mScalePct]"),
                    scaleBase = null,
                    readField = function (n) { return node.querySelector("[name=" + n + "]").value; },
                    captureBase = function () {
                        scaleBase = {
                            width: readField("mWidth").trim() || "auto",
                            height: readField("mHeight").trim() || "auto",
                            clip: clipNames.map(function (n) { return parseInt(readField(n), 10) || 0; }),
                            shown: $SS.options.mascotShownSize()
                        };
                    },
                    scaleSize = function (v, pct, shownPx) {
                        var mt = /^(-?\d+(?:\.\d+)?)([a-z%]*)$/i.exec(v);
                        if (mt) {
                            var n = parseFloat(mt[1]) * pct / 100;
                            return (!mt[2] || mt[2] === "px" ? Math.round(n) : Math.round(n * 100) / 100) + mt[2];
                        }
                        return shownPx ? Math.round(shownPx * pct / 100) + "px" : v;
                    },
                    applyScale = function (pct) {
                        pct = Math.max(1, Math.round(pct) || 100);
                        if (!scaleBase) captureBase();
                        var b = scaleBase,
                            autoBoth = b.width === "auto" && b.height === "auto";
                        pctField.value = pct;
                        if (pct === 100) {
                            setField("mWidth", b.width);
                            setField("mHeight", b.height);
                        } else {
                            setField("mWidth", scaleSize(b.width, pct, autoBoth && b.shown ? b.shown.width : 0));
                            setField("mHeight", b.height === "auto" ? "auto" : scaleSize(b.height, pct, 0));
                        }
                        clipNames.forEach(function (n, i) {
                            setField(n, pct === 100 ? b.clip[i] : Math.round(b.clip[i] * pct / 100));
                        });
                        if (pct === 100) scaleBase = null;
                        preview();
                    };
                node.addEventListener("click", function (e) {
                    var btn = e.target.closest && e.target.closest(".mascot-scale-btn");
                    if (!btn) return;
                    e.preventDefault();
                    if (btn.classList.contains("mascot-scale-reset")) applyScale(100);
                    else applyScale((parseInt(pctField.value, 10) || 100) + parseInt(btn.getAttribute("data-step"), 10));
                });
                node.addEventListener("input", function (e) {
                    var t = e.target;
                    if (t.name === "mScalePct") {
                        var pct = parseInt(t.value, 10);
                        if (pct >= 1) applyScale(pct);
                        return;
                    }
                    if (scaledFields.indexOf(t.name) !== -1) {
                        scaleBase = null;
                        pctField.value = 100;
                    }
                    $SS.options.syncSlider(t);
                    // The simple-mode position sliders and the advanced offset
                    // inputs edit the same values; keep them in sync (the text
                    // inputs are what collect() reads)
                    if (t.name === "mOffsetS") setField("mOffset", t.value + "px");
                    else if (t.name === "mHOffsetS") setField("mHOffset", t.value + "px");
                    else if (t.name === "mOffset") setField("mOffsetS", parseInt(t.value, 10) || 0);
                    else if (t.name === "mHOffset") setField("mHOffsetS", parseInt(t.value, 10) || 0);
                    preview();
                });
                $SS.options.stepWithArrows(node);
                node.addEventListener("change", function (e) {
                    if (e.target.name === "mAdvanced") {
                        var adv = e.target.checked;
                        node.classList.toggle("advanced", adv);
                        $SS.conf["Advanced Mascot Editor"] = adv;
                        $SS.Config.set("Advanced Mascot Editor", adv);
                    }
                    preview();
                });
                $("a[name=mSave]", div).bind("click", function () {
                    var obj = collect();
                    if (obj.url) {
                        if (bEdit) work[mIndex] = obj;
                        else work.push(obj);
                        $SS.options.renderMascotGallery();
                        $SS.options.touched();
                    }
                    closeEditor();
                });
                $("a[name=mCancel]", div).bind("click", closeEditor);
                overlay2.bind("click", function (e) {
                    if (e.target === overlay2.elems[0]) closeEditor();
                });
            },
            showTheme: function (tIndex) {
                // The mascot editor shares the #overlay2 id; never allow two
                $("#overlay2").remove();
                var div, overlay, previewThemeIndex = -1,
                    bEdit = typeof tIndex === "number",
                    tEdit = bEdit ? $SS.conf["Themes"][tIndex] : null,
                    themeIndex = tIndex,
                    originalSelectedTheme = $SS.conf["Selected Theme"], // Store originally selected theme
                    esc = $SS.escapeHTML,
                    // New themes seed from the selected theme instead of
                    // all-black fields, so creating one starts from what's
                    // on screen rather than blanking the page
                    seed = bEdit ? tEdit :
                        ($SS.conf["Themes"][originalSelectedTheme] || $SS.conf["Themes"][0] || {}),
                    RPA, themeR, themePY, themePX, themeA;

                if (seed.bgImg && seed.bgRPA) {
                    RPA = seed.bgRPA.split(" ");
                    themeR = RPA[0];
                    themePY = RPA[1];
                    themePX = RPA[2];
                    themeA = RPA[3];
                }

                div = $("<div id='add-theme' class='dialog'>");

                var switchBtn = "<span class='side-switch' title='Switch side'>&#8646;</span>";

                var previewPost = switchBtn + "<div class='theme-preview-post' data-color='mainColor'>" +
                    "<div class='preview-border' data-color='mainColor'>" +
                    "<span class='preview-subject' data-color='titleColor'>Post Subject</span><br>" +
                    "<span class='preview-name' data-color='nameColor'>Anonymous</span>" +
                    "<span class='preview-trip' data-color='tripColor'> !tripcode</span>" +
                    "<span class='preview-date' data-color='textColor'> 10/01/03(Mon)12:00:00</span>" +
                    // Link-styled spans, not anchors: the site/TS quote
                    // handlers bind to any >>-style anchor added to the DOM
                    // and would treat these as real quotelinks
                    "<span class='preview-postnum'> <span class='preview-link' data-color='linkColor'>No.12345678</span></span>" +
                    "<br><span class='preview-backlink' data-color='blinkColor'><span class='preview-link'>&gt;&gt;12345678</span></span>" +
                    "<div class='theme-preview-hover' data-color='hoverColor' title='Backlink hover preview'>" +
                    "<span class='preview-name'>Anonymous</span><span class='preview-date'> 10/01/03(Mon)11:59:59</span>" +
                    "<br>I appear when hovering the quotelink above." +
                    "</div>" +
                    "<span class='preview-quote' data-color='quoteColor'>&gt;be me, clickable</span>" +
                    "<br><span data-color='textColor'>I'm a dummy post and example text.</span>" +
                    "</div></div>";

                var seedBG = seed.bgImg && ($SS.validImageURL(seed.bgImg) || $SS.validBase64(seed.bgImg)) ? seed.bgImg : "";
                var innerHTML = previewPost + "<div class='theme-body'><div class='theme-fields'><label>" +
                    "<span class='option-title'>Theme Name:</span><input type=text name=name value=\"" + (bEdit ? esc(tEdit.name) : "") + "\">" +
                    "</label><label>" +
                    "<span class='option-title'>Author Name:</span><input type=text name=authorName value=\"" + (bEdit ? esc(tEdit.authorName) : "") + "\">" +
                    "</label><label>" +
                    "<span class='option-title'>Author Tripcode:</span><input type=text name=authorTrip value=\"" + (bEdit ? esc(tEdit.authorTrip) : "") + "\">" +
                    "</label><label>" +
                    "<span class='option-title'>BG Image:</span><input type=text name=bgImg value=\"" + esc(seedBG) + "\"></label><label>" +
                    "<span class='option-title'>BG Repeat:</span><select name=bgR>" +
                    "<option" + (themeR === "no-repeat" ? " selected" : "") + ">no-repeat</option>" +
                    "<option" + (themeR === "repeat" ? " selected" : "") + ">repeat</option>" +
                    "<option" + (themeR === "repeat-x" ? " selected" : "") + ">repeat-x</option>" +
                    "<option" + (themeR === "repeat-y" ? " selected" : "") + ">repeat-y</option>" +
                    "</select></label><label>" +
                    "<span class='option-title'>BG Attachment:</span><select name=bgA>" +
                    "<option" + (themeA === "fixed" ? " selected" : "") + ">fixed</option>" +
                    "<option" + (themeA === "scroll" ? " selected" : "") + ">scroll</option>" +
                    "</select></label><label>" +
                    "<span class='option-title'>BG Position-X:</span><select name=bgPX>" +
                    "<option" + (themePX === "left" ? " selected" : "") + ">left</option>" +
                    "<option" + (themePX === "center" ? " selected" : "") + ">center</option>" +
                    "<option" + (themePX === "right" ? " selected" : "") + ">right</option>" +
                    "</select></label><label>" +
                    "<span class='option-title'>BG Position-Y:</span><select name=bgPY>" +
                    "<option" + (themePY === "top" ? " selected" : "") + ">top</option>" +
                    "<option" + (themePY === "center" ? " selected" : "") + ">center</option>" +
                    "<option" + (themePY === "bottom" ? " selected" : "") + ">bottom</option>" +
                    "</select></label><label>" +
                    "<span class='option-title'>Reply Opacity:</span><input type=text name=replyOp value='" + $SS.normalizeOpacity(seed.replyOp, "1.0") + "'></label><label>" +
                    "<span class='option-title'>Header Opacity:</span><input type=text name=navOp value='" + $SS.normalizeOpacity(seed.navOp, "0.9") + "'>" +
                    "</label><label>" +
                    "<span class='option-title'>Hover Opacity:</span><input type=text name=hoverOp value='" + $SS.normalizeOpacity(seed.hoverOp, "0.8") + "'></label><label>" +
                    "<span class='option-title'>Hover Outline Opacity:</span><input type=text name=hoverOutOp value='" + $SS.normalizeOpacity(seed.hoverOutOp, "0.5") + "'>" +
                    "</label>";

                for (var i = 0, MAX = themeInputs.length; i < MAX; ++i) {
                    var hex = $SS.normalizeHex(seed[themeInputs[i].name]);
                    if (!hex && themeInputs[i].name === "hoverColor") // absent on pre-hoverColor themes: show the derived default
                        hex = $SS.hexFromRGB(new $SS.Color(seed.mainColor).shiftRGB(-16).split(","));
                    if (!hex && themeInputs[i].name === "hoverOutColor") // ditto: outline derives from the link color
                        hex = $SS.normalizeHex(seed.linkColor);
                    hex = hex || "000000";
                    var rgb = $SS.RGBFromHex(hex);
                    var textColor = $SS.isLight(rgb) ? "#000" : "#fff";
                    innerHTML += "<label><span class='option-title'>" + themeInputs[i].dName + ":</span>" +
                        "<span class=color-picker-wrap>" +
                        "<input type=text name=" + themeInputs[i].name + " value=\"" + hex + "\" autocomplete=off " +
                            "class=color-hex style='background:#" + hex + " !important;color:" + textColor + " !important'>" +
                        "<input type=color value=\"#" + hex + "\" class=color-picker-btn>" +
                        "</span></label>";
                }

                innerHTML += "</div><label id=customCSS><span class='option-title'>Custom CSS:</span><textarea name=customCSS class='field'></textarea>" +
                    "</label></div><div class='theme-buttons'>" +
                    "<a class='options-button' name=export>Export</a>" +
                    "<a class='options-button' name=" + (bEdit ? "edit" : "add") + ">Save</a><a class='options-button' name=cancel>Cancel</a></div>";

                div.html(innerHTML);
                if (seed.customCSS)
                    div.elems[0].querySelector("textarea[name=customCSS]").value = seed.customCSS;

                $(".side-switch", div).bind("click", function () {
                    div.elems[0].classList.toggle("left");
                });

                // Click preview elements to focus color inputs
                $("[data-color]", div).bind("click", function (e) {
                    e.preventDefault();
                    e.stopPropagation();
                    var name = this.getAttribute("data-color"),
                        input = div.elems[0].querySelector("input[name='" + name + "']");
                    if (input) {
                        input.focus();
                        input.select();
                        $("label.picked", div).removeClass("picked");
                        var label = input.closest("label");
                        if (label) label.classList.add("picked");
                    }
                });

                // Live preview function
                var updateLivePreview = function () {
                    var overlay = $("#overlay2"),
                        previewTheme = {},
                        makeRPA = function () {
                            var RPA = [];
                            RPA.push($("select[name=bgR]", overlay).val() || "repeat");
                            RPA.push($("select[name=bgPY]", overlay).val() || "top");
                            RPA.push($("select[name=bgPX]", overlay).val() || "left");
                            RPA.push($("select[name=bgA]", overlay).val() || "scroll");
                            return RPA.join(" ");
                        };

                    // Collect the named fields; empty ones fall back to the base
                    // theme below. A half-typed hex would preview as black, so
                    // colors only count once they normalize
                    $("input,textarea,select", overlay).each(function () {
                        var val = this.value;
                        if (!this.name || val === "") return;
                        if (this.classList.contains("color-hex")) {
                            val = $SS.normalizeHex(val);
                            if (!val) return;
                        }
                        previewTheme[this.name] = val;
                    });

                    // Set defaults for missing values
                    if (bEdit && tEdit) {
                        // When editing, use the original theme as base
                        for (var key in tEdit) {
                            if (previewTheme[key] === undefined && typeof tEdit[key] !== "object" && key !== "default") {
                                previewTheme[key] = tEdit[key];
                            }
                        }
                    } else {
                        // For new themes, use the currently selected theme as base (not first theme)
                        var baseTheme = $SS.conf["Themes"][originalSelectedTheme] || $SS.conf["Themes"][0];
                        for (var key in baseTheme) {
                            if (previewTheme[key] === undefined && typeof baseTheme[key] !== "object" && key !== "default") {
                                previewTheme[key] = baseTheme[key];
                            }
                        }
                    }

                    if (previewTheme.bgImg)
                        previewTheme.bgRPA = makeRPA();

                    // Create temporary theme in themes array
                    // Mark it as preview so we can identify and remove it later
                    previewTheme._isPreview = true;
                    if (previewThemeIndex === -1) {
                        previewThemeIndex = $SS.conf["Themes"].length;
                        $SS.conf["Themes"].push(previewTheme);
                    } else {
                        $SS.conf["Themes"][previewThemeIndex] = previewTheme;
                    }

                    // Temporarily switch to preview theme
                    $SS.conf["Selected Theme"] = previewThemeIndex;
                    $SS.theme = new $SS.Theme(previewThemeIndex);
                    $SS.setThemeVariables();
                    // Scheme-dependent root classes must track the preview,
                    // or light-on-dark previews render half-applied
                    document.documentElement.classList.toggle("isLight", $SS.theme.textColor.isLight === true);
                    document.documentElement.classList.toggle("dark-captcha", $SS.theme.bgColor.isLight === false);
                };

                // A color picker drag fires input events faster than frames,
                // and each preview rewrites the theme variables (a page-wide
                // restyle): one preview per frame
                var previewQueued = false,
                    queuePreview = function () {
                        if (previewQueued) return;
                        previewQueued = true;
                        requestAnimationFrame(function () {
                            previewQueued = false;
                            if (document.getElementById("add-theme")) updateLivePreview();
                        });
                    };

                // Sync color swatch to hex text input and trigger preview
                $("input[type='color']", div).bind("input change", function () {
                    var textInput = this.parentNode.querySelector(".color-hex");
                    if (textInput) {
                        var hex = this.value.replace("#", "");
                        textInput.value = hex;
                        textInput.style.setProperty("background-color", "#" + hex, "important");
                        var rgb = $SS.RGBFromHex(hex);
                        textInput.style.setProperty("color", $SS.isLight(rgb) ? "#000" : "#fff", "important");
                    }
                    queuePreview();
                });

                // Live preview on text input / textarea / select changes
                $("input[type=text],textarea,select", div).bind("input change", function () {
                    if (this.classList.contains("color-hex")) {
                        var hex = this.value.replace("#", "");
                        if (/^[0-9a-f]{6}$/i.test(hex)) {
                            this.style.setProperty("background-color", "#" + hex, "important");
                            var rgb = $SS.RGBFromHex(hex);
                            this.style.setProperty("color", $SS.isLight(rgb) ? "#000" : "#fff", "important");
                        }
                    }
                    queuePreview();
                });

                overlay = $("<div id=overlay2>").append(div);

                $("a[name=export]", div).bind("click", function () {
                    var theme = $SS.options.addTheme(themeIndex, true);
                    if (!theme || $("a[download]", div).exists())
                        return;
                    // Built via the DOM so a quote in the name can't break out
                    // of the download attribute
                    var exportalert = document.createElement("a");
                    exportalert.className = "options-button";
                    exportalert.download = (theme.name || "theme") + ".json";
                    exportalert.href = "data:application/json;base64," + btoa(unescape(encodeURIComponent(JSON.stringify(theme))));
                    exportalert.textContent = "Save me!";
                    return $(this).replace($(exportalert));
                });

                if (bEdit) {
                    $("a[name=edit]", div).bind("click", function () {
                        $SS.options.addTheme(themeIndex);
                        $("#overlay").removeClass("previewing");
                    });
                    $("#overlay").addClass("previewing");
                } else {
                    $("a[name=add]", div).bind("click", function () {
                        $SS.options.addTheme();
                    });
                    $("#overlay").addClass("previewing");
                }

                $("a[name=cancel]", div).bind("click", function () {
                    // Remove preview theme if it exists
                    if (previewThemeIndex !== -1) {
                        $SS.conf["Themes"].splice(previewThemeIndex, 1);
                    }
                    // Back to the selection the panel shows (System Theming
                    // and the other live values are honored by refresh)
                    $SS.conf["Selected Theme"] = originalSelectedTheme;
                    $SS.options.refresh();
                    $("#overlay").removeClass("previewing");
                    $("#overlay2").remove();
                });

                if (bEdit)
                    $("input,textarea,select", div).bind("change", tEdit.mHandler = function () {
                        tEdit.modified = true;
                        $("input,textarea,select", $("#add-theme")).unbind("change", tEdit.mHandler);
                    });

                return $(document.body).append(overlay);
            },
            addTheme: function (tIndex, exp) {
                var overlay = $("#overlay2");

                // Remove preview theme if it exists (from live preview).
                // Export leaves it alone: the editor stays open and the
                // preview must keep rendering
                var previewIndex = -1;
                if (!exp) {
                    for (var i = $SS.conf["Themes"].length - 1; i >= 0; i--) {
                        if ($SS.conf["Themes"][i] && $SS.conf["Themes"][i]._isPreview) {
                            previewIndex = i;
                            break;
                        }
                    }
                    if (previewIndex !== -1) {
                        $SS.conf["Themes"].splice(previewIndex, 1);
                        // Adjust tIndex if it was after the preview theme
                        if (typeof tIndex === "number" && tIndex > previewIndex) {
                            tIndex--;
                        }
                    }
                }

                var tTheme = {},
                    makeRPA = function () {
                        var RPA = [];

                        RPA.push($("select[name=bgR]", overlay).val());
                        RPA.push($("select[name=bgPY]", overlay).val());
                        RPA.push($("select[name=bgPX]", overlay).val());
                        RPA.push($("select[name=bgA]", overlay).val());

                        return RPA.join(" ");
                    },
                    bEdit = typeof tIndex === "number",
                    tEdit = bEdit ? $SS.conf["Themes"][tIndex] : null,
                    error = false,
                    div;

                if (!exp && bEdit && !tEdit.modified) {
                    // A live preview may have been spliced out above, leaving
                    // the in-memory selection dangling past the array end;
                    // re-init restores the stored state
                    if (previewIndex !== -1)
                        $SS.options.refresh();
                    return overlay.remove();
                }

                var colorNames = {},
                    opDefaults = { replyOp: "1.0", navOp: "0.9", hoverOp: "0.8", hoverOutOp: "0.5" };
                for (var c = 0, cMAX = themeInputs.length; c < cMAX; ++c)
                    colorNames[themeInputs[c].name] = themeInputs[c].dName;

                $("input[type=text],textarea", overlay).each(function () {
                    var val;

                    if (this.name === "bgImg") {
                        val = this.value;

                        if (val !== "" && !$SS.validImageURL(val) && !$SS.validBase64(val)) {
                            error = true;
                            return alert("Not a valid image URL/base64!");
                        }

                        val = $SS.cleanBase64(val);

                    } else if (this.name === "name") {
                        val = this.value;

                        if (bEdit && tEdit.default && tEdit.name === val)
                            val += " [Modded]";
                    } else if (colorNames[this.name]) {
                        // Colors must round-trip as 6-digit hex; junk here
                        // would silently kill every rule using the variable
                        val = $SS.normalizeHex(this.value);
                        if (val === null) {
                            if (this.value !== "") {
                                error = true;
                                return alert("\"" + this.value + "\" is not a valid hex color for " + colorNames[this.name] + "!");
                            }
                            val = "";
                        }
                    } else if (opDefaults[this.name] !== undefined) {
                        val = $SS.normalizeOpacity(this.value, opDefaults[this.name]);
                    } else
                        val = this.value;

                    if (val !== "")
                        tTheme[this.name] = val;
                });

                if (error) return;

                if (!tTheme.name)
                    tTheme.name = "Unnamed Theme";

                if (tTheme.bgImg)
                    tTheme.bgRPA = makeRPA();

                if (exp) return tTheme;

                if (bEdit && !tEdit.default) {
                    $SS.conf["Themes"][tIndex] = tTheme;
                    tTheme = new $SS.Theme(tIndex);
                    div = $("#theme" + tIndex, $("#overlay"));
                    var fresh = tTheme.preview();
                    if (div.exists()) {
                        // replace() returns the detached node; keep the live
                        // one so the click below lands in the document
                        div.replace(fresh);
                        div = fresh;
                    } else {
                        div = fresh;
                        $("#overlay #themes-section").append(div);
                    }
                } else {
                    if (!tTheme.authorName)
                        tTheme.authorName = "You";
                    tIndex = $SS.conf["Themes"].push(tTheme);
                    tTheme = new $SS.Theme(--tIndex);
                    div = tTheme.preview();

                    $("#overlay #themes-section").append(div);
                }

                if (div && div.exists()) {
                    // Select the saved theme explicitly rather than firing a
                    // click on its preview: the click handler's
                    // already-selected guard reads classes rendered from
                    // stale mid-preview state and can skip both the
                    // selection and the save
                    div.parent().children(".selected").removeClass("selected");
                    div.addClass("selected");
                    div.scrollIntoView(true);
                    // Under System Theming the page displays the Dark/Light
                    // mapping, not the selection; point the governing slot at
                    // the saved theme so saving is always visible
                    if ($SS.conf["System Theming"]) {
                        var slot = window.matchMedia("(prefers-color-scheme: dark)").matches ?
                            "Dark Theme" : "Light Theme";
                        $SS.conf[slot] = tIndex;
                        $SS.Config.set(slot, tIndex);
                    }
                    $SS.options.saveThemeState();
                    $SS.options.refresh();
                }

                // The list may have grown; keep the Dark/Light selects in step
                $SS.options.refreshThemeSelects();
                $("#overlay").removeClass("previewing");
                return overlay.remove();
            },
            deleteTheme: function (tIndex) {
                var t = $SS.conf["Themes"][tIndex];
                if (!t) return;

                // Defaults are hidden, not deleted
                if (t.default) {
                    if ($SS.conf["Hidden Themes"].indexOf(tIndex) === -1 &&
                        $SS.conf["Hidden Themes"].push(tIndex) === 1)
                        $("#themes-section a[name=restoreThemes]").show();
                    $SS.Config.set("Hidden Themes", $SS.conf["Hidden Themes"]);
                    var tile = $("#theme" + tIndex),
                        wasSelected = tile.hasClass("selected");
                    tile.removeClass("selected").hide();
                    // The page must not keep showing a theme the list no
                    // longer offers: fall back to the first visible one
                    if (wasSelected) {
                        for (var i = 0; i < $SS.conf["Themes"].length; i++) {
                            if (i !== tIndex && $SS.conf["Hidden Themes"].indexOf(i) === -1) {
                                $("#theme" + i).addClass("selected");
                                break;
                            }
                        }
                        $SS.options.saveThemeState();
                        $SS.options.refresh();
                    }
                    return;
                }

                if (!confirm('Delete theme "' + t.name + '"? This cannot be undone.'))
                    return;

                // Remove from the array itself, not just the DOM: every index
                // after this shifts down, so compact the index-based settings
                // and rebuild the tab or the stale div ids would persist a
                // selection pointing at the wrong (or no) theme
                $SS.conf["Themes"].splice(tIndex, 1);
                ["Selected Theme", "NSFW Theme", "Dark Theme", "Light Theme"].forEach(function (key) {
                    var v = parseInt($SS.conf[key], 10) || 0;
                    if (v === tIndex) v = 0;
                    else if (v > tIndex) v--;
                    $SS.conf[key] = v;
                    $SS.Config.set(key, v);
                });

                var tOptions = $("#oneechan-options");
                if (tOptions.exists()) {
                    $SS.options.createThemesTab(tOptions);
                    $SS.options.refreshThemeSelects();
                }

                $SS.options.saveThemeState();
                return $SS.options.refresh();
            },
        },

        /* THEMES */
        Themes: {
            defaults: [{
                name: "Yotsuba",
                authorName: "moot",
                authorTrip: "!Εр8рui8Vw2",
                "default": true,
                bgImg: "iVBORw0KGgoAAAANSUhEUgAAAAEAAADICAIAAACmkByiAAAAWElEQVR4AaWSwQ3AIAwDbfbfpdt0nKrPUp3QCfHgkfjsCMh47mskmU5HGvbmuuh9dVce8M4it/SfMZglGeZx/ccyu/Vsv4/N29f331AY5Bi3+hdo4A92+wXvCwR9mXztrAAAAABJRU5ErkJggg==",
                bgRPA: "repeat-x top center scroll",
                replyOp: "1.0",
                navOp: "0.9",
                bgColor: "ffffee",
                mainColor: "f0e0d6",
                brderColor: "d9bFb7",
                inputColor: "ffffff",
                inputbColor: "aaaaaa",
                blinkColor: "800000",
                unreadColor: "000080",
                linkColor: "0000ee",
                linkHColor: "dd0000",
                qlColor: "000080",
                nameColor: "117743",
                quoteColor: "789922",
                textColor: "800000",
                tripColor: "228854",
                titleColor: "cc1105",
                headerColor: "800000",
                headerLColor: "800000",
                headerLHColor: "dd0000",
                headerBGColor: "f0e0d6",
                boardColor: "800000",
                postHLColor: "228854",
                quotesYouHLColor: "dd0000",
                ownPostHLColor: "228854",
                threadHLColor: "dd0000",
                replybgHLColor: "d6bad0",
                replyslctColor: "228854",
                customCSS: "span.postNum.desktop > a {\ncolor: #800000 !important\n}\nspan.postNum.desktop > a:hover {\ncolor: #dd0000 !important\n}\n.menu-button {\ncolor: #800000 !important\n}"
            }, {
                name: "Yotsuba B",
                authorName: "moot",
                authorTrip: "!Εр8рui8Vw2",
                "default": true,
                bgImg: "iVBORw0KGgoAAAANSUhEUgAAAAEAAADICAIAAACmkByiAAAASUlEQVR4AcWRuQ0AIBDDzuy/HAVrMAM9slCorqAJziNgrj2qSg/cGhHnjPqDDPxOfYiebwFj+XobeLGI7p39fW1/Ib58d55Bwh3x9wRv6r75UwAAAABJRU5ErkJggg==",
                bgRPA: "repeat-x top center scroll",
                replyOp: "1.0",
                navOp: "0.9",
                bgColor: "eef2ff",
                mainColor: "d6daf0",
                brderColor: "b7c5d9",
                inputColor: "ffffff",
                inputbColor: "aaaaaa",
                blinkColor: "34345c",
                unreadColor: "34345C",
                linkColor: "34345c",
                linkHColor: "dd0000",
                qlColor: "dd0000",
                nameColor: "117743",
                quoteColor: "789922",
                textColor: "000000",
                tripColor: "228854",
                titleColor: "0f0c5d",
                headerColor: "34345c",
                headerLColor: "34345c",
                headerLHColor: "dd0000",
                headerBGColor: "d6daf0",
                boardColor: "af0a0f",
                postHLColor: "228854",
                quotesYouHLColor: "228854",
                ownPostHLColor: "228854",
                threadHLColor: "dd0000",
                replybgHLColor: "d6bad0",
                replyslctColor: "228854",
                customCSS: "span.postNum.desktop > a {\ncolor: #000000 !important\n}\nspan.postNum.desktop > a:hover {\ncolor: #dd0000 !important\n}"
            }, {
                name: "Vimyanized Dark",
                authorName: "Seaweed",
                authorTrip: "!!lq+3fff+/ev",
                "default": true,
                bgImg: false,
                replyOp: "1.0",
                navOp: "0.9",
                bgColor: "090d0f",
                mainColor: "0d1114",
                brderColor: "0b1316",
                inputColor: "090d0f",
                inputbColor: "0d1114",
                blinkColor: "4797cc",
                unreadColor: "4270b2",
                linkColor: "53bdb1",
                linkHColor: "3090b5",
                qlColor: "53bdb1",
                nameColor: "d63e34",
                quoteColor: "96c83b",
                textColor: "f8f8f8",
                tripColor: "d4b63c",
                titleColor: "b88cd1",
                headerColor: "f8f8f8",
                headerLColor: "53bdb1",
                headerLHColor: "3090b5",
                headerBGColor: "0d1114",
                boardColor: "f8f8f8",
                postHLColor: "d4b63c",
                quotesYouHLColor: "d4b63c",
                ownPostHLColor: "d4b63c",
                threadHLColor: "b88cd1",
                replybgHLColor: "090d10",
                replyslctColor: "d4b63c"
            }, {
                name: "Muted",
                authorName: "Seaweed",
                authorTrip: "!!lq+3fff+/ev",
                "default": true,
                bgImg: false,
                replyOp: "1.0",
                navOp: "0.9",
                bgColor: "ffffff",
                mainColor: "f5f2e9",
                brderColor: "dddddd",
                inputColor: "ffffff",
                inputbColor: "dddddd",
                blinkColor: "bc312a",
                unreadColor: "bc312a",
                linkColor: "bc312a",
                linkHColor: "8e2220",
                qlColor: "bc312a",
                nameColor: "2c64a0",
                quoteColor: "789922",
                textColor: "393735",
                tripColor: "cc6563",
                titleColor: "111111",
                headerColor: "393735",
                headerLColor: "bc312a",
                headerLHColor: "8e2220",
                headerBGColor: "f5f2e9",
                boardColor: "bc312a",
                postHLColor: "cc6563",
                quotesYouHLColor: "2c64a0",
                ownPostHLColor: "cc6563",
                threadHLColor: "111111",
                replybgHLColor: "d9d6cd",
                replyslctColor: "cc6563"
            }, {
                name: "Surf", //Inspired by Blue Tone
                authorName: "nebukazar",
                authorTrip: "!/Am.NeBUqQ",
                "default": true,
                bgImg: false,
                replyOp: "1.0",
                navOp: "1.0",
                mainColor: "242424",
                brderColor: "242424",
                inputColor: "1b1b1b",
                inputbColor: "252525",
                headerBGColor: "242424",
                headerColor: "ffffff",
                boardColor: "ffffff",
                bgColor: "1b1b1b",
                textColor: "ffffff",
                blinkColor: "20548f",
                headerLColor: "20548f",
                headerLHColor: "ffffff",
                linkColor: "808080",
                linkHColor: "ffffff",
                qlColor: "808080",
                nameColor: "20548f",
                tripColor: "808080",
                titleColor: "808080",
                quoteColor: "07992d",
                unreadColor: "ffffff",
                postHLColor: "292929",
                quotesYouHLColor: "ffffff",
                ownPostHLColor: "ffffff",
                threadHLColor: "808080",
                replybgHLColor: "121212",
                replyslctColor: "ffffff"
            }, {
                name: "Stilig",
                authorName: "Myson",
                authorTrip: "!RiDeag.gG.",
                "default": true,
                bgImg: false,
                replyOp: "1.0",
                navOp: "0.9",
                mainColor: "ffffff",
                brderColor: "ebebeb",
                inputColor: "ffffff",
                inputbColor: "dedede",
                headerBGColor: "3d444e",
                headerColor: "ffffff",
                boardColor: "999999",
                bgColor: "f2f2f2",
                textColor: "717171",
                blinkColor: "999999",
                unreadColor: "999999",
                headerLColor: "babcbe",
                headerLHColor: "999999",
                linkColor: "999999",
                linkHColor: "5f5f65",
                qlColor: "999999",
                nameColor: "49637d",
                tripColor: "5f5f65",
                titleColor: "7a7f88",
                quoteColor: "009933",
                postHLColor: "5f5f65",
                quotesYouHLColor: "ff4a3e",
                ownPostHLColor: "5f5f65",
                threadHLColor: "7a7f88",
                replybgHLColor: "e6e6e6",
                replyslctColor: "5f5f65",
                customCSS: ".reply {box-shadow: -1px 1px 1px rgba(0,0,0,.08);}"
            }, {
                name: "Minimalistic Mayhem",
                authorName: "Mayhem",
                authorTrip: "!MayhemxaEo",
                "default": true,
                bgImg: false,
                replyOp: "1.0",
                navOp: "0.9",
                bgColor: "191919",
                mainColor: "222222",
                brderColor: "292929",
                inputColor: "222222",
                inputbColor: "151515",
                blinkColor: "897399",
                unreadColor: "897399",
                linkColor: "897399",
                linkHColor: "c617e6",
                qlColor: "897399",
                nameColor: "a34443",
                quoteColor: "8ba446",
                textColor: "bbbbbb",
                tripColor: "96562c",
                titleColor: "987d3e",
                headerColor: "bbbbbb",
                headerLColor: "897399",
                headerLHColor: "c617e6",
                headerBGColor: "222222",
                boardColor: "bbbbbb",
                postHLColor: "96562c",
                quotesYouHLColor: "96562c",
                ownPostHLColor: "96562c",
                threadHLColor: "987d3e",
                replybgHLColor: "141414",
                replyslctColor: "96562c"
            }, {
                name: "Blackboard",
                authorName: "Seaweed",
                authorTrip: "!!lq+3fff+/ev",
                "default": true,
                bgImg: false,
                replyOp: "1.0",
                navOp: "0.9",
                bgColor: "0a0d1c",
                mainColor: "0c1021",
                brderColor: "0e1228",
                inputColor: "0c1021",
                inputbColor: "080b16",
                blinkColor: "54b12e",
                unreadColor: "8da6ce",
                linkColor: "fbde2d",
                linkHColor: "4b65cc",
                qlColor: "fbde2d",
                nameColor: "8da6ce",
                quoteColor: "9acf08",
                textColor: "f8f8f8",
                tripColor: "ff6400",
                titleColor: "ff6400",
                headerColor: "f8f8f8",
                headerLColor: "fbde2d",
                headerLHColor: "4b65cc",
                headerBGColor: "0c1021",
                boardColor: "f8f8f8",
                postHLColor: "ff6400",
                quotesYouHLColor: "ff6400",
                ownPostHLColor: "ff6400",
                threadHLColor: "ff6400",
                replybgHLColor: "080c1d",
                replyslctColor: "ff6400"
            }, {
                name: "Dark Flat",
                authorName: "ahodesuka",
                authorTrip: "!.pC/AHOKAg",
                "default": true,
                bgImg: "R0lGODlhAwADAIAAAB0dHRkZGSH5BADoAwAALAAAAAADAAMAAAIDDG5YADs=",
                bgRPA: "repeat top left fixed",
                replyOp: "1.0",
                navOp: "0.9",
                bgColor: "1C1D1E",
                mainColor: "232425",
                brderColor: "292a2b",
                inputColor: "18191a",
                inputbColor: "121314",
                blinkColor: "6f99b4",
                unreadColor: "ac9bb0",
                linkColor: "ac9bb0",
                linkHColor: "6f99b4",
                qlColor: "ac9bb0",
                nameColor: "a8c6d9",
                quoteColor: "b3c45e",
                textColor: "dddddd",
                tripColor: "d4c095",
                titleColor: "9390c9",
                headerColor: "dddddd",
                headerLColor: "ac9bb0",
                headerLHColor: "6f99b4",
                headerBGColor: "232425",
                boardColor: "dddddd",
                postHLColor: "d4c095",
                quotesYouHLColor: "d4c095",
                ownPostHLColor: "d4c095",
                threadHLColor: "9390c9",
                replybgHLColor: "171919",
                replyslctColor: "d4c095"
            }, {
                name: "Yukimura",
                authorName: "the real",
                authorTrip: "!eKISSUy3/c",
                "default": true,
                bgImg: false,
                replyOp: "1.0",
                navOp: "0.9",
                mainColor: "1b1b1b",
                brderColor: "191919",
                inputColor: "1b1b1b",
                inputbColor: "1b1b1b",
                headerBGColor: "1b1b1b",
                headerColor: "e3c2b3",
                boardColor: "e3c2b3",
                bgColor: "171717",
                textColor: "e3c2b3",
                blinkColor: "5c433c",
                headerLColor: "e96a81",
                headerLHColor: "e96a81",
                linkColor: "e96a81",
                linkHColor: "e96a81",
                qlColor: "e96a81",
                nameColor: "e96a81",
                tripColor: "5c433c",
                titleColor: "5c433c",
                quoteColor: "b3c45e",
                unreadColor: "5c433c",
                postHLColor: "5c433c",
                quotesYouHLColor: "d63e34",
                ownPostHLColor: "5c433c",
                threadHLColor: "5c433c",
                replybgHLColor: "0d0d0d",
                replyslctColor: "5c433c"
            }, {
                name: "Photons + Odin",
                authorName: "John",
                authorTrip: "!Hu6tDS8lls",
                "default": true,
                bgImg: "R0lGODlhAwADAIAAAB0dHRkZGSH5BADoAwAALAAAAAADAAMAAAIDDG5YADs=",
                bgRPA: "repeat top left fixed",
                replyOp: "1.0",
                navOp: "0.9",
                mainColor: "1a1a1a",
                brderColor: "1f1f1f",
                inputColor: "18191a",
                inputbColor: "121314",
                headerBGColor: "1a1a1a",
                headerColor: "dddddd",
                boardColor: "dddddd",
                bgColor: "202020",
                textColor: "dddddd",
                blinkColor: "c72d41",
                headerLColor: "737f88",
                headerLHColor: "4f585d",
                linkColor: "737f88",
                linkHColor: "4f585d",
                qlColor: "737f88",
                nameColor: "0099bc",
                tripColor: "ff0085",
                titleColor: "ffa600",
                quoteColor: "85c600",
                unreadColor: "446a6d",
                postHLColor: "ff0085",
                quotesYouHLColor: "ff0085",
                ownPostHLColor: "ff0085",
                threadHLColor: "ffa600",
                replybgHLColor: "0d0d0d",
                replyslctColor: "ff0085"
            }, {
                name: "Photon",
                authorName: "Seaweed",
                authorTrip: "!!lq+3fff+/ev",
                "default": true,
                bgImg: false,
                replyOp: "1.0",
                navOp: "0.9",
                bgColor: "eeeeee",
                mainColor: "dddddd",
                brderColor: "c4c4c4",
                inputColor: "ffffff",
                inputbColor: "cccccc",
                blinkColor: "111111",
                unreadColor: "ff6600",
                linkColor: "ff6600",
                linkHColor: "ff3300",
                qlColor: "ff6600",
                nameColor: "004a99",
                quoteColor: "789922",
                textColor: "333333",
                tripColor: "ff3300",
                titleColor: "002244",
                headerColor: "333333",
                headerLColor: "ff6600",
                headerLHColor: "ff3300",
                headerBGColor: "dddddd",
                boardColor: "004a99",
                postHLColor: "ff3300",
                quotesYouHLColor: "004a99",
                ownPostHLColor: "ff3300",
                threadHLColor: "002244",
                replybgHLColor: "c4c4c4",
                replyslctColor: "ff3300"
            }, {
                name: "Original Minimalistic Mayhem",
                authorName: "Mayhem",
                authorTrip: "!MayhemxaEo",
                "default": true,
                bgImg: false,
                replyOp: "1.0",
                navOp: "0.9",
                bgColor: "191919",
                mainColor: "333333",
                brderColor: "111111",
                inputColor: "222222",
                inputbColor: "151515",
                blinkColor: "559c7a",
                unreadColor: "559c7a",
                linkColor: "559c7a",
                linkHColor: "c7de1a",
                qlColor: "559c7a",
                nameColor: "2e88a6",
                quoteColor: "8ba446",
                textColor: "dddddd",
                tripColor: "8c5d2a",
                titleColor: "486273",
                headerColor: "dddddd",
                headerLColor: "559c7a",
                headerLHColor: "c7de1a",
                headerBGColor: "333333",
                boardColor: "dddddd",
                postHLColor: "8c5d2a",
                quotesYouHLColor: "8c5d2a",
                ownPostHLColor: "8c5d2a",
                threadHLColor: "486273",
                replybgHLColor: "25262a",
                replyslctColor: "8c5d2a"
            }, {
                name: "Tomorrow",
                authorName: "Seaweed",
                authorTrip: "!!lq+3fff+/ev",
                "default": true,
                bgImg: false,
                replyOp: "1.0",
                navOp: "0.9",
                bgColor: "1d1f21",
                mainColor: "282a2e",
                brderColor: "373b41",
                inputColor: "282a2e",
                inputbColor: "1d1f21",
                blinkColor: "5f89ac",
                unreadColor: "81a2be",
                linkColor: "81a2be",
                linkHColor: "cc6666",
                qlColor: "81a2be",
                nameColor: "81a2be",
                quoteColor: "b5bd68",
                textColor: "c5c8c6",
                tripColor: "8abeb7",
                titleColor: "b294bb",
                headerColor: "c5c8c6",
                headerLColor: "81a2be",
                headerLHColor: "cc6666",
                headerBGColor: "282a2e",
                boardColor: "c5c8c6",
                postHLColor: "8abeb7",
                quotesYouHLColor: "8abeb7",
                ownPostHLColor: "8abeb7",
                threadHLColor: "b294bb",
                replybgHLColor: "24262a",
                replyslctColor: "8abeb7",
                customCSS: "span.postNum.desktop > a {\ncolor: #c5c8c6 !important\n}\nspan.postNum.desktop > a:hover {\ncolor: #81a2be !important\n}"
            }, {
                name: "Yotsuba Purple",
                authorName: "Seaweed",
                authorTrip: "!!lq+3fff+/ev",
                "default": true,
                bgImg: false,
                replyOp: "1.0",
                navOp: "0.9",
                bgColor: "f8f3fe",
                mainColor: "eeddff",
                brderColor: "cab7d9",
                inputColor: "ffffff",
                inputbColor: "cab7d9",
                blinkColor: "000000",
                unreadColor: "962594",
                linkColor: "962594",
                linkHColor: "b22caa",
                qlColor: "b22caa",
                nameColor: "591177",
                quoteColor: "789922",
                textColor: "000000",
                tripColor: "b22caa",
                titleColor: "0f0c5d",
                headerColor: "000000",
                headerLColor: "962594",
                headerLHColor: "b22caa",
                headerBGColor: "eeddff",
                boardColor: "591177",
                postHLColor: "b22caa",
                quotesYouHLColor: "d63e34",
                ownPostHLColor: "b22caa",
                threadHLColor: "0f0c5d",
                replybgHLColor: "b7aac4",
                replyslctColor: "b22caa"
            }, {
                name: "安心院なじみ",
                authorName: "ahodesuka",
                authorTrip: "!.pC/AHOKAg",
                "default": true,
                bgImg: false,
                replyOp: "1.0",
                navOp: "0.9",
                bgColor: "ffffff",
                mainColor: "efefef",
                brderColor: "d6d6d6",
                inputColor: "cccccc",
                inputbColor: "bbbbbb",
                blinkColor: "f5871f",
                unreadColor: "bf8040",
                linkColor: "bf8040",
                linkHColor: "bf8040",
                qlColor: "bf8040",
                nameColor: "2b80c2",
                quoteColor: "718c00",
                textColor: "4d4d4c",
                tripColor: "3e999f",
                titleColor: "4d4d4d",
                headerColor: "4d4d4c",
                headerLColor: "bf8040",
                headerLHColor: "bf8040",
                headerBGColor: "efefef",
                boardColor: "4d4d4c",
                postHLColor: "3e999f",
                quotesYouHLColor: "3e999f",
                ownPostHLColor: "3e999f",
                threadHLColor: "4d4d4d",
                replybgHLColor: "c7c7c7",
                replyslctColor: "3e999f"
            }, {
                name: "Solarized Dark", // http://ethanschoonover.com/solarized
                authorName: "ubuntufriend",
                authorTrip: "!UbuntuBReY!!iizPaxgtRk3",
                "default": true,
                bgImg: false,
                replyOp: "1.0",
                navOp: "0.9",
                bgColor: "073642",
                mainColor: "032b36",
                brderColor: "133942",
                inputColor: "073642",
                inputbColor: "0d272e",
                blinkColor: "4f5f8f",
                unreadColor: "696fc0",
                linkColor: "696bba",
                linkHColor: "d33682",
                qlColor: "696bba",
                nameColor: "586e75",
                quoteColor: "859900",
                textColor: "93a1a1",
                tripColor: "2aa198",
                titleColor: "bec2c4",
                headerColor: "93a1a1",
                headerLColor: "696bba",
                headerLHColor: "d33682",
                headerBGColor: "032b36",
                boardColor: "93a1a1",
                postHLColor: "2aa198",
                quotesYouHLColor: "2aa198",
                ownPostHLColor: "2aa198",
                threadHLColor: "bec2c4",
                replybgHLColor: "073642",
                replyslctColor: "2aa198"
            }, {
                name: "4chan Rewired Modded", // Originally by !K.WeEabo0o, modded by ahoka
                authorName: "ahodesuka",
                authorTrip: "!.pC/AHOKAg",
                "default": true,
                bgImg: false,
                replyOp: "1.0",
                navOp: "0.9",
                bgColor: "f4f4f4",
                mainColor: "efefef",
                brderColor: "d4d4d4",
                inputColor: "e4e4e4",
                inputbColor: "cccccc",
                blinkColor: "bf7f3f",
                unreadColor: "bf7f3f",
                linkColor: "bf7f3f",
                linkHColor: "d33682",
                nameColor: "4c4c4c",
                quoteColor: "6b7a1e",
                textColor: "4c4c4c",
                tripColor: "bf7f3f",
                titleColor: "4c4c4c",
                headerColor: "4c4c4c",
                headerLColor: "bf7f3f",
                headerLHColor: "d33682",
                headerBGColor: "efefef",
                boardColor: "4c4c4c",
                postHLColor: "bf7f3f",
                quotesYouHLColor: "d63e34",
                ownPostHLColor: "bf7f3f",
                threadHLColor: "4c4c4c",
                replybgHLColor: "c7c7c7",
                replyslctColor: "bf7f3f"
            }, {
                name: "Yasashii",
                authorName: "nebukazar",
                authorTrip: "!/Am.NeBUqQ",
                "default": true,
                bgImg: false,
                replyOp: "1.0",
                navOp: "0.9",
                mainColor: "f8f8f8",
                brderColor: "f8f8f8",
                inputColor: "f8f8f8",
                inputbColor: "be7375",
                headerBGColor: "a6586f",
                headerColor: "f8f8f8",
                boardColor: "a6586f",
                bgColor: "ebebeb",
                textColor: "5b5c5c",
                blinkColor: "656599",
                headerLColor: "ebebeb",
                headerLHColor: "656599",
                linkColor: "b78087",
                linkHColor: "c8ab78",
                qlColor: "b78087",
                nameColor: "be7375",
                tripColor: "656599",
                titleColor: "b87d6e",
                quoteColor: "7eba6c",
                unreadColor: "f8f8f8",
                postHLColor: "9875a3",
                quotesYouHLColor: "656599",
                ownPostHLColor: "9875a3",
                threadHLColor: "b87d6e",
                replybgHLColor: "eaeaea",
                replyslctColor: "9875a3"
            }, {
                name: "AppChan", // Originally by Zixaphir @ http://userstyles.org/styles/54149/appchan
                authorName: "Zixaphir",
                authorTrip: "!M.........",
                "default": true,
                bgImg: false,
                replyOp: "1.0",
                navOp: "0.9",
                bgColor: "2c2c2c",
                mainColor: "333333",
                brderColor: "333333",
                inputColor: "333333",
                inputbColor: "2c2c2c",
                blinkColor: "4f5f8f",
                unreadColor: "6688aa",
                linkColor: "6688aa",
                linkHColor: "6688aa",
                qlColor: "6688aa",
                nameColor: "aaaaaa",
                quoteColor: "789922",
                textColor: "aaaaaa",
                tripColor: "aaaaaa",
                titleColor: "aaaaaa",
                headerColor: "aaaaaa",
                headerLColor: "6688aa",
                headerLHColor: "6688aa",
                headerBGColor: "333333",
                boardColor: "aaaaaa",
                postHLColor: "aaaaaa",
                quotesYouHLColor: "aaaaaa",
                ownPostHLColor: "aaaaaa",
                threadHLColor: "aaaaaa",
                replybgHLColor: "282828",
                replyslctColor: "aaaaaa"
            }, {
                name: "Zenburned",
                authorName: "lazy",
                authorTrip: "!HONKYn7h1.",
                "default": true,
                bgImg: false,
                replyOp: "1.0",
                navOp: "0.9",
                bgColor: "3f3f3f",
                mainColor: "575757",
                brderColor: "5e5e5e",
                inputColor: "454545",
                inputbColor: "888888",
                blinkColor: "dca3a3",
                unreadColor: "93b3a3",
                linkColor: "efdcbc",
                linkHColor: "f8f893",
                qlColor: "efdcbc",
                nameColor: "c0bed1",
                quoteColor: "7f9f7f",
                textColor: "dcdccc",
                tripColor: "8cd0d3",
                titleColor: "aaaaaa",
                headerColor: "dcdccc",
                headerLColor: "efdcbc",
                headerLHColor: "f8f893",
                headerBGColor: "575757",
                boardColor: "dcdccc",
                postHLColor: "8cd0d3",
                quotesYouHLColor: "8cd0d3",
                ownPostHLColor: "8cd0d3",
                threadHLColor: "aaaaaa",
                replybgHLColor: "494949",
                replyslctColor: "8cd0d3"
            }, {
                name: "Monokai",
                authorName: "Seaweed",
                authorTrip: "!!lq+3fff+/ev",
                "default": true,
                bgImg: false,
                replyOp: "1.0",
                navOp: "0.9",
                bgColor: "20211c",
                mainColor: "272822",
                brderColor: "2d2e27",
                inputColor: "20211c",
                inputbColor: "171713",
                blinkColor: "f92672",
                unreadColor: "e2db74",
                linkColor: "e2db74",
                linkHColor: "ae81ff",
                qlColor: "e2db74",
                nameColor: "5ac0cc",
                quoteColor: "a2cc28",
                textColor: "f8f8f2",
                tripColor: "fa8220",
                titleColor: "ae81ff",
                headerColor: "f8f8f2",
                headerLColor: "e2db74",
                headerLHColor: "ae81ff",
                headerBGColor: "272822",
                boardColor: "f8f8f2",
                postHLColor: "fa8220",
                quotesYouHLColor: "fa8220",
                ownPostHLColor: "fa8220",
                threadHLColor: "ae81ff",
                replybgHLColor: "23241e",
                replyslctColor: "fa8220"
            }, {
                name: "Ao ni sarasu", // based on jaygeegeegee's http://userstyles.org/styles/75602/last-fm-kind-of-blue
                authorName: "Seaweed",
                authorTrip: "!!lq+3fff+/ev",
                "default": true,
                bgImg: false,
                replyOp: "1.0",
                navOp: "0.9",
                bgColor: "e9eced",
                mainColor: "e3e7e8",
                brderColor: "cccccc",
                inputColor: "e9eced",
                inputbColor: "cccccc",
                blinkColor: "477085",
                unreadColor: "477085",
                linkColor: "477085",
                linkHColor: "5d6678",
                qlColor: "477085",
                nameColor: "4c4c4c",
                quoteColor: "6b7a1e",
                textColor: "4c4c4c",
                tripColor: "5d6678",
                titleColor: "617d6f",
                headerColor: "4c4c4c",
                headerLColor: "477085",
                headerLHColor: "5d6678",
                headerBGColor: "e3e7e8",
                boardColor: "477085",
                postHLColor: "5d6678",
                quotesYouHLColor: "d63e34",
                ownPostHLColor: "5d6678",
                threadHLColor: "617d6f",
                replybgHLColor: "d5dada",
                replyslctColor: "5d6678"
            }, {
                name: "Blue Tone",
                authorName: "Leagle",
                authorTrip: "!YoGiiH6Oi.",
                "default": true,
                bgImg: false,
                replyOp: "1.0",
                navOp: "0.9",
                mainColor: "222222",
                brderColor: "222222",
                inputColor: "18191a",
                inputbColor: "121314",
                headerBGColor: "1b1b1b",
                headerColor: "dddddd",
                boardColor: "dddddd",
                bgColor: "1b1b1b",
                textColor: "a0a0a0",
                blinkColor: "3296c8",
                headerLColor: "3296c8",
                headerLHColor: "dddddd",
                linkColor: "a0a0a0",
                linkHColor: "dddddd",
                qlColor: "3296c8",
                nameColor: "dddddd",
                tripColor: "dddddd",
                titleColor: "a0a0a0",
                quoteColor: "009933",
                unreadColor: "3296c8",
                postHLColor: "ffffff",
                quotesYouHLColor: "ffffff",
                ownPostHLColor: "ffffff",
                threadHLColor: "a0a0a0",
                replybgHLColor: "141414",
                replyslctColor: "ffffff",
                customCSS: "body{\nbackground: rgba(19,19,19,1);\n}\n.boardBanner .boardTitle {\ntext-shadow: 0 0 3px #a0a0a0 !important;\nletter-spacing: 0px !important;\n}\n#delform {\n padding: 0 2px !important;\n background: rgba(19,19,19,1);\n}"
            }, {
                name: "Cold Snap",
                authorName: "Kori",
                authorTrip: "!STRaW/KORI",
                "default": true,
                bgImg: false,
                replyOp: "1.0",
                navOp: "0.9",
                mainColor: "fcfcfc",
                brderColor: "ebebeb",
                inputColor: "ffffff",
                inputbColor: "ffffff",
                headerBGColor: "ffffff",
                headerColor: "aaaaaa",
                boardColor: "6699cc",
                bgColor: "ffffff",
                textColor: "232323",
                blinkColor: "6699cc",
                headerLColor: "aaaaaa",
                headerLHColor: "6699cc",
                linkColor: "6699cc",
                linkHColor: "6699cc",
                qlColor: "6699cc",
                nameColor: "aaaaaa",
                tripColor: "476b8f",
                titleColor: "909090",
                quoteColor: "83bf57",
                unreadColor: "6699cc",
                postHLColor: "476b8f",
                quotesYouHLColor: "476b8f",
                ownPostHLColor: "476b8f",
                threadHLColor: "909090",
                replybgHLColor: "eeeeee",
                replyslctColor: "476b8f"
            }, {
                name: "Blue Phallus",
                authorName: "iluvOP",
                authorTrip: "!Tripfags can die.",
                "default": true,
                bgImg: false,
                replyOp: "1.0",
                navOp: "0.9",
                mainColor: "242436",
                brderColor: "242436",
                inputColor: "242436",
                inputbColor: "262638",
                headerBGColor: "242436",
                headerColor: "da637e",
                boardColor: "7787a3",
                bgColor: "20202f",
                textColor: "a7a7ad",
                blinkColor: "4b5e57",
                headerLColor: "4c626d",
                headerLHColor: "da637e",
                linkColor: "7787a3",
                linkHColor: "da637e",
                qlColor: "4b5e57",
                nameColor: "da637e",
                tripColor: "63918b",
                titleColor: "da637e",
                quoteColor: "b1b792",
                unreadColor: "64657b",
                postHLColor: "da637e",
                quotesYouHLColor: "da637e",
                ownPostHLColor: "da637e",
                threadHLColor: "da637e",
                replybgHLColor: "20202f",
                replyslctColor: "da637e",
                customCSS: ".reply { box-shadow: -2px 2px 2px rgba(0,0,0,.10); }"
            }, {
                name: "Midnight Caek",
                authorName: "saxamaphone",
                authorTrip: "!3.saxN0DHY",
                "default": true,
                bgImg: false,
                replyOp: "1.0",
                navOp: "0.9",
                mainColor: "1c1c1c",
                brderColor: "1c1c1c",
                inputColor: "1c1c1c",
                inputbColor: "1c1c1c",
                headerBGColor: "101010",
                headerColor: "909090",
                boardColor: "909090",
                bgColor: "101010",
                textColor: "909090",
                blinkColor: "424247",
                headerLColor: "909090",
                headerLHColor: "47475b",
                linkColor: "57577b",
                linkHColor: "47475b",
                qlColor: "57577b",
                nameColor: "7c2d2d",
                tripColor: "3e7157",
                titleColor: "aaaaaa",
                quoteColor: "71793e",
                unreadColor: "57577b",
                postHLColor: "7c2d2d",
                quotesYouHLColor: "7c2d2d",
                ownPostHLColor: "7c2d2d",
                threadHLColor: "aaaaaa",
                replybgHLColor: "0e0e0e",
                replyslctColor: "7c2d2d"
            }],

            init: function () {
                $SS.conf["Themes"] = Array.isArray($SS.conf["Themes"]) ?
                    this.defaults.concat($SS.conf["Themes"]) : this.defaults.slice(0);

                var i;
                if ($SS.conf["System Theming"]) {
                    i = window.matchMedia('(prefers-color-scheme: dark)').matches ?
                        parseInt($SS.conf["Dark Theme"], 10) : parseInt($SS.conf["Light Theme"], 10);
                } else {
                    i = $SS.conf["Selected Theme"];
                }

                var hidden = $SS.conf["Hidden Themes"] || [],
                    tIndex = $SS.conf["Themes"][i] ? i : 0;
                // A stored selection can point at a since-hidden default;
                // show the first theme the list still offers instead
                if (hidden.indexOf(tIndex) !== -1)
                    for (var j = 0; j < $SS.conf["Themes"].length; j++)
                        if (hidden.indexOf(j) === -1) { tIndex = j; break; }
                $SS.theme = new $SS.Theme(tIndex); // Set the active theme.
                $SS.setThemeVariables();

                // Listen for system color scheme changes
                if (!this._mqListener) {
                    this._mqListener = function () {
                        if ($SS.conf["System Theming"]) {
                            $SS.options.refresh();
                        }
                    };
                    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', this._mqListener);
                }
            }
        },

        classes: {
            init: function () {
                var cl = document.documentElement.classList,
                    // The home page has its own layout; several board-page
                    // layout features must not engage there
                    // The text subdomain's home is the same design under
                    // homepage-text-mode (identical stylesheet, fewer panels)
                    isHome = !!document.body && (document.body.classList.contains("homepage-standard-mode") ||
                        document.body.classList.contains("homepage-text-mode"));
                cl.add("oneechan");
                // The text subdomain renders the same design without images;
                // gives the ported CSS a hook for text-board adjustments
                cl.toggle("st-text", $SS.location.sub === "text");
                cl.toggle("isLight", $SS.theme.textColor.isLight === true);
                cl.toggle("dark-captcha", $SS.theme.bgColor.isLight === false);
                cl.toggle("underline-quotes", $SS.conf["Underline QuoteLinks"] === true);
                cl.toggle("underline-disabled", $SS.conf["Underline All Links"] === false);
                cl.toggle("rounded-corners", $SS.conf["Rounded Corners"] === true);
                cl.toggle("hide-board-name", $SS.conf["Show Board Name"] === false);
                cl.toggle("reply-fit-width", $SS.conf["Fit Width"] === true);
                cl.toggle("fit-postmenu", $SS.conf["Fit Post Menu"] === true);
                cl.toggle("hide-banner", $SS.conf["Show Banner"] === false);
                cl.toggle("banner-opacity", $SS.conf["Reduce Banner Opacity"] === true);
                cl.toggle("show-form", $SS.conf["Show Original Form"] === false);
                cl.toggle("post-info", $SS.conf["Show Reply Header"] === true);
                cl.toggle("show-file-info", $SS.conf["Show File Info"] === false);
                cl.toggle("borders-all", $SS.conf["Borders"] === 2);
                cl.toggle("borders-none", $SS.conf["Borders"] === 3);
                cl.toggle("hl-border", $SS.conf["Decoration Style"] === 1);
                cl.toggle("hl-outline", $SS.conf["Decoration Style"] === 2);
                cl.toggle("hl-border-down", $SS.conf["Decoration Style"] === 3);
                // The sidebar rearranges the board header/banner; on the
                // home page that mangles its custom layout
                cl.toggle("right-sidebar", $SS.conf["Sidebar Position"] === 1 && !isHome);
                cl.toggle("left-sidebar", $SS.conf["Sidebar Position"] === 2 && !isHome);
                cl.toggle("ss-sidebar", $SS.conf["SS-like Sidebar"] === true && !isHome);
                cl.toggle("mini-sidebar", $SS.conf["Minimal Sidebar"] === true && !isHome);
                cl.toggle("recolor-even", $SS.conf["Recolor Even Replies"] === true);
                cl.toggle("alt-spoiler", $SS.conf["Invert Spoiler"] === true);
                cl.toggle("backlink-icon", $SS.conf["Backlink Icons"] === true);
                cl.toggle("backlink-shadow", $SS.conf["Backlink Shadow"] === true);
                cl.toggle("fit-eximg", $SS.conf["Fit Expanded Images"] === true);
                cl.toggle("normal-qr", $SS.conf["Autohide Style"] === 1);
                cl.toggle("vertical-qr", $SS.conf["Autohide Style"] === 2);
                cl.toggle("fade-qr", $SS.conf["Autohide Style"] === 3);
                cl.toggle("qr-opacity", $SS.conf["Transparent QR"] === true);
                cl.toggle("qr-background", $SS.conf["Remove Background"] === true);
                cl.toggle("qr-controls", $SS.conf["Remove Controls"] === true);
                cl.toggle("force-indent", $SS.conf["Indent OP"] === false);
                cl.toggle("force-wrapping", $SS.conf["Allow Wrapping Around OP"] === false);
                cl.toggle("op-background", $SS.conf["OP Background"] === true);
                cl.toggle("expand-inputs", $SS.conf["Expanding Form Inputs"] === true);
                cl.toggle("qr-transition", $SS.conf["Animated Transition"] === true);
                cl.toggle("ts-notifs", $SS.conf["Style Holotower TS Notifications"] === true);
                cl.toggle("header-gradient", $SS.conf["Show Header Background Gradient"] === true);
                cl.toggle("header-shadow", $SS.conf["Show Header Shadow"] === false);
                cl.toggle("header-highlight", $SS.conf["Highlight Current Board"] === false);
                cl.toggle("hide-navlinks", $SS.conf["Show Navigation Links"] === false);
                cl.toggle("hide-navlinktop", $SS.conf["Show Top Links"] === false);
                cl.toggle("hide-navlinkbot", $SS.conf["Show Bottom Links"] === false);
                cl.toggle("thumb-opacity", $SS.conf["Reduce Thumbnail Opacity"] === true);
                cl.toggle("follow-cursor", $SS.conf["Follow Cursor"] === true);
                cl.toggle("catalog-justify", $SS.conf["Justified Text"] === true);
                cl.toggle("catalog-background", $SS.conf["Show Background"] === true);
                cl.toggle("catalog-thumbsize", $SS.conf["Unified Thumbnail Size"] === true);
                cl.toggle("use-sc-icons", $SS.conf["Use StyleTower Icons"] === true);
                cl.toggle("highlight-you", $SS.conf["Highlight Posts Quoting You"] === true);
                cl.toggle("highlight-own", $SS.conf["Highlight Own Posts"] === true);
                cl.toggle("mascot-overlap", $SS.conf["Mascots Overlap Posts"] === true);
                cl.toggle("mascot-dim", $SS.conf["Reduce Mascot Opacity"] === true);
                cl.toggle("st-home", isHome);
                // Holotower marks the fixed header on the boardlist element itself
                // (Holotower TS "Fixed Header" / "Auto-hide Header" toggles); mirror
                // that state onto :root as the classes the ported CSS keys off.
                var headerEl = document.querySelector("body > .boardlist:not(.bottom)"),
                    lastHeaderClass = null,
                    tsHeaderSetting = function (key) {
                        try { return JSON.parse(localStorage.getItem("Thread Settings") || "{}")[key] === true; } catch (e) { return false; }
                    },
                    syncHeader = function () {
                        // TS rewrites the header's classes on every scroll
                        // event; only an actual change is worth mirroring
                        var cls = headerEl ? headerEl.className : "";
                        if (cls === lastHeaderClass) return;
                        lastHeaderClass = cls;
                        var hc = headerEl ? headerEl.classList : null,
                            isFixed = hc != null && hc.contains("fixed"),
                            // TS's hide-on-scroll adds autohide+scroll while
                            // the page scrolls down and drops them on the way
                            // up; the header is only tucked away, so the page
                            // keeps its top padding rather than jumping by
                            // the header's height at every direction change.
                            // The Auto-hide Header mode (autohide on its own,
                            // or stored as a setting) is what frees the space
                            autohide = isFixed && hc.contains("autohide") &&
                                (!hc.contains("scroll") || tsHeaderSetting("headerAutohide"));
                        cl.toggle("fixed", isFixed);
                        cl.toggle("top-header", isFixed);
                        cl.toggle("autohide", autohide);
                    };
                // TS only builds its fixed header on thread pages; extend its
                // stored Fixed/Auto-hide Header preference to the index and
                // catalog (its stylesheet ships on those pages too) so the
                // header behaves the same site-wide.
                if (!$SS.location.reply && headerEl && !isHome) {
                    try {
                        var tsHeader = JSON.parse(localStorage.getItem("Thread Settings") || "{}"),
                            wantFixed = tsHeader.headerFixed !== false;
                        headerEl.classList.toggle("fixed", wantFixed);
                        headerEl.classList.toggle("autohide", wantFixed && tsHeader.headerAutohide === true);
                        if (wantFixed && document.body)
                            document.body.style.setProperty("--header-height", (headerEl.offsetHeight || 25) + "px");
                    } catch (e) { }
                }
                syncHeader();
                if (headerEl && !$SS._headerObserver) {
                    $SS._headerObserver = new MutationObserver(syncHeader);
                    $SS._headerObserver.observe(headerEl, { attributes: true, attributeFilter: ["class"] });
                }
                // Once: later posts come through the DOM observer, and a
                // live settings change need not re-query every post
                if (!$SS._initDone) $SS.replacePostMenuBtn();
            }
        },

        /* STRUCTS */
        Color: function (hex, incHover) {
            // Themes from imports/old versions may carry 3-digit, prefixed or
            // invalid values; normalize so the emitted CSS is always valid
            hex = $SS.normalizeHex(hex) || "000000";
            this.hex = "#" + hex;
            this.private_rgb = $SS.RGBFromHex(hex);
            this.rgb = this.private_rgb.join(",");
            this.isLight = $SS.isLight(this.private_rgb);
            this.shiftRGB = function (shift, smart) {
                var rgb = this.private_rgb.slice(0);

                shift = smart ?
                    (this.isLight ? (shift < 0 ? shift : -shift) : Math.abs(shift)) : shift;

                rgb[0] = Math.min(Math.max(rgb[0] + shift, 0), 255);
                rgb[1] = Math.min(Math.max(rgb[1] + shift, 0), 255);
                rgb[2] = Math.min(Math.max(rgb[2] + shift, 0), 255);

                return rgb.join(",");
            };

            if (incHover)
                this.hover = this.shiftRGB(16, true);
        },
        Image: function (img, RPA) {
            this.img = img;
            this.RPA = RPA;
            this.get = function () {
                if (!this.img) return "none ";
                // The theme variables are rebuilt on every live change; an
                // embedded (base64) background can run to megabytes, and
                // validating and escaping it each time is regex work over
                // the whole string. The last result is kept
                var memo = $SS._imageMemo;
                if (memo && memo.img === this.img && memo.RPA === this.RPA) return memo.out;

                var src;
                if ($SS.validBase64(this.img)) {
                    // Imported themes may keep the data: prefix; strip it so it
                    // can't be doubled when the URI is rebuilt
                    var b64 = $SS.cleanBase64(this.img);
                    src = "data:image/" + $SS.typeofBase64(b64) + ";base64," + b64;
                } else
                    src = String(this.img).replace(/['"\\()\s]/g, function (c) {
                        return /\s/.test(c) ? (c === " " ? "%20" : "") :
                            "%" + c.charCodeAt(0).toString(16).toUpperCase();
                    });

                var out = "url('" + src + "')" + (this.RPA !== undefined ? " " + this.RPA : "");
                $SS._imageMemo = { img: this.img, RPA: this.RPA, out: out };
                return out;
            };
        },
        Theme: function (index) {
            var theme;

            if ((theme = $SS.conf["Themes"][index]) == undefined) {
                this.hidden = true;
                return;
            }

            this.index = index;
            this.hidden = $SS.conf["Hidden Themes"].indexOf(index) !== -1;
            this.name = theme.name;
            this.authorName = theme.authorName || "Anonymous";
            this.authorTrip = theme.authorTrip || "!..NoTrip..";
            this.default = theme.default;
            this.bgImg = new $SS.Image(theme.bgImg, theme.bgRPA);
            // Free-text in old saves: clamp to 0..1 so a stray value can't
            // invalidate every rgba() consumer
            this.replyOp = $SS.normalizeOpacity(theme.replyOp, "1.0");
            this.navOp = $SS.normalizeOpacity(theme.navOp, "0.9");
            // Themes from older StyleChan/OneeChan versions lack the newer
            // keys; derive those from related colors rather than painting
            // them black (OneeChan's highlightColor is our postHLColor)
            var col = function () {
                for (var i = 0; i < arguments.length; i++) {
                    var v = $SS.normalizeHex(theme[arguments[i]]);
                    if (v) return v;
                }
                return null;
            };
            this.bgColor = new $SS.Color(col("bgColor", "mainColor"));
            this.mainColor = new $SS.Color(col("mainColor", "bgColor"));
            this.textColor = new $SS.Color(col("textColor", "headerColor"));
            this.brderColor = new $SS.Color(col("brderColor", "mainColor"));
            this.inputColor = new $SS.Color(col("inputColor", "mainColor"), true);
            this.inputbColor = new $SS.Color(col("inputbColor", "brderColor", "mainColor"));
            this.linkColor = new $SS.Color(col("linkColor", "textColor"));
            this.linkHColor = new $SS.Color(col("linkHColor", "linkColor", "textColor"));
            this.qlColor = new $SS.Color(col("qlColor", "linkColor", "textColor"));
            this.blinkColor = new $SS.Color(col("blinkColor", "linkColor", "textColor"));
            this.unreadColor = new $SS.Color(col("unreadColor", "linkColor", "textColor"));
            this.nameColor = new $SS.Color(col("nameColor", "textColor"));
            this.tripColor = new $SS.Color(col("tripColor", "nameColor", "textColor"));
            this.titleColor = new $SS.Color(col("titleColor", "nameColor", "textColor"));
            this.quoteColor = new $SS.Color(col("quoteColor", "textColor"));
            this.headerColor = new $SS.Color(col("headerColor", "textColor"));
            this.boardColor = new $SS.Color(col("boardColor", "headerColor", "textColor"));
            this.headerLColor = new $SS.Color(col("headerLColor", "linkColor", "textColor"));
            this.headerLHColor = new $SS.Color(col("headerLHColor", "linkHColor", "linkColor", "textColor"));
            this.headerBGColor = new $SS.Color(col("headerBGColor", "mainColor", "bgColor"));
            this.postHLColor = new $SS.Color(col("postHLColor", "highlightColor", "titleColor", "textColor"));
            this.quotesYouHLColor = new $SS.Color(col("quotesYouHLColor", "nameColor", "textColor"));
            this.ownPostHLColor = new $SS.Color(col("ownPostHLColor", "tripColor", "textColor"));
            this.threadHLColor = new $SS.Color(col("threadHLColor", "titleColor", "textColor"));
            this.replyslctColor = new $SS.Color(col("replyslctColor", "linkColor", "textColor"));
            this.replybgHLColor = new $SS.Color(col("replybgHLColor", "mainColor", "bgColor"));
            // Hover previews default to the shade replies always used, so
            // themes without the key keep their look
            this.hoverColor = theme.hoverColor ? new $SS.Color(theme.hoverColor) : null;
            this.hoverOutColor = theme.hoverOutColor ? new $SS.Color(theme.hoverOutColor) : null;
            this.hoverOp = $SS.normalizeOpacity(theme.hoverOp, "0.8");
            this.hoverOutOp = $SS.normalizeOpacity(theme.hoverOutOp, "0.5");
            this.codeBackground = (this.bgColor.isLight ? "255, 255, 255, 0.2" : "0, 0, 0, 0.2");
            this.codeBorder = (this.bgColor.isLight ? "204, 204, 204, 1.0" : "204, 204, 204, 0.1");
            this.icons = {
                menuIcon: "<svg viewBox='0 0 512 512' preserveAspectRatio='xMidYMid meet' class='icon' xmlns='http://www.w3.org/2000/svg'>" +
                    "<path fill='currentColor' d='M256 432q-15 1-16 16 1 15 16 16 15-1 16-16-1-15-16-16ZM64 288H448v32q-1 27-19 45t-45 19H320v64q-1 27-19 45t-45 19q-27-1-45-19t-19-45V384H128q-27-1-45-19T64 320V288v32-32ZM226 6l21 52q3 6 9 6t9-6L286 6q2-6 9-6H400q20 1 34 14 13 14 14 34V224v22 10H74 64V246 224 48q1-20 14-34Q92 1 112 0h10q6 0 8 6l21 52q3 6 9 6t9-6L190 6q2-6 9-6h19q6 0 8 6Z'/></svg>",
                backlink: "<svg viewBox='0 0 30 30' preserveAspectRatio='xMidYMid meet' xmlns='http://www.w3.org/2000/svg'>" +
                    "<path fill='rgb(" + this.blinkColor.rgb + ")' d='M12.981,9.073V6.817l-12.106,6.99l12.106,6.99v-2.422c3.285-0.002,9.052,0.28,9.052,2.269c0,2.78-6.023,4.263-6.023,4.263v2.132c0,0,13.53,0.463,13.53-9.823C29.54,9.134,17.952,8.831,12.981,9.073z'/></svg>",
                threadClosed: "<svg viewBox='0 0 30 30' preserveAspectRatio='xMidYMid meet' xmlns='http://www.w3.org/2000/svg'>" +
                    "<path fill='rgb(" + this.headerColor.rgb + ")' d='M22.335,12.833V9.999h-0.001C22.333,6.501,19.498,3.666,16,3.666S9.666,6.502,9.666,10h0v2.833H7.375V25h17.25V12.833H22.335zM11.667,10C11.667,10,11.667,10,11.667,10c0-2.39,1.944-4.334,4.333-4.334c2.391,0,4.335,1.944,4.335,4.333c0,0,0,0,0,0v2.834h-8.668V10z'/></svg>",
                threadPinned: "<svg viewBox='0 0 30 30' preserveAspectRatio='xMidYMid meet' xmlns='http://www.w3.org/2000/svg'>" +
                    "<path fill='rgb(" + this.tripColor.rgb + ")' d='M16,3.5c-4.142,0-7.5,3.358-7.5,7.5c0,4.143,7.5,18.121,7.5,18.121S23.5,15.143,23.5,11C23.5,6.858,20.143,3.5,16,3.5z M16,14.584c-1.979,0-3.584-1.604-3.584-3.584S14.021,7.416,16,7.416S19.584,9.021,19.584,11S17.979,14.584,16,14.584z'/></svg>",
                downArrow: "<svg viewBox='7 4 29 27' preserveAspectRatio='xMidYMid meet' height='16' width='16' xmlns='http://www.w3.org/2000/svg'>" +
                    "<path fill='rgb(" + this.tripColor.rgb + ")' d='M8.037,11.166L14.5,22.359c0.825,1.43,2.175,1.43,3,0l6.463-11.194c0.826-1.429,0.15-2.598-1.5-2.598H9.537C7.886,8.568,7.211,9.737,8.037,11.166z'/></svg>",
                // The same arrow cropped to its glyph: the navigation buttons
                // rotate it, and the empty right side of the 16px version would
                // become a gap on one side or the other depending on the order
                navArrow: "<svg viewBox='6.5 7.5 19 17' preserveAspectRatio='xMidYMid meet' xmlns='http://www.w3.org/2000/svg'>" +
                    "<path fill='rgb(" + this.tripColor.rgb + ")' d='M8.037,11.166L14.5,22.359c0.825,1.43,2.175,1.43,3,0l6.463-11.194c0.826-1.429,0.15-2.598-1.5-2.598H9.537C7.886,8.568,7.211,9.737,8.037,11.166z'/></svg>",
                options: "<svg viewBox='0 0 30 30' preserveAspectRatio='xMidYMid meet' xmlns='http://www.w3.org/2000/svg'>" +
                    "<path fill='rgb(" + this.headerLColor.rgb + ")' d='M15,10.5c-2.485,0-4.5,2.015-4.5,4.5s2.015,4.5,4.5,4.5s4.5-2.015,4.5-4.5S17.485,10.5,15,10.5z M27.5,17.16v-4.32l-3.02-0.5c-0.22-0.79-0.53-1.54-0.94-2.24l1.78-2.49l-3.05-3.05l-2.49,1.78c-0.7-0.4-1.45-0.72-2.24-0.94L16.16,2.4h-4.32l-0.5,3.02c-0.79,0.22-1.54,0.53-2.24,0.94L6.61,4.58L3.56,7.63l1.78,2.49c-0.4,0.7-0.72,1.45-0.94,2.24l-3.02,0.5v4.32l3.02,0.5c0.22,0.79,0.53,1.54,0.94,2.24l-1.78,2.49l3.05,3.05l2.49-1.78c0.7,0.4,1.45,0.72,2.24,0.94l0.5,3.02h4.32l0.5-3.02c0.79-0.22,1.54-0.53,2.24-0.94l2.49,1.78l3.05-3.05l-1.78-2.49c0.4-0.7,0.72-1.45,0.94-2.24L27.5,17.16z'/></svg>"
            };

            if (theme.customCSS) {
                // Old exports wrapped the CSS in parentheses and quotes
                var css = String(theme.customCSS);
                if (css.length > 2 && css[0] === "(" && css[css.length - 1] === ")")
                    css = css.slice(1, -1);
                css = css.replace(/^\\?"|\\?"$/g, '');
                this.customCSS = $SS.trimLineBreaks(css);
            } else
                this.customCSS = "";

            this.preview = function () {
                var div = $("<div " + (this.hidden ? "hidden=true " : "") +
                    " id=theme" + this.index + " class='theme-preview" + ($SS.conf["Selected Theme"] == this.index ? " selected" : "") + "'>").html("<div class=reply " +
                        "style='background-color:" + this.mainColor.hex + "!important;border:1px solid " + this.brderColor.hex + "!important;color:" + this.textColor.hex + "!important'>" +
                        "<span style='display:inline-block;width:10px;height:10px;border-radius:2px;background-color:" + this.inputColor.hex + "!important;border:1px solid " + this.inputbColor.hex + "!important;box-shadow:rgba(" + this.mainColor.shiftRGB(64) + ",.3) 0 1px;'></span>&ensp;" +
                        "<span style='color:" + this.titleColor.hex + "!important; font-weight: bold !important'>" + $SS.escapeHTML(this.name) + "</span>&ensp;" +
                        "<span style='color:" + this.nameColor.hex + "!important; font-weight: bold !important'>" + $SS.escapeHTML(this.authorName) + "</span>&ensp;" +
                        "<span style='color:" + this.tripColor.hex + "!important'> " + $SS.escapeHTML(this.authorTrip) + "</span>" +
                        "<time style='color:" + this.textColor.hex + "'> 20XX.01.01 12:00 </time>" +
                        "<a href='javascript:;' class='pv-link' style='--pv-link:" + this.linkColor.hex + ";--pv-linkh:" + this.linkHColor.hex + "'>No.22772469</a>" +
                        "<br><blockquote><span style='color:" + this.quoteColor.hex + "'>>implying this isn't a post</span><br>Post content is right here.</blockquote>" +
                        "<p class='theme-buttons-container'>" +
                        "<a href='javascript:;' title=Edit style='background-color:" + this.inputColor.hex + "!important;border:1px solid " + this.inputbColor.hex + "!important;color:" + this.textColor.hex + "!important'>Edit</a>" +
                        "<a href='javascript:;' title=Delete style='background-color:" + this.inputColor.hex + "!important;border:1px solid " + this.inputbColor.hex + "!important;color:" + this.textColor.hex + "!important'>Delete</a></p>" +
                        "<h3 class='selected-label'>Selected</h3>" +
                        "</div>");

                $(div).bind("click", function () {
                    var $this = $(this);
                    if ($this.hasClass("selected")) return;

                    $this.parent().children(".selected").removeClass("selected");
                    $this.addClass("selected");
                    // Applies at once; the panel's Save stores it
                    $SS.options.touched();
                });
                $("a[title=Delete]", div).bind("click", function (e) {
                    e.stopPropagation();
                    $SS.options.deleteTheme(index);
                });
                $("a[title=Edit]", div).bind("click", function (e) {
                    e.stopPropagation();
                    $SS.options.showTheme(index);
                });

                return div;
            };
        },

        /* HELPER METHODS */
        formatFont: function (font) {
            if (/^(serif|sans-serif|monospace|cursive|system-ui)$/.test(font))
                return font;

            return $SS.cssQuote(font);
        },
        /* A single-quoted CSS string: quotes and backslashes escaped, line
           breaks dropped (a stray quote would otherwise end the rule early) */
        cssQuote: function (s) {
            return "'" + String(s == null ? "" : s).replace(/[\\']/g, "\\$&").replace(/[\r\n]/g, "") + "'";
        },
        systemFonts: {
            windows: [
                "Arial", "Arial Black", "Arial Narrow", "Calibri", "Cambria",
                "Candara", "Century Gothic", "Comic Sans MS", "Consolas",
                "Constantia", "Corbel", "Courier New", "Franklin Gothic Medium",
                "Georgia", "Impact", "Lucida Console",
                "Lucida Sans Unicode", "Palatino Linotype", "Segoe UI",
                "Tahoma", "Times New Roman", "Trebuchet MS", "Verdana"
            ],
            macos: [
                "Arial", "Arial Black", "Comic Sans MS", "Courier New",
                "Futura", "Georgia", "Gill Sans", "Helvetica",
                "Helvetica Neue", "Hoefler Text", "Impact", "Menlo",
                "Monaco", "Optima", "Palatino", "San Francisco",
                "SF Mono", "SF Pro", "Tahoma", "Times New Roman",
                "Trebuchet MS", "Verdana"
            ],
            linux: [
                "Arial", "Cantarell", "Courier New", "DejaVu Sans",
                "DejaVu Sans Mono", "DejaVu Serif", "Georgia",
                "Liberation Mono", "Liberation Sans", "Liberation Serif",
                "Noto Sans", "Noto Sans Mono", "Tahoma",
                "Times New Roman", "Ubuntu", "Ubuntu Mono", "Verdana"
            ]
        },
        isTS: function () {
            // Holotower TS saves its settings on every run
            try {
                return !!localStorage.getItem("Thread Settings");
            } catch (e) { return false; }
        },
        getOS: function () {
            var ua = navigator.userAgent;
            if (/Windows/i.test(ua)) return "windows";
            if (/Mac/i.test(ua)) return "macos";
            if (/Linux/i.test(ua)) return "linux";
            return "windows";
        },
        RGBFromHex: function (hex) {
            var rgb = [];
            hex = parseInt($SS.normalizeHex(hex) || "000000", 16);

            rgb[0] = (hex >> 16) & 0xFF;
            rgb[1] = (hex >> 8) & 0xFF;
            rgb[2] = hex & 0xFF;

            return rgb;
        },
        hexFromRGB: function (rgb) {
            return ((1 << 24) | (rgb[0] << 16) | (rgb[1] << 8) | rgb[2]).toString(16).slice(1);
        },
        /* Returns a lowercase 6-digit hex (no "#") or null: 3-digit hex is
           expanded, 8-digit hex drops its alpha, anything else is rejected */
        normalizeHex: function (hex) {
            if (typeof hex !== "string") return null;
            hex = hex.replace(/^#/, "").toLowerCase();
            if (/^[0-9a-f]{3}$/.test(hex))
                return hex.charAt(0) + hex.charAt(0) + hex.charAt(1) + hex.charAt(1) + hex.charAt(2) + hex.charAt(2);
            if (/^[0-9a-f]{8}$/.test(hex)) return hex.substr(0, 6);
            return /^[0-9a-f]{6}$/.test(hex) ? hex : null;
        },
        /* Returns the value clamped to 0..1 as a string, or fallback when
           the value isn't numeric (cleared field, junk text, old saves) */
        normalizeOpacity: function (val, fallback) {
            var op = parseFloat(val);
            return isNaN(op) ? fallback : String(Math.min(Math.max(op, 0), 1));
        },
        escapeHTML: function (s) {
            return String(s == null ? "" : s)
                .replace(/&/g, "&amp;").replace(/"/g, "&quot;")
                .replace(/'/g, "&#39;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
        },
        isLight: function (rgb) {
            return rgb[0] + rgb[1] + rgb[2] >= 400;
        },
        trimLineBreaks: function (str) {
            return str.replace(/(\r\n|\r|\n)/gm, "");
        },
        cleanBase64: function (b64) {
            return b64.replace(/^(data:image\/(?:gif|jpe?g|png|webp|avif|svg\+xml);base64,)(\r\n|\r|\n)?/gmi, "");
        },
        typeofBase64: function (b64) {
            switch (b64.substr(0, 8)) {
                case "PD94bWwg":
                    return "svg+xml";
                case "R0lGODlh":
                    return "gif";
                case "/9j/4AAQ":
                case "/9j/4QAY":
                    return "jpeg";
                case "iVBORw0K":
                default:
                    if (b64.substr(0, 5) === "UklGR") return "webp";
                    if (b64.substr(0, 5) === "PHN2Z") return "svg+xml";
                    return "png";
            }
        },
        validBase64: function (b64) {
            return /^(?:data:image\/(?:gif|jpe?g|png|webp|avif|svg\+xml);base64,)?(?:[A-Za-z0-9+\/]{4})*(?:[A-Za-z0-9+\/]{2}==|[A-Za-z0-9+\/]{3}=|[A-Za-z0-9+\/]{4})$/i.test(b64);
        },
        validImageURL: function (img) {
            return /^https?:\/\/.+$/i.test(img);
        },
        /* Holotower (vichan) upload limits */
        maxFileSizeDefault: 10485760, /* 10MB */
        maxImageDim: 10000,

        getLocation: function (url) {
            var obj;

            if (typeof url === "string") {
                obj = document.createElement("a");
                obj.href = location.protocol + "//" + url;
            } else
                obj = window.location;

            var pathname = obj.pathname.slice(1).split("/");

            return {
                sub: obj.hostname.split(".")[0],
                board: /\.(?:php|html)$/.test(pathname[0] || "") ? "" : pathname[0],
                maxFileSize: $SS.maxFileSizeDefault,
                reply: pathname[1] === "res",
                catalog: pathname[1] === "catalog.html",
                dead: /^404\b|^Not [Ff]ound\b/.test(document.title)
            };
        }
    };
    /* END STYLE SCRIPT CLASSES */
    $SS.init();
})();
